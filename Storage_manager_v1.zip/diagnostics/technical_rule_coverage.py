import time
from collections import defaultdict

from config.settings import DB_PATH
from core.rule_engine import RuleEngine
from core.storage_scope import StorageScope
from database.db import create_connection


def gb(size):

    return size / (1024 ** 3)


def percentage(
    value,
    total
):

    if total == 0:
        return 0

    return (
        value
        / total
        * 100
    )


def main():

    print("=" * 78)

    print(
        "STORAGE MANAGER — TECHNICAL RULE COVERAGE"
    )

    print("=" * 78)

    conn = create_connection(
        DB_PATH
    )

    engine = RuleEngine()

    # --------------------------------------------------------
    # STATS
    # --------------------------------------------------------

    scope_stats = defaultdict(

        lambda: {

            "files": 0,

            "size": 0

        }

    )

    technical_matched_files = 0

    technical_matched_size = 0

    technical_unknown_files = 0

    technical_unknown_size = 0


    rule_stats = defaultdict(

        lambda: {

            "files": 0,

            "size": 0

        }

    )


    print(
        "\nAnalyzing storage scopes and technical rules..."
    )


    start = time.perf_counter()


    cursor = conn.execute(

        """
        SELECT
            path,
            size
        FROM files
        """

    )


    for path, size in cursor:

        size = size or 0


        analysis = engine.analyze_scoped(

            path,

            size

        )


        scope = analysis[
            "scope"
        ]


        scope_stats[
            scope
        ]["files"] += 1


        scope_stats[
            scope
        ]["size"] += size


        # ----------------------------------------------------
        # ONLY TECHNICAL STORAGE COUNTS
        # TOWARD RULEBOOK COVERAGE
        # ----------------------------------------------------

        if scope != StorageScope.TECHNICAL.value:

            continue


        result = analysis[
            "rule_result"
        ]


        if result is None:

            technical_unknown_files += 1

            technical_unknown_size += size

            continue


        technical_matched_files += 1

        technical_matched_size += size


        rule_stats[
            result.rule_id
        ]["files"] += 1


        rule_stats[
            result.rule_id
        ]["size"] += size


    analysis_time = (

        time.perf_counter()

        - start

    )


    # ========================================================
    # STORAGE SCOPE
    # ========================================================

    print(
        "\n" + "=" * 78
    )

    print(
        "STORAGE SCOPE BREAKDOWN"
    )

    print(
        "=" * 78
    )


    for scope, stats in scope_stats.items():

        print(

            f"{scope:20} | "

            f"{stats['files']:9,} files | "

            f"{gb(stats['size']):10.2f} GB"

        )


    # ========================================================
    # TECHNICAL COVERAGE
    # ========================================================

    total_technical_files = (

        technical_matched_files

        + technical_unknown_files

    )


    total_technical_size = (

        technical_matched_size

        + technical_unknown_size

    )


    print(
        "\n" + "=" * 78
    )

    print(
        "TECHNICAL STORAGE RULE COVERAGE"
    )

    print(
        "=" * 78
    )


    print(

        f"\nTechnical files : "

        f"{total_technical_files:,}"

    )


    print(

        f"Technical size  : "

        f"{gb(total_technical_size):.2f} GB"

    )


    print()


    print(

        f"Rule matched    : "

        f"{technical_matched_files:,} files | "

        f"{gb(technical_matched_size):.2f} GB"

    )


    print(

        f"Still unknown   : "

        f"{technical_unknown_files:,} files | "

        f"{gb(technical_unknown_size):.2f} GB"

    )


    print()


    file_coverage = percentage(
        technical_matched_files,
        total_technical_files
    )

    size_coverage = percentage(
        technical_matched_size,
        total_technical_size
    )

    print(
        f"File coverage   : {file_coverage:.2f}%"
    )

    print(
        f"Size coverage   : {size_coverage:.2f}%"
    )


    # print(

    #     "Size coverage   : "

    #     f"{percentage(

    #         technical_matched_size,

    #         total_technical_size

    #     ):.2f}%"

    # )


    # ========================================================
    # RULES
    # ========================================================

    print(
        "\n" + "=" * 78
    )

    print(
        "TECHNICAL RULE MATCHES"
    )

    print(
        "=" * 78
    )


    sorted_rules = sorted(

        rule_stats.items(),

        key=lambda item:
            item[1]["size"],

        reverse=True

    )


    for rule_id, stats in sorted_rules:

        print(

            f"{rule_id:30} | "

            f"{stats['files']:9,} files | "

            f"{gb(stats['size']):10.2f} GB"

        )


    # ========================================================
    # PERFORMANCE
    # ========================================================

    print(
        "\n" + "=" * 78
    )

    print(
        "PERFORMANCE"
    )

    print(
        "=" * 78
    )


    print(

        f"\nAnalysis time : "

        f"{analysis_time:.2f} sec"

    )


    print(
        "=" * 78
    )


    conn.close()


if __name__ == "__main__":

    main()