import os
import time
import mftparser

from config.settings import DRIVE


# ============================================================
# CONFIG
# ============================================================

FOLDER_TO_CHECK = r"C:\Users\aashi\Downloads"

TOP_DIFFERENCES = 50


def format_size(size_bytes):
    """
    Convert bytes into readable format.
    """

    if size_bytes >= 1024 ** 3:
        return f"{size_bytes / (1024 ** 3):.2f} GB"

    if size_bytes >= 1024 ** 2:
        return f"{size_bytes / (1024 ** 2):.2f} MB"

    if size_bytes >= 1024:
        return f"{size_bytes / 1024:.2f} KB"

    return f"{size_bytes} B"


def main():

    print("=" * 80)
    print("MFT SIZE vs FILESYSTEM SIZE")
    print("=" * 80)

    print(
        f"\nFolder:\n"
        f"{FOLDER_TO_CHECK}"
    )


    # ========================================================
    # MFT SCAN
    # ========================================================

    print("\nScanning MFT...")

    start = time.perf_counter()


    entries = mftparser.ScanVolume(
        DRIVE,
        only_active=True,
        microseconds=False
    )


    mft_time = (
        time.perf_counter()
        - start
    )


    print(
        f"MFT scan time: "
        f"{mft_time:.2f} sec"
    )


    # Convert:
    #
    # C:\Users\aashi\Downloads
    #
    # to:
    #
    # \users\aashi\downloads\

    relative_folder = (
        FOLDER_TO_CHECK[2:]
        .rstrip("\\")
        .lower()
        + "\\"
    )


    results = []

    checked = 0

    failed = 0


    # ========================================================
    # COMPARE INDIVIDUAL FILES
    # ========================================================

    print(
        "\nComparing file sizes..."
    )


    start = time.perf_counter()


    for entry in entries:

        path = entry[5]

        mft_size = (
            entry[7] or 0
        )

        is_directory = entry[9]


        if not path:
            continue


        if is_directory:
            continue


        if not path.lower().startswith(
            relative_folder
        ):
            continue


        full_path = (
            DRIVE + path
        )


        try:

            actual_size = (
                os.path.getsize(
                    full_path
                )
            )


        except (
            FileNotFoundError,
            PermissionError,
            OSError
        ):

            failed += 1

            continue


        extension = (
            os.path.splitext(
                full_path
            )[1]
            .lower()
        )


        if not extension:

            extension = "[no extension]"


        difference = (
            actual_size
            - mft_size
        )


        results.append(
            {
                "path": full_path,

                "extension": extension,

                "mft_size": mft_size,

                "actual_size": actual_size,

                "difference": difference,

                "abs_difference": abs(
                    difference
                )
            }
        )


        checked += 1


    compare_time = (
        time.perf_counter()
        - start
    )


    # ========================================================
    # SORT BY BIGGEST DIFFERENCE
    # ========================================================

    results.sort(
        key=lambda x: x[
            "abs_difference"
        ],

        reverse=True
    )


    # ========================================================
    # SUMMARY
    # ========================================================

    matching = sum(
        1
        for result in results
        if result["difference"] == 0
    )


    mismatching = (
        checked
        - matching
    )


    total_mft = sum(
        result["mft_size"]
        for result in results
    )


    total_actual = sum(
        result["actual_size"]
        for result in results
    )


    print(
        "\n" + "=" * 80
    )

    print(
        "SUMMARY"
    )

    print(
        "=" * 80
    )


    print(
        f"Files checked      : "
        f"{checked:,}"
    )

    print(
        f"Matching sizes     : "
        f"{matching:,}"
    )

    print(
        f"Mismatching sizes  : "
        f"{mismatching:,}"
    )

    print(
        f"Failed             : "
        f"{failed:,}"
    )


    print()


    print(
        f"Total MFT size     : "
        f"{format_size(total_mft)}"
    )

    print(
        f"Total actual size  : "
        f"{format_size(total_actual)}"
    )

    print(
        f"Missing difference : "
        f"{format_size(abs(total_actual - total_mft))}"
    )


    print(
        f"\nComparison time    : "
        f"{compare_time:.2f} sec"
    )


    # ========================================================
    # TOP DIFFERENCES
    # ========================================================

    print(
        "\n" + "=" * 80
    )

    print(
        f"TOP {TOP_DIFFERENCES} SIZE DIFFERENCES"
    )

    print(
        "=" * 80
    )


    for index, result in enumerate(
        results[:TOP_DIFFERENCES],
        start=1
    ):

        print(
            f"\n[{index}]"
        )

        print(
            f"Extension : "
            f"{result['extension']}"
        )

        print(
            f"MFT Size  : "
            f"{format_size(result['mft_size'])}"
        )

        print(
            f"Actual    : "
            f"{format_size(result['actual_size'])}"
        )

        print(
            f"Difference: "
            f"{format_size(result['abs_difference'])}"
        )

        print(
            f"Path      : "
            f"{result['path']}"
        )


if __name__ == "__main__":

    main()