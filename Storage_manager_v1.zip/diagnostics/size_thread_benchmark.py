import os
import time
from concurrent.futures import ThreadPoolExecutor

import mftparser

from config.settings import DRIVE


FOLDER_TO_CHECK = r"C:\Users\aashi\Downloads"

THREAD_COUNTS = [
    1,
    4,
    8,
    16
]


def format_gb(size_bytes):
    return size_bytes / (1024 ** 3)


def get_file_size(path):
    """
    Return actual logical file size.
    Return 0 if file disappears or cannot be accessed.
    """

    try:
        return os.path.getsize(path)

    except (
        FileNotFoundError,
        PermissionError,
        OSError
    ):
        return 0


def get_paths_from_mft():

    print("\nScanning MFT...")

    start = time.perf_counter()

    entries = mftparser.ScanVolume(
        DRIVE,
        only_active=True,
        microseconds=False
    )

    mft_time = (
        time.perf_counter()
        - start
    )

    relative_folder = (
        FOLDER_TO_CHECK[2:]
        .rstrip("\\")
        .lower()
    )

    prefix = (
        relative_folder
        + "\\"
    )

    paths = []


    for entry in entries:

        path = entry[5]
        is_directory = entry[9]

        if not path:
            continue

        if is_directory:
            continue

        if path.lower().startswith(prefix):

            full_path = (
                DRIVE + path
            )

            paths.append(
                full_path
            )


    print(
        f"MFT scan time : "
        f"{mft_time:.2f} sec"
    )

    print(
        f"Files found   : "
        f"{len(paths):,}"
    )


    return paths


def benchmark(
    paths,
    workers
):

    print(
        f"\nTesting "
        f"{workers} thread(s)..."
    )


    start = time.perf_counter()


    if workers == 1:

        sizes = [
            get_file_size(path)
            for path in paths
        ]

    else:

        with ThreadPoolExecutor(
            max_workers=workers
        ) as executor:

            sizes = list(
                executor.map(
                    get_file_size,
                    paths
                )
            )


    elapsed = (
        time.perf_counter()
        - start
    )


    total_size = sum(
        sizes
    )


    print(
        f"Time       : "
        f"{elapsed:.2f} sec"
    )

    print(
        f"Total size : "
        f"{format_gb(total_size):.2f} GB"
    )


    return (
        elapsed,
        total_size
    )


def main():

    print(
        "=" * 60
    )

    print(
        "FILE SIZE THREAD BENCHMARK"
    )

    print(
        "=" * 60
    )


    paths = get_paths_from_mft()


    results = []


    for workers in THREAD_COUNTS:

        elapsed, total_size = (
            benchmark(
                paths,
                workers
            )
        )


        results.append(
            (
                workers,
                elapsed,
                total_size
            )
        )


    print(
        "\n" + "=" * 60
    )

    print(
        "FINAL RESULTS"
    )

    print(
        "=" * 60
    )


    print(
        f"{'Threads':<12}"
        f"{'Time':<15}"
        f"{'Size':<15}"
    )


    print(
        "-" * 42
    )


    for (
        workers,
        elapsed,
        total_size

    ) in results:


        print(
            f"{workers:<12}"
            f"{elapsed:<15.2f}"
            f"{format_gb(total_size):<15.2f}"
        )


if __name__ == "__main__":

    main()