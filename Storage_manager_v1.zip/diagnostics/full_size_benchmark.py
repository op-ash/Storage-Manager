import os
import time
import gc
from concurrent.futures import ThreadPoolExecutor

import mftparser
import psutil

from config.settings import DRIVE
from core.classifier import classify_path


# ============================================================
# CONFIG
# ============================================================

WORKERS = 8


# ============================================================
# MEMORY
# ============================================================

process = psutil.Process(os.getpid())


def ram_mb():
    return (
        process.memory_info().rss
        / (1024 * 1024)
    )


def format_gb(size_bytes):
    return (
        size_bytes
        / (1024 ** 3)
    )


# ============================================================
# FILE SIZE
# ============================================================

def get_file_size(path):
    """
    Get accurate logical file size.

    Returns:
        (size, success)
    """

    try:

        return (
            os.path.getsize(path),
            True
        )

    except (
        FileNotFoundError,
        PermissionError,
        OSError
    ):

        return (
            0,
            False
        )


# ============================================================
# MAIN
# ============================================================

def main():

    print(
        "=" * 65
    )

    print(
        "FULL STORAGE SIZE BENCHMARK"
    )

    print(
        "=" * 65
    )


    initial_ram = ram_mb()


    print(
        f"\nInitial RAM: "
        f"{initial_ram:.2f} MB"
    )


    # ========================================================
    # STEP 1 — MFT SCAN
    # ========================================================

    print(
        "\nScanning MFT..."
    )


    start = time.perf_counter()


    entries = mftparser.ScanVolume(
        DRIVE,
        only_active=True,
        microseconds=False
    )


    mft_time = (
        time.perf_counter()
        - start
    )


    mft_ram = ram_mb()


    print(
        f"MFT entries : "
        f"{len(entries):,}"
    )

    print(
        f"MFT time    : "
        f"{mft_time:.2f} sec"
    )

    print(
        f"RAM         : "
        f"{mft_ram:.2f} MB"
    )


    # ========================================================
    # STEP 2 — EXTRACT USEFUL PATHS
    # ========================================================

    print(
        "\nExtracting useful paths..."
    )


    start = time.perf_counter()


    paths = []


    for entry in entries:

        path = entry[5]

        is_directory = entry[9]


        category = classify_path(
            path,
            is_directory
        )


        if category is None:

            continue


        full_path = (
            DRIVE + path
        )


        paths.append(
            full_path
        )


    path_time = (
        time.perf_counter()
        - start
    )


    print(
        f"Useful files : "
        f"{len(paths):,}"
    )

    print(
        f"Path time    : "
        f"{path_time:.2f} sec"
    )

    print(
        f"RAM          : "
        f"{ram_mb():.2f} MB"
    )


    # ========================================================
    # STEP 3 — RELEASE MFT
    # ========================================================

    print(
        "\nReleasing MFT data..."
    )


    del entries

    gc.collect()


    print(
        f"RAM after release: "
        f"{ram_mb():.2f} MB"
    )


    # ========================================================
    # STEP 4 — ACCURATE SIZE RESOLUTION
    # ========================================================

    print(
        f"\nResolving accurate file sizes "
        f"using {WORKERS} threads..."
    )


    start = time.perf_counter()


    total_size = 0

    successful = 0

    failed = 0


    with ThreadPoolExecutor(
        max_workers=WORKERS
    ) as executor:


        results = executor.map(
            get_file_size,
            paths
        )


        for (
            size,
            success
        ) in results:


            if success:

                total_size += size

                successful += 1


            else:

                failed += 1


    size_time = (
        time.perf_counter()
        - start
    )


    final_ram = ram_mb()


    # ========================================================
    # RESULTS
    # ========================================================

    print(
        "\n" + "=" * 65
    )

    print(
        "RESULTS"
    )

    print(
        "=" * 65
    )


    print(
        f"Useful files       : "
        f"{len(paths):,}"
    )

    print(
        f"Successful sizes   : "
        f"{successful:,}"
    )

    print(
        f"Failed sizes       : "
        f"{failed:,}"
    )


    print()


    print(
        f"Total actual size  : "
        f"{format_gb(total_size):.2f} GB"
    )


    print()


    print(
        f"MFT scan           : "
        f"{mft_time:.2f} sec"
    )

    print(
        f"Path extraction    : "
        f"{path_time:.2f} sec"
    )

    print(
        f"Size resolution    : "
        f"{size_time:.2f} sec"
    )


    total_time = (
        mft_time
        + path_time
        + size_time
    )


    print(
        f"Total time         : "
        f"{total_time:.2f} sec"
    )


    print()


    print(
        f"Initial RAM        : "
        f"{initial_ram:.2f} MB"
    )

    print(
        f"MFT peak RAM       : "
        f"{mft_ram:.2f} MB"
    )

    print(
        f"Final RAM          : "
        f"{final_ram:.2f} MB"
    )


    print(
        "=" * 65
    )


if __name__ == "__main__":

    main()