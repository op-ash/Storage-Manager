from config.settings import DB_PATH
from database.db import create_connection

from rules_v3 import (
    FileContext,
    StorageClassifier,
    AI_ANALYSIS,
    StandardUserFoldersRule,
    get_protected_rules,
    get_safe_rules,
)

from ai_analysis import (
    FolderTreeBuilder,
    StartingBoundaryResolver,
    DirectFileClusterBuilder,
)


# ============================================================
# HELPERS
# ============================================================

def gb(size):
    return size / (1024 ** 3)


def create_classifier():

    return StorageClassifier(
        user_rules=[
            StandardUserFoldersRule(),
        ],
        protected_rules=get_protected_rules(),
        safe_rules=get_safe_rules(),
    )


def load_ai_analysis_files(
    conn,
    classifier,
):
    """
    Load AI_ANALYSIS files once.

    This diagnostic intentionally stores the AI file list
    because the same dataset is needed by:

        1. FolderTreeBuilder
        2. DirectFileClusterBuilder

    Production pipeline can later optimize this if needed.
    """

    files = []

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        """
    )

    for path, size in cursor:

        size = size or 0

        context = FileContext.create(
            path,
            size,
        )

        result = classifier.classify_context(
            context
        )

        if result.classification == AI_ANALYSIS:

            files.append(
                (
                    path,
                    size,
                )
            )

    return files


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 80)
    print(
        "STORAGE MANAGER — AI CLUSTER COVERAGE TEST"
    )
    print("=" * 80)

    classifier = create_classifier()

    conn = create_connection(
        DB_PATH
    )

    print(
        "\nLoading AI_ANALYSIS files..."
    )

    ai_files = load_ai_analysis_files(
        conn,
        classifier,
    )

    conn.close()

    # ========================================================
    # SOURCE TOTALS
    # ========================================================

    source_file_count = len(
        ai_files
    )

    source_size = sum(
        size
        for _, size in ai_files
    )

    # ========================================================
    # BUILD FOLDER TREE
    # ========================================================

    print(
        "Building folder tree..."
    )

    tree = FolderTreeBuilder().build(
        ai_files
    )

    # ========================================================
    # RESOLVE FOLDER CLUSTERS
    # ========================================================

    resolver = StartingBoundaryResolver(
        tree
    )

    folder_clusters = (
        resolver.resolve()
    )

    folder_file_count = sum(
        node.total_file_count
        for node in folder_clusters
    )

    folder_size = sum(
        node.total_size
        for node in folder_clusters
    )

    # ========================================================
    # BUILD DIRECT FILE CLUSTERS
    # ========================================================

    print(
        "Building direct-file clusters..."
    )

    direct_builder = (
        DirectFileClusterBuilder()
    )

    direct_clusters = (
        direct_builder.build(
            files=ai_files,
            folder_candidates=folder_clusters,
        )
    )

    direct_file_count = sum(
        cluster.file_count
        for cluster in direct_clusters
    )

    direct_size = sum(
        cluster.total_size
        for cluster in direct_clusters
    )

    # ========================================================
    # REPRESENTATION TOTALS
    # ========================================================

    represented_file_count = (
        folder_file_count
        + direct_file_count
    )

    represented_size = (
        folder_size
        + direct_size
    )

    file_difference = (
        source_file_count
        - represented_file_count
    )

    size_difference = (
        source_size
        - represented_size
    )

    file_coverage = (
        represented_file_count
        / source_file_count
        * 100
        if source_file_count
        else 0
    )

    size_coverage = (
        represented_size
        / source_size
        * 100
        if source_size
        else 0
    )

    # ========================================================
    # SOURCE SUMMARY
    # ========================================================

    print("\n" + "=" * 80)
    print("AI_ANALYSIS SOURCE")
    print("=" * 80)

    print(
        f"\nFiles : "
        f"{source_file_count:,}"
    )

    print(
        f"Size  : "
        f"{gb(source_size):.3f} GB"
    )

    # ========================================================
    # FOLDER CLUSTERS
    # ========================================================

    print("\n" + "=" * 80)
    print("FOLDER CLUSTERS")
    print("=" * 80)

    print(
        f"\nClusters : "
        f"{len(folder_clusters):,}"
    )

    print(
        f"Files    : "
        f"{folder_file_count:,}"
    )

    print(
        f"Size     : "
        f"{gb(folder_size):.3f} GB"
    )

    # ========================================================
    # DIRECT FILE CLUSTERS
    # ========================================================

    print("\n" + "=" * 80)
    print("DIRECT FILE CLUSTERS")
    print("=" * 80)

    print(
        f"\nClusters : "
        f"{len(direct_clusters):,}"
    )

    print(
        f"Files    : "
        f"{direct_file_count:,}"
    )

    print(
        f"Size     : "
        f"{gb(direct_size):.3f} GB"
    )

    for index, cluster in enumerate(
        direct_clusters,
        start=1,
    ):

        print(
            f"\n[{index}] "
            f"{cluster.display_name}"
        )

        print(
            f"    Files : "
            f"{cluster.file_count:,}"
        )

        print(
            f"    Size  : "
            f"{gb(cluster.total_size):.3f} GB"
        )

        top_files = (
            cluster.get_top_files(
                limit=5
            )
        )

        if top_files:

            print(
                "    Top files:"
            )

            for file in top_files:

                print(
                    f"      - "
                    f"{file.name:<45} "
                    f"{file.size / (1024 ** 2):>8.2f} MB"
                )

    # ========================================================
    # FINAL COVERAGE
    # ========================================================

    print("\n" + "=" * 80)
    print("FINAL COVERAGE")
    print("=" * 80)

    print(
        f"\nSource files      : "
        f"{source_file_count:,}"
    )

    print(
        f"Represented files : "
        f"{represented_file_count:,}"
    )

    print(
        f"File difference   : "
        f"{file_difference:,}"
    )

    print(
        f"File coverage     : "
        f"{file_coverage:.6f}%"
    )

    print(
        f"\nSource size       : "
        f"{gb(source_size):.6f} GB"
    )

    print(
        f"Represented size  : "
        f"{gb(represented_size):.6f} GB"
    )

    print(
        f"Size difference   : "
        f"{gb(size_difference):.9f} GB"
    )

    print(
        f"Size coverage     : "
        f"{size_coverage:.6f}%"
    )

    # ========================================================
    # FINAL STATUS
    # ========================================================

    print("\n" + "=" * 80)
    print("STATUS")
    print("=" * 80)

    if (
        file_difference == 0
        and size_difference == 0
    ):

        print(
            "\n[OK] AI_ANALYSIS dataset is fully "
            "represented."
        )

        print(
            "[OK] Folder clusters + direct-file "
            "clusters = 100% coverage."
        )

    else:

        print(
            "\n[ERROR] Cluster representation "
            "does not match AI_ANALYSIS source."
        )

        print(
            "Further investigation is required."
        )

    print("\n" + "=" * 80)


if __name__ == "__main__":
    main()