import time

from config.settings import DB_PATH
from database.db import create_connection

from rules_v3 import (
    FileContext,
    StorageClassifier,
    AI_ANALYSIS,
    StandardUserFoldersRule,
    get_protected_rules,
    get_safe_rules,
)

from ai_analysis import (
    FolderTreeBuilder,
)


# ============================================================
# HELPERS
# ============================================================

def gb(size):
    return size / (1024 ** 3)


def create_classifier():

    return StorageClassifier(
        user_rules=[
            StandardUserFoldersRule(),
        ],
        protected_rules=get_protected_rules(),
        safe_rules=get_safe_rules(),
    )


def iter_ai_analysis_files(
    conn,
    classifier,
):
    """
    Stream files from SQLite and yield only files classified
    as AI_ANALYSIS.

    Files are yielded one by one instead of loading the full
    dataset into a Python list.
    """

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        """
    )

    for path, size in cursor:

        size = size or 0

        context = FileContext.create(
            path,
            size,
        )

        result = classifier.classify_context(
            context
        )

        if result.classification == AI_ANALYSIS:

            yield (
                path,
                size,
            )


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 80)
    print("STORAGE MANAGER — AI FOLDER TREE TEST")
    print("=" * 80)

    classifier = create_classifier()

    conn = create_connection(
        DB_PATH
    )

    builder = FolderTreeBuilder()

    print(
        "\nBuilding folder tree from "
        "AI_ANALYSIS files..."
    )

    start = time.perf_counter()

    tree = builder.build(
        iter_ai_analysis_files(
            conn,
            classifier,
        )
    )

    elapsed = (
        time.perf_counter()
        - start
    )

    conn.close()

    # ========================================================
    # INPUT TOTALS
    # ========================================================

    print("\n" + "=" * 80)
    print("TREE INPUT")
    print("=" * 80)

    print(
        f"\nInput files : "
        f"{tree.total_input_files:,}"
    )

    print(
        f"Input size  : "
        f"{gb(tree.total_input_size):.2f} GB"
    )

    print(
        f"Tree nodes  : "
        f"{tree.total_nodes:,}"
    )

    print(
        f"Drive roots : "
        f"{len(tree.roots):,}"
    )

    # ========================================================
    # AGGREGATED TOTALS
    # ========================================================

    aggregated_files, aggregated_size = (
        tree.get_aggregated_totals()
    )

    print("\n" + "=" * 80)
    print("AGGREGATED TREE TOTALS")
    print("=" * 80)

    print(
        f"\nAggregated files : "
        f"{aggregated_files:,}"
    )

    print(
        f"Aggregated size  : "
        f"{gb(aggregated_size):.2f} GB"
    )

    # ========================================================
    # INTEGRITY
    # ========================================================

    file_difference = (
        tree.total_input_files
        - aggregated_files
    )

    size_difference = (
        tree.total_input_size
        - aggregated_size
    )

    print("\n" + "=" * 80)
    print("INTEGRITY")
    print("=" * 80)

    print(
        f"\nFile difference : "
        f"{file_difference:,}"
    )

    print(
        f"Size difference : "
        f"{gb(size_difference):.6f} GB"
    )

    if (
        file_difference == 0
        and size_difference == 0
    ):

        print(
            "\n[OK] Folder tree integrity passed."
        )

    else:

        print(
            "\n[ERROR] Folder tree integrity failed."
        )

    # ========================================================
    # DRIVE ROOTS
    # ========================================================

    print("\n" + "=" * 80)
    print("DRIVE ROOTS")
    print("=" * 80)

    sorted_roots = sorted(
        tree.roots.values(),
        key=lambda node:
            node.total_size,
        reverse=True
    )

    for root in sorted_roots:

        print(
            f"\n{root.path}"
        )

        print(
            f"  Files    : "
            f"{root.total_file_count:,}"
        )

        print(
            f"  Size     : "
            f"{gb(root.total_size):.2f} GB"
        )

        print(
            f"  Children : "
            f"{root.child_count:,}"
        )

    # ========================================================
    # TOP LEVEL FOLDERS
    # ========================================================

    print("\n" + "=" * 80)
    print("TOP LEVEL FOLDERS BY SIZE")
    print("=" * 80)

    top_level_nodes = []

    for root in tree.roots.values():

        top_level_nodes.extend(
            root.children.values()
        )

    top_level_nodes.sort(
        key=lambda node:
            node.total_size,
        reverse=True
    )

    for index, node in enumerate(
        top_level_nodes[:20],
        start=1,
    ):

        print(
            f"\n[{index}] "
            f"{node.path}"
        )

        print(
            f"    Size     : "
            f"{gb(node.total_size):.2f} GB"
        )

        print(
            f"    Files    : "
            f"{node.total_file_count:,}"
        )

        print(
            f"    Children : "
            f"{node.child_count:,}"
        )

    # ========================================================
    # NODE STATISTICS
    # ========================================================

    max_depth = 0
    leaf_nodes = 0
    internal_nodes = 0

    for node in tree.iter_nodes():

        if node.depth > max_depth:
            max_depth = node.depth

        if node.is_leaf:
            leaf_nodes += 1

        else:
            internal_nodes += 1

    print("\n" + "=" * 80)
    print("TREE STATISTICS")
    print("=" * 80)

    print(
        f"\nTotal nodes    : "
        f"{tree.total_nodes:,}"
    )

    print(
        f"Internal nodes : "
        f"{internal_nodes:,}"
    )

    print(
        f"Leaf nodes     : "
        f"{leaf_nodes:,}"
    )

    print(
        f"Maximum depth  : "
        f"{max_depth:,}"
    )

    # ========================================================
    # PERFORMANCE
    # ========================================================

    print("\n" + "=" * 80)
    print("PERFORMANCE")
    print("=" * 80)

    print(
        f"\nFull pipeline time : "
        f"{elapsed:.2f} sec"
    )

    if elapsed:

        print(
            f"DB files/sec       : "
            f"{tree.total_input_files / elapsed:,.0f} "
            f"AI files/sec"
        )

    print("\n" + "=" * 80)


if __name__ == "__main__":
    main()