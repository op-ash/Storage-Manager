from config.settings import DB_PATH
from database.db import create_connection

from rules_v3 import (
    FileContext,
    StorageClassifier,
    AI_ANALYSIS,
    StandardUserFoldersRule,
    get_protected_rules,
    get_safe_rules,
)

from ai_analysis import (
    FolderTreeBuilder,
    StartingBoundaryResolver,
    DirectFileClusterBuilder,
    ClusterSummarizer,
)


# ============================================================
# CONFIG
# ============================================================

TARGET_FOLDER_NAMES = {
    "google",
    "capcut",
    "code",
}

TOP_CHILDREN = 5
TOP_FILES = 5
TOP_EXTENSIONS = 5


# ============================================================
# HELPERS
# ============================================================

def gb(size):
    return size / (1024 ** 3)


def mb(size):
    return size / (1024 ** 2)


def format_size(size):

    if size >= 1024 ** 3:
        return f"{gb(size):.2f} GB"

    return f"{mb(size):.2f} MB"


def create_classifier():

    return StorageClassifier(
        user_rules=[
            StandardUserFoldersRule(),
        ],
        protected_rules=get_protected_rules(),
        safe_rules=get_safe_rules(),
    )


def load_ai_analysis_files(
    conn,
    classifier,
):

    files = []

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        """
    )

    for path, size in cursor:

        size = size or 0

        context = FileContext.create(
            path,
            size,
        )

        result = classifier.classify_context(
            context
        )

        if result.classification == AI_ANALYSIS:

            files.append(
                (
                    path,
                    size,
                )
            )

    return files


# ============================================================
# SUMMARY DISPLAY
# ============================================================

def print_summary(
    summary,
):

    print("\n" + "=" * 80)

    print(
        f"CLUSTER TYPE : "
        f"{summary.cluster_type}"
    )

    print("=" * 80)

    print(
        f"\nName  : "
        f"{summary.name}"
    )

    print(
        f"Path  : "
        f"{summary.path}"
    )

    print(
        f"Size  : "
        f"{format_size(summary.total_size)}"
    )

    print(
        f"Files : "
        f"{summary.total_file_count:,}"
    )

    if summary.cluster_type == "FOLDER":

        print(
            f"\nAnalysis boundary : "
            f"{summary.analysis_path}"
        )

        print(
            f"Analysis size     : "
            f"{format_size(summary.analysis_size)}"
        )

        print(
            f"Drill depth       : "
            f"{summary.drill_depth}"
        )

        if summary.drill_path:

            print(
                "\nAdaptive drill path:"
            )

            for step in summary.drill_path:

                print(
                    f"  {step.parent_name}"
                    f" -> "
                    f"{step.child_name}"
                    f" "
                    f"({step.dominance_ratio * 100:.2f}%)"
                )

        if summary.skipped_siblings:

            print(
                "\nData outside drill path:"
            )

            for skipped in (
                summary.skipped_siblings
            ):

                print(
                    f"  {skipped.parent_path}"
                )

                print(
                    f"    Folders : "
                    f"{skipped.folder_count:,}"
                )

                print(
                    f"    Files   : "
                    f"{skipped.file_count:,}"
                )

                print(
                    f"    Size    : "
                    f"{format_size(skipped.total_size)}"
                )
    # ========================================================
    # DIRECT DATA
    # ========================================================

    print(
        f"\nDirect size  : "
        f"{format_size(summary.direct_size)}"
    )

    print(
        f"Direct files : "
        f"{summary.direct_file_count:,}"
    )

    # ========================================================
    # CHILD FOLDERS
    # ========================================================

    print(
        f"\nChild folders : "
        f"{summary.child_folder_count:,}"
    )

    if summary.top_children:

        print(
            "\nTop child folders:"
        )

        for index, child in enumerate(
            summary.top_children,
            start=1,
        ):

            print(
                f"  {index}. "
                f"{child.name}"
            )

            print(
                f"     Size  : "
                f"{format_size(child.size)}"
            )

            print(
                f"     Files : "
                f"{child.file_count:,}"
            )

    if (
        summary.other_children_size
        or summary.other_children_file_count
    ):

        print(
            "\nOther child folders combined:"
        )

        print(
            f"  Size  : "
            f"{format_size(summary.other_children_size)}"
        )

        print(
            f"  Files : "
            f"{summary.other_children_file_count:,}"
        )

    # ========================================================
    # TOP FILES
    # ========================================================

    if summary.top_files:

        print(
            "\nTop files:"
        )

        for index, file in enumerate(
            summary.top_files,
            start=1,
        ):

            print(
                f"  {index}. "
                f"{file.name}"
            )

            print(
                f"     Size      : "
                f"{format_size(file.size)}"
            )

            print(
                f"     Extension : "
                f"{file.extension}"
            )

    # ========================================================
    # EXTENSIONS
    # ========================================================

    if summary.extensions:

        print(
            "\nTop extensions:"
        )

        for extension in (
            summary.extensions
        ):

            print(
                f"  {extension.extension:<18} "
                f"{extension.file_count:>6,} files | "
                f"{format_size(extension.total_size)}"
            )

    # ========================================================
    # HIDDEN FILE DATA
    # ========================================================

    if summary.other_files_count:

        print(
            "\nOther files:"
        )

        print(
            f"  Files : "
            f"{summary.other_files_count:,}"
        )

        print(
            f"  Size  : "
            f"{format_size(summary.other_files_size)}"
        )


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 80)
    print(
        "STORAGE MANAGER — CLUSTER SUMMARIZER TEST"
    )
    print("=" * 80)

    classifier = create_classifier()

    conn = create_connection(
        DB_PATH
    )

    print(
        "\nLoading AI_ANALYSIS files..."
    )

    ai_files = load_ai_analysis_files(
        conn,
        classifier,
    )

    conn.close()

    print(
        f"AI files loaded : "
        f"{len(ai_files):,}"
    )

    # ========================================================
    # BUILD CLUSTERS
    # ========================================================

    print(
        "\nBuilding folder tree..."
    )

    tree = FolderTreeBuilder().build(
        ai_files
    )

    resolver = StartingBoundaryResolver(
        tree
    )

    folder_clusters = (
        resolver.resolve()
    )

    direct_clusters = (
        DirectFileClusterBuilder().build(
            files=ai_files,
            folder_candidates=folder_clusters,
        )
    )

    print(
        f"Folder clusters      : "
        f"{len(folder_clusters):,}"
    )

    print(
        f"Direct-file clusters : "
        f"{len(direct_clusters):,}"
    )

    # ========================================================
    # SUMMARIZER
    # ========================================================

    summarizer = ClusterSummarizer(
        top_children=TOP_CHILDREN,
        top_files=TOP_FILES,
        top_extensions=TOP_EXTENSIONS,
    )

    # ========================================================
    # TARGET FOLDER CLUSTERS
    # ========================================================

    print("\n" + "=" * 80)
    print("TARGET FOLDER CLUSTERS")
    print("=" * 80)

    matched_folders = []

    for cluster in folder_clusters:

        if (
            cluster.name.lower()
            in TARGET_FOLDER_NAMES
        ):

            matched_folders.append(
                cluster
            )

    matched_folders.sort(
        key=lambda node:
            node.total_size,
        reverse=True,
    )

    for cluster in matched_folders:

        summary = summarizer.summarize(
            cluster
        )

        print_summary(
            summary
        )

    # ========================================================
    # DIRECT FILE CLUSTERS
    # ========================================================

    print("\n" + "=" * 80)
    print("DIRECT FILE CLUSTER SUMMARIES")
    print("=" * 80)

    for cluster in direct_clusters:

        summary = summarizer.summarize(
            cluster
        )

        print_summary(
            summary
        )

    # ========================================================
    # SUMMARY SIZE ESTIMATE
    #
    # This is NOT an exact token count.
    # It simply gives us an idea of how much structured
    # information each cluster contains.
    # ========================================================

    all_test_clusters = (
        matched_folders
        + direct_clusters
    )

    total_summary_items = 0

    for cluster in all_test_clusters:

        summary = summarizer.summarize(
            cluster
        )

        total_summary_items += (
            len(summary.top_children)
            + len(summary.top_files)
            + len(summary.extensions)
        )

    print("\n" + "=" * 80)
    print("SUMMARY COMPACTNESS")
    print("=" * 80)

    print(
        f"\nClusters summarized : "
        f"{len(all_test_clusters):,}"
    )

    print(
        f"Metadata list items : "
        f"{total_summary_items:,}"
    )

    print(
        "\nNOTE:"
    )

    print(
        "Hundreds of thousands of raw files are represented "
        "using only compact cluster metadata."
    )

    print("\n" + "=" * 80)


if __name__ == "__main__":
    main()