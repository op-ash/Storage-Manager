from rules.rules_v2 import get_rules


TEST_PATHS = [

    # --------------------------------------------------------
    # PROTECTION
    # --------------------------------------------------------

    r"C:\Users\aashi\AppData\Local\Programs\SomeApp\app.exe",

    r"C:\Users\aashi\AppData\Local\wsl\disk.vhdx",

    r"C:\Users\aashi\AppData\Local\Docker\data\disk.raw",

    r"C:\Users\aashi\.cache\huggingface\hub\model.bin",


    # --------------------------------------------------------
    # TEMP
    # --------------------------------------------------------

    r"C:\Users\aashi\AppData\Local\Temp\example.tmp",

    r"C:\Windows\Temp\example.tmp",


    # --------------------------------------------------------
    # CRASH
    # --------------------------------------------------------

    r"C:\Users\aashi\AppData\Local\CrashDumps\app.dmp",


    # --------------------------------------------------------
    # CHROMIUM MULTI PROFILE
    # --------------------------------------------------------

    r"C:\Users\aashi\AppData\Local\Google\Chrome\User Data\Default\Cache\data.bin",

    r"C:\Users\aashi\AppData\Local\Google\Chrome\User Data\Profile 7\Code Cache\js\file",

    r"C:\Users\aashi\AppData\Local\BraveSoftware\Brave-Browser\User Data\Profile 12\GPUCache\data",

    r"C:\Users\aashi\AppData\Local\Perplexity\Comet\User Data\My Custom Profile\Cache\data",


    # --------------------------------------------------------
    # ELECTRON-LIKE CACHE
    # --------------------------------------------------------

    r"C:\Users\aashi\AppData\Roaming\Notion\Cache\data",

    r"C:\Users\aashi\AppData\Roaming\Code\Code Cache\js\data",


    # --------------------------------------------------------
    # UNKNOWN
    # --------------------------------------------------------

    r"C:\Users\aashi\AppData\Local\SomeApp\Database\data.db",

]


def analyze(
    path,
    rules
):

    for rule in rules:

        result = rule.match(
            path,
            0
        )

        if result is not None:

            return result

    return None


def main():

    print("=" * 80)

    print(
        "STORAGE MANAGER — RULEBOOK V2 TEST"
    )

    print("=" * 80)


    rules = get_rules()


    print(
        f"\nLoaded rules: {len(rules)}"
    )


    print(
        "\nRule execution order:"
    )


    for rule in rules:

        print(
            f"{rule.priority:3} | "
            f"{rule.rule_id}"
        )


    for path in TEST_PATHS:

        print(
            "\n" + "-" * 80
        )

        print(
            f"PATH: {path}"
        )


        result = analyze(
            path,
            rules
        )


        if result is None:

            print(
                "RESULT     : UNKNOWN"
            )

            continue


        print(
            f"RULE       : "
            f"{result.rule_id}"
        )

        print(
            f"CATEGORY   : "
            f"{result.category}"
        )

        print(
            f"RISK       : "
            f"{result.risk}"
        )

        print(
            f"ACTION     : "
            f"{result.action}"
        )

        print(
            f"CONFIDENCE : "
            f"{result.confidence:.0%}"
        )

        print(
            f"REASON     : "
            f"{result.reason}"
        )


if __name__ == "__main__":

    main()