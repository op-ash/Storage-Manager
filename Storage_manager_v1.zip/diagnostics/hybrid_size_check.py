import os
import time
import mftparser

from config.settings import DRIVE


FOLDER_TO_CHECK = r"C:\ProgramData"

def gb(size):
    return size / (1024 ** 3)


def main():

    print("=" * 65)
    print("MFT HYBRID SIZE CHECK")
    print("=" * 65)

    # ========================================================
    # MFT SCAN
    # ========================================================

    print("\nScanning MFT...")

    start = time.perf_counter()

    entries = mftparser.ScanVolume(
        DRIVE,
        only_active=True,
        microseconds=False
    )

    mft_time = time.perf_counter() - start

    relative_folder = (
        FOLDER_TO_CHECK[2:]
        .rstrip("\\")
        .lower()
        + "\\"
    )

    print(
        f"MFT scan time: "
        f"{mft_time:.2f} sec"
    )

    # ========================================================
    # HYBRID SIZE CALCULATION
    # ========================================================

    print("\nCalculating hybrid size...")

    start = time.perf_counter()

    total_hybrid_size = 0

    total_files = 0

    mft_size_used = 0

    fallback_attempts = 0

    fallback_nonzero = 0

    fallback_still_zero = 0

    fallback_failed = 0


    for entry in entries:

        path = entry[5]

        is_directory = entry[9]

        if not path or is_directory:
            continue

        if not path.lower().startswith(
            relative_folder
        ):
            continue


        total_files += 1

        mft_size = entry[7] or 0

        full_path = DRIVE + path


        # ----------------------------------------------
        # MFT SIZE AVAILABLE
        # ----------------------------------------------

        if mft_size > 0:

            total_hybrid_size += mft_size

            mft_size_used += 1

            continue


        # ----------------------------------------------
        # ZERO-SIZE FALLBACK
        # ----------------------------------------------

        fallback_attempts += 1


        try:

            actual_size = os.path.getsize(
                full_path
            )

            total_hybrid_size += actual_size


            if actual_size > 0:

                fallback_nonzero += 1

            else:

                fallback_still_zero += 1


        except (
            FileNotFoundError,
            PermissionError,
            OSError
        ):

            fallback_failed += 1


    hybrid_time = (
        time.perf_counter()
        - start
    )


    # ========================================================
    # ACTUAL FILESYSTEM CHECK
    # ========================================================

    print("\nCalculating filesystem reference size...")

    start = time.perf_counter()

    filesystem_size = 0

    filesystem_files = 0


    for root, dirs, files in os.walk(
        FOLDER_TO_CHECK
    ):

        for filename in files:

            path = os.path.join(
                root,
                filename
            )

            try:

                filesystem_size += (
                    os.path.getsize(path)
                )

                filesystem_files += 1

            except OSError:

                pass


    filesystem_time = (
        time.perf_counter()
        - start
    )


    # ========================================================
    # RESULTS
    # ========================================================

    difference = abs(
        total_hybrid_size
        - filesystem_size
    )


    print("\n" + "=" * 65)
    print("RESULTS")
    print("=" * 65)


    print(
        f"Total files             : "
        f"{total_files:,}"
    )

    print(
        f"MFT size used directly  : "
        f"{mft_size_used:,}"
    )

    print(
        f"Zero-size fallbacks     : "
        f"{fallback_attempts:,}"
    )

    print(
        f"Fallback fixed non-zero : "
        f"{fallback_nonzero:,}"
    )

    print(
        f"Actually empty files    : "
        f"{fallback_still_zero:,}"
    )

    print(
        f"Fallback failed         : "
        f"{fallback_failed:,}"
    )


    print()


    print(
        f"Hybrid total size       : "
        f"{gb(total_hybrid_size):.4f} GB"
    )

    print(
        f"Filesystem total size   : "
        f"{gb(filesystem_size):.4f} GB"
    )

    print(
        f"Difference              : "
        f"{difference:,} bytes"
    )


    print()


    print(
        f"MFT scan time           : "
        f"{mft_time:.4f} sec"
    )

    print(
        f"Hybrid calculation      : "
        f"{hybrid_time:.4f} sec"
    )

    print(
        f"Filesystem full scan    : "
        f"{filesystem_time:.4f} sec"
    )

    print(
        f"Hybrid total time       : "
        f"{mft_time + hybrid_time:.4f} sec"
    )


    print("\n" + "=" * 65)


    if difference == 0:

        print(
            "SUCCESS: Hybrid size exactly matches filesystem."
        )

    else:

        print(
            "WARNING: Hybrid size does not exactly match filesystem."
        )


if __name__ == "__main__":
    main()