import os
import time
from collections import defaultdict

from config.settings import DB_PATH
from database.db import create_connection

from core.storage_scope import (
    StorageScope,
    StorageScopeClassifier
)

from rules.rules_v2 import get_rules


def gb(size):
    return size / (1024 ** 3)


def analyze(path, size, rules):
    for rule in rules:
        result = rule.match(path, size)

        if result is not None:
            return result

    return None


def get_group(path):
    """
    Groups UNKNOWN technical files into meaningful
    application/storage-level locations.

    Examples:

    C:\\Users\\aashi\\AppData\\Local\\CapCut\\...
        -> C:\\Users\\aashi\\AppData\\Local\\CapCut

    C:\\Users\\aashi\\AppData\\Roaming\\Notion\\...
        -> C:\\Users\\aashi\\AppData\\Roaming\\Notion

    C:\\ProgramData\\NVIDIA Corporation\\...
        -> C:\\ProgramData\\NVIDIA Corporation
    """

    normalized = os.path.normpath(path)

    parts = normalized.split(os.sep)

    lower_parts = [
        part.lower()
        for part in parts
    ]

    # ---------------------------------------------------------
    # USER APPDATA
    # ---------------------------------------------------------

    if "appdata" in lower_parts:

        try:
            appdata_index = lower_parts.index(
                "appdata"
            )

            # Expected:
            # AppData / Local / AppName
            # AppData / Roaming / AppName

            if len(parts) > appdata_index + 2:

                return os.path.join(
                    *parts[
                        :appdata_index + 3
                    ]
                )

        except ValueError:
            pass

    # ---------------------------------------------------------
    # PROGRAMDATA
    # ---------------------------------------------------------

    if (
        len(parts) >= 3
        and lower_parts[1] == "programdata"
    ):

        return os.path.join(
            *parts[:3]
        )

    # ---------------------------------------------------------
    # RECYCLE BIN
    # ---------------------------------------------------------

    if (
        len(parts) >= 2
        and lower_parts[1] == "$recycle.bin"
    ):

        return r"C:\$Recycle.Bin"

    # ---------------------------------------------------------
    # WINDOWS
    # ---------------------------------------------------------

    if (
        len(parts) >= 2
        and lower_parts[1] == "windows"
    ):

        if len(parts) >= 3:

            return os.path.join(
                *parts[:3]
            )

        return r"C:\Windows"

    # ---------------------------------------------------------
    # FALLBACK
    # ---------------------------------------------------------

    if len(parts) >= 3:

        return os.path.join(
            *parts[:3]
        )

    return normalized


def main():

    print("=" * 80)
    print(
        "STORAGE MANAGER — V2 UNKNOWN TECHNICAL BREAKDOWN"
    )
    print("=" * 80)

    conn = create_connection(
        DB_PATH
    )

    classifier = (
        StorageScopeClassifier()
    )

    rules = get_rules()

    groups = defaultdict(
        lambda: {
            "files": 0,
            "size": 0
        }
    )

    total_files = 0
    total_size = 0

    print(
        "\nAnalyzing unknown technical storage..."
    )

    start = time.perf_counter()

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        """
    )

    for path, size in cursor:

        size = size or 0

        # -----------------------------------------------------
        # ONLY TECHNICAL STORAGE
        # -----------------------------------------------------

        scope = classifier.classify(
            path
        )

        if scope != StorageScope.TECHNICAL:
            continue

        # -----------------------------------------------------
        # RUN RULEBOOK V2
        # -----------------------------------------------------

        result = analyze(
            path,
            size,
            rules
        )

        # Already understood by Rulebook
        if result is not None:
            continue

        # -----------------------------------------------------
        # UNKNOWN TECHNICAL DATA
        # -----------------------------------------------------

        total_files += 1
        total_size += size

        group = get_group(
            path
        )

        groups[group]["files"] += 1
        groups[group]["size"] += size

    elapsed = (
        time.perf_counter()
        - start
    )

    sorted_groups = sorted(
        groups.items(),
        key=lambda item:
            item[1]["size"],
        reverse=True
    )

    # =========================================================
    # SUMMARY
    # =========================================================

    print(
        "\n" + "=" * 80
    )

    print(
        "UNKNOWN TECHNICAL SUMMARY"
    )

    print(
        "=" * 80
    )

    print(
        f"\nUnknown files : "
        f"{total_files:,}"
    )

    print(
        f"Unknown size  : "
        f"{gb(total_size):.2f} GB"
    )

    # =========================================================
    # TOP GROUPS
    # =========================================================

    print(
        "\n" + "=" * 80
    )

    print(
        "TOP UNKNOWN TECHNICAL GROUPS"
    )

    print(
        "=" * 80
    )

    for index, (
        path,
        stats
    ) in enumerate(
        sorted_groups[:50],
        start=1
    ):

        share = (
            stats["size"]
            / total_size
            * 100
            if total_size
            else 0
        )

        print(
            f"\n[{index}]"
        )

        print(
            f"Path  : {path}"
        )

        print(
            f"Size  : "
            f"{gb(stats['size']):.2f} GB"
        )

        print(
            f"Files : "
            f"{stats['files']:,}"
        )

        print(
            f"Share : "
            f"{share:.2f}%"
        )

    # =========================================================
    # PERFORMANCE
    # =========================================================

    print(
        "\n" + "=" * 80
    )

    print(
        "PERFORMANCE"
    )

    print(
        "=" * 80
    )

    print(
        f"\nAnalysis time : "
        f"{elapsed:.2f} sec"
    )

    conn.close()


if __name__ == "__main__":
    main()