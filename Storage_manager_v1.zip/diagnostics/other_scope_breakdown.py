import os
import time
from collections import defaultdict

from config.settings import DB_PATH
from core.storage_scope import (
    StorageScope,
    StorageScopeClassifier
)
from database.db import create_connection


def gb(size):
    return size / (1024 ** 3)


def get_group(path):
    """
    Group OTHER files into useful high-level paths.

    Examples:

    C:\\Users\\aashi\\.vscode\\extensions\\...
        -> C:\\Users\\aashi\\.vscode

    C:\\Users\\aashi\\.cache\\huggingface\\...
        -> C:\\Users\\aashi\\.cache

    C:\\Users\\aashi\\somefile.exe
        -> C:\\Users\\aashi\\[ROOT FILES]
    """

    path = os.path.normpath(path)
    parts = path.split(os.sep)

    # C:\Users\<username>\...
    if (
        len(parts) >= 4
        and parts[1].lower() == "users"
    ):
        # File directly inside user profile
        if len(parts) == 4:
            return os.path.join(
                *parts[:3],
                "[ROOT FILES]"
            )

        # Group by first folder under user profile
        return os.path.join(
            *parts[:4]
        )

    # Other locations: group near root
    if len(parts) >= 2:
        return os.path.join(
            *parts[:2]
        )

    return path


def main():

    print("=" * 80)
    print("STORAGE MANAGER — OTHER SCOPE BREAKDOWN")
    print("=" * 80)

    conn = create_connection(DB_PATH)

    classifier = StorageScopeClassifier()

    groups = defaultdict(
        lambda: {
            "files": 0,
            "size": 0
        }
    )

    total_files = 0
    total_size = 0

    print("\nAnalyzing OTHER scope...")

    start = time.perf_counter()

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        """
    )

    for path, size in cursor:

        size = size or 0

        scope = classifier.classify(path)

        if scope != StorageScope.OTHER:
            continue

        total_files += 1
        total_size += size

        group = get_group(path)

        groups[group]["files"] += 1
        groups[group]["size"] += size

    elapsed = time.perf_counter() - start

    sorted_groups = sorted(
        groups.items(),
        key=lambda item: item[1]["size"],
        reverse=True
    )

    print("\n" + "=" * 80)
    print("OTHER SCOPE SUMMARY")
    print("=" * 80)

    print(f"\nFiles : {total_files:,}")
    print(f"Size  : {gb(total_size):.2f} GB")

    print("\n" + "=" * 80)
    print("TOP OTHER STORAGE GROUPS")
    print("=" * 80)

    for index, (path, stats) in enumerate(
        sorted_groups[:50],
        start=1
    ):

        share = (
            stats["size"] / total_size * 100
            if total_size
            else 0
        )

        print(f"\n[{index}]")
        print(f"Path  : {path}")
        print(f"Size  : {gb(stats['size']):.2f} GB")
        print(f"Files : {stats['files']:,}")
        print(f"Share : {share:.2f}%")

    print("\n" + "=" * 80)
    print("PERFORMANCE")
    print("=" * 80)

    print(f"\nAnalysis time : {elapsed:.2f} sec")

    conn.close()


if __name__ == "__main__":
    main()