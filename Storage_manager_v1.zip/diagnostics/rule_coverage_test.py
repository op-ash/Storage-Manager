import time
from collections import defaultdict

from config.settings import DB_PATH
from core.rule_engine import RuleEngine
from database.db import create_connection


def gb(size):
    return size / (1024 ** 3)


def percentage(value, total):
    if total == 0:
        return 0
    return (value / total) * 100


def main():

    print("=" * 75)
    print("STORAGE MANAGER — RULE ENGINE COVERAGE TEST")
    print("=" * 75)

    # ========================================================
    # DATABASE
    # ========================================================

    print("\nOpening SQLite database...")

    conn = create_connection(DB_PATH)

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        """
    )

    # ========================================================
    # RULE ENGINE
    # ========================================================

    engine = RuleEngine()

    # Overall counters

    total_files = 0
    total_size = 0

    matched_files = 0
    matched_size = 0

    unknown_files = 0
    unknown_size = 0

    # Category stats

    category_stats = defaultdict(
        lambda: {
            "files": 0,
            "size": 0
        }
    )

    # Risk stats

    risk_stats = defaultdict(
        lambda: {
            "files": 0,
            "size": 0
        }
    )

    # Individual rule stats

    rule_stats = defaultdict(
        lambda: {
            "files": 0,
            "size": 0
        }
    )

    # ========================================================
    # ANALYSIS
    # ========================================================

    print("\nAnalyzing indexed files with Rule Engine...\n")

    start = time.perf_counter()

    for path, size in cursor:

        size = size or 0

        total_files += 1
        total_size += size

        result = engine.analyze(
            path,
            size
        )

        # ----------------------------------------------------
        # UNKNOWN
        # ----------------------------------------------------

        if result is None:

            unknown_files += 1
            unknown_size += size

            category_stats["UNKNOWN"]["files"] += 1
            category_stats["UNKNOWN"]["size"] += size

            risk_stats["UNKNOWN"]["files"] += 1
            risk_stats["UNKNOWN"]["size"] += size

            continue

        # ----------------------------------------------------
        # MATCHED
        # ----------------------------------------------------

        matched_files += 1
        matched_size += size

        # Category

        category_stats[
            result.category
        ]["files"] += 1

        category_stats[
            result.category
        ]["size"] += size

        # Risk

        risk_stats[
            result.risk_level
        ]["files"] += 1

        risk_stats[
            result.risk_level
        ]["size"] += size

        # Rule

        rule_stats[
            result.rule_id
        ]["files"] += 1

        rule_stats[
            result.rule_id
        ]["size"] += size

    analysis_time = (
        time.perf_counter()
        - start
    )

    # ========================================================
    # OVERALL RESULTS
    # ========================================================

    print("=" * 75)
    print("OVERALL COVERAGE")
    print("=" * 75)

    print(
        f"\nTotal indexed files : "
        f"{total_files:,}"
    )

    print(
        f"Total indexed size  : "
        f"{gb(total_size):.2f} GB"
    )

    print()

    print(
        f"Rule matched files  : "
        f"{matched_files:,} "
        f"({percentage(matched_files, total_files):.2f}%)"
    )

    print(
        f"Rule matched size   : "
        f"{gb(matched_size):.2f} GB "
        f"({percentage(matched_size, total_size):.2f}%)"
    )

    print()

    print(
        f"Unknown files       : "
        f"{unknown_files:,} "
        f"({percentage(unknown_files, total_files):.2f}%)"
    )

    print(
        f"Unknown size        : "
        f"{gb(unknown_size):.2f} GB "
        f"({percentage(unknown_size, total_size):.2f}%)"
    )

    # ========================================================
    # CATEGORY BREAKDOWN
    # ========================================================

    print("\n" + "=" * 75)
    print("CATEGORY BREAKDOWN")
    print("=" * 75)

    sorted_categories = sorted(
        category_stats.items(),
        key=lambda item:
            item[1]["size"],
        reverse=True
    )

    for category, stats in sorted_categories:

        print(
            f"{category:20} | "
            f"{stats['files']:9,} files | "
            f"{gb(stats['size']):10.2f} GB"
        )

    # ========================================================
    # RISK BREAKDOWN
    # ========================================================

    print("\n" + "=" * 75)
    print("RISK BREAKDOWN")
    print("=" * 75)

    sorted_risks = sorted(
        risk_stats.items(),
        key=lambda item:
            item[1]["size"],
        reverse=True
    )

    for risk, stats in sorted_risks:

        print(
            f"{risk:20} | "
            f"{stats['files']:9,} files | "
            f"{gb(stats['size']):10.2f} GB"
        )

    # ========================================================
    # RULE MATCH BREAKDOWN
    # ========================================================

    print("\n" + "=" * 75)
    print("RULE MATCH BREAKDOWN")
    print("=" * 75)

    sorted_rules = sorted(
        rule_stats.items(),
        key=lambda item:
            item[1]["size"],
        reverse=True
    )

    for rule_id, stats in sorted_rules:

        print(
            f"{rule_id:30} | "
            f"{stats['files']:9,} files | "
            f"{gb(stats['size']):10.2f} GB"
        )

    # ========================================================
    # PERFORMANCE
    # ========================================================

    print("\n" + "=" * 75)
    print("PERFORMANCE")
    print("=" * 75)

    print(
        f"\nFiles analyzed : "
        f"{total_files:,}"
    )

    print(
        f"Analysis time  : "
        f"{analysis_time:.4f} sec"
    )

    if analysis_time > 0:

        print(
            f"Files / second : "
            f"{total_files / analysis_time:,.0f}"
        )

    # ========================================================
    # FINAL
    # ========================================================

    print("\n" + "=" * 75)

    print(
        f"CURRENT RULEBOOK FILE COVERAGE: "
        f"{percentage(matched_files, total_files):.2f}%"
    )

    print(
        f"CURRENT RULEBOOK SIZE COVERAGE: "
        f"{percentage(matched_size, total_size):.2f}%"
    )

    print("=" * 75)

    conn.close()


if __name__ == "__main__":
    main()