import os
import time
from collections import defaultdict

from config.settings import DB_PATH
from database.db import create_connection

from rules_v3 import (
    FileContext,
    StorageClassifier,

    SAFE_TO_CLEAN,
    PROTECTED,
    AI_ANALYSIS,
    USER_VERIFICATION,

    StandardUserFoldersRule,
    get_protected_rules,
    get_safe_rules,
)


# ============================================================
# HELPERS
# ============================================================

def gb(size):
    return size / (1024 ** 3)


def mb(size):
    return size / (1024 ** 2)


def get_path_group(path):
    """
    Create a useful high-level grouping for diagnosis.

    Examples:

    C:\\Users\\name\\AppData\\Local\\Google
    C:\\Users\\name\\AppData\\Roaming\\Code
    C:\\ProgramData\\NVIDIA Corporation
    C:\\Users\\name\\Downloads
    """

    normalized = os.path.normpath(
        path
    )

    parts = normalized.replace(
        "/",
        "\\"
    ).split("\\")

    lower_parts = [
        part.lower()
        for part in parts
    ]

    # --------------------------------------------------------
    # USER PROFILE DATA
    # --------------------------------------------------------

    if (
        len(parts) >= 3
        and lower_parts[0].endswith(":")
        and lower_parts[1] == "users"
    ):

        # C:\Users\username\...

        if len(parts) >= 4:

            # AppData
            if (
                lower_parts[3]
                == "appdata"
            ):

                if len(parts) >= 6:

                    return "\\".join(
                        parts[:6]
                    )

                return "\\".join(
                    parts[:4]
                )

            # Standard / other user folders

            return "\\".join(
                parts[:4]
            )

    # --------------------------------------------------------
    # PROGRAMDATA
    # --------------------------------------------------------

    if (
        len(parts) >= 2
        and lower_parts[1]
        == "programdata"
    ):

        if len(parts) >= 3:

            return "\\".join(
                parts[:3]
            )

        return normalized

    # --------------------------------------------------------
    # WINDOWS
    # --------------------------------------------------------

    if (
        len(parts) >= 2
        and lower_parts[1]
        == "windows"
    ):

        if len(parts) >= 3:

            return "\\".join(
                parts[:3]
            )

        return normalized

    # --------------------------------------------------------
    # PROGRAM FILES
    # --------------------------------------------------------

    if len(parts) >= 2:

        if lower_parts[1] in (
            "program files",
            "program files (x86)",
        ):

            if len(parts) >= 3:

                return "\\".join(
                    parts[:3]
                )

            return normalized

    # --------------------------------------------------------
    # FALLBACK
    # --------------------------------------------------------

    if len(parts) >= 3:

        return "\\".join(
            parts[:3]
        )

    return normalized


def create_classifier():

    return StorageClassifier(

        user_rules=[
            StandardUserFoldersRule(),
        ],

        protected_rules=(
            get_protected_rules()
        ),

        safe_rules=(
            get_safe_rules()
        ),
    )


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 80)
    print("STORAGE MANAGER — RULEBOOK V3 FULL DIAGNOSIS")
    print("=" * 80)

    classifier = (
        create_classifier()
    )

    conn = create_connection(
        DB_PATH
    )

    # ========================================================
    # DATA STRUCTURES
    # ========================================================

    total_files = 0
    total_size = 0

    classification_stats = defaultdict(
        lambda: {
            "files": 0,
            "size": 0,
        }
    )

    rule_stats = defaultdict(
        lambda: {
            "files": 0,
            "size": 0,
            "classification": None,
            "category": None,
        }
    )

    path_groups = defaultdict(
        lambda: defaultdict(
            lambda: {
                "files": 0,
                "size": 0,
            }
        )
    )

    samples = defaultdict(
        list
    )

    # Rule conflicts:
    # stores files that independently match
    # more than one deterministic rule.

    conflicts = []

    # ========================================================
    # ANALYSIS
    # ========================================================

    print(
        "\nAnalyzing indexed storage..."
    )

    start = time.perf_counter()

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        """
    )

    for path, size in cursor:

        size = size or 0

        context = FileContext.create(
            path,
            size
        )

        total_files += 1
        total_size += size

        # ----------------------------------------------------
        # FINAL CLASSIFICATION
        # ----------------------------------------------------

        result = (
            classifier.classify_context(
                context
            )
        )

        classification = (
            result.classification
        )

        # ----------------------------------------------------
        # CLASSIFICATION STATS
        # ----------------------------------------------------

        classification_stats[
            classification
        ]["files"] += 1

        classification_stats[
            classification
        ]["size"] += size

        # ----------------------------------------------------
        # RULE STATS
        # ----------------------------------------------------

        rule_stats[
            result.rule_id
        ]["files"] += 1

        rule_stats[
            result.rule_id
        ]["size"] += size

        rule_stats[
            result.rule_id
        ][
            "classification"
        ] = classification

        rule_stats[
            result.rule_id
        ][
            "category"
        ] = result.category

        # ----------------------------------------------------
        # PATH GROUPING
        # ----------------------------------------------------

        group = get_path_group(
            path
        )

        path_groups[
            classification
        ][
            group
        ]["files"] += 1

        path_groups[
            classification
        ][
            group
        ]["size"] += size

        # ----------------------------------------------------
        # SAMPLE PATHS
        # ----------------------------------------------------

        sample_key = (
            classification,
            result.rule_id
        )

        if len(
            samples[
                sample_key
            ]
        ) < 10:

            samples[
                sample_key
            ].append(
                path
            )

        # ----------------------------------------------------
        # CONFLICT DIAGNOSIS
        #
        # Run every deterministic rule independently.
        # This does NOT affect final classification.
        # ----------------------------------------------------

        matched_rules = []

        for rule in (
            classifier.user_rules
            + classifier.protected_rules
            + classifier.safe_rules
        ):

            independent_result = (
                rule.match(
                    context
                )
            )

            if independent_result is not None:

                matched_rules.append(
                    (
                        independent_result.rule_id,
                        independent_result.classification,
                    )
                )

        if len(
            matched_rules
        ) > 1:

            if len(conflicts) < 100:

                conflicts.append(
                    (
                        path,
                        matched_rules,
                    )
                )

    elapsed = (
        time.perf_counter()
        - start
    )

    conn.close()

    # ========================================================
    # GLOBAL SUMMARY
    # ========================================================

    print(
        "\n"
        + "=" * 80
    )

    print(
        "GLOBAL STORAGE SUMMARY"
    )

    print(
        "=" * 80
    )

    print(
        f"\nTotal indexed files : "
        f"{total_files:,}"
    )

    print(
        f"Total indexed size  : "
        f"{gb(total_size):.2f} GB"
    )

    # ========================================================
    # CLASSIFICATION SUMMARY
    # ========================================================

    print(
        "\n"
        + "=" * 80
    )

    print(
        "CLASSIFICATION SUMMARY"
    )

    print(
        "=" * 80
    )

    classification_order = (
        USER_VERIFICATION,
        SAFE_TO_CLEAN,
        PROTECTED,
        AI_ANALYSIS,
    )

    classified_files_check = 0
    classified_size_check = 0

    for classification in (
        classification_order
    ):

        stats = (
            classification_stats.get(
                classification,
                {
                    "files": 0,
                    "size": 0,
                }
            )
        )

        classified_files_check += (
            stats["files"]
        )

        classified_size_check += (
            stats["size"]
        )

        percentage = (
            (
                stats["size"]
                / total_size
            )
            * 100
            if total_size
            else 0
        )

        print(
            f"{classification:<22} | "
            f"{stats['files']:>10,} files | "
            f"{gb(stats['size']):>10.2f} GB | "
            f"{percentage:>6.2f}%"
        )

    # ========================================================
    # INTEGRITY CHECK
    # ========================================================

    print(
        "\n"
        + "=" * 80
    )

    print(
        "CLASSIFICATION INTEGRITY CHECK"
    )

    print(
        "=" * 80
    )

    print(
        f"\nInput files      : "
        f"{total_files:,}"
    )

    print(
        f"Classified files : "
        f"{classified_files_check:,}"
    )

    print(
        f"Difference       : "
        f"{total_files - classified_files_check:,}"
    )

    print(
        f"\nInput size       : "
        f"{gb(total_size):.4f} GB"
    )

    print(
        f"Classified size  : "
        f"{gb(classified_size_check):.4f} GB"
    )

    print(
        f"Size difference  : "
        f"{gb(total_size - classified_size_check):.6f} GB"
    )

    if (
        total_files
        == classified_files_check
        and total_size
        == classified_size_check
    ):

        print(
            "\n[OK] Every indexed file received "
            "exactly one final classification."
        )

    else:

        print(
            "\n[WARNING] Classification totals "
            "do not match indexed storage."
        )

    # ========================================================
    # RULE BREAKDOWN
    # ========================================================

    print(
        "\n"
        + "=" * 80
    )

    print(
        "RULE BREAKDOWN"
    )

    print(
        "=" * 80
    )

    sorted_rules = sorted(
        rule_stats.items(),
        key=lambda item:
            item[1]["size"],
        reverse=True
    )

    for rule_id, stats in (
        sorted_rules
    ):

        print(
            f"{rule_id:<36} | "
            f"{stats['classification']:<20} | "
            f"{stats['files']:>9,} files | "
            f"{gb(stats['size']):>9.2f} GB"
        )

    # ========================================================
    # TOP PATH GROUPS BY CLASSIFICATION
    # ========================================================

    for classification in (
        classification_order
    ):

        print(
            "\n"
            + "=" * 80
        )

        print(
            f"TOP PATH GROUPS — "
            f"{classification}"
        )

        print(
            "=" * 80
        )

        groups = sorted(
            path_groups[
                classification
            ].items(),
            key=lambda item:
                item[1]["size"],
            reverse=True
        )

        if not groups:

            print(
                "\nNo files."
            )

            continue

        for index, (
            group,
            stats
        ) in enumerate(
            groups[:50],
            start=1
        ):

            print(
                f"\n[{index}]"
            )

            print(
                f"Path  : "
                f"{group}"
            )

            print(
                f"Size  : "
                f"{gb(stats['size']):.2f} GB "
                f"({mb(stats['size']):.2f} MB)"
            )

            print(
                f"Files : "
                f"{stats['files']:,}"
            )

    # ========================================================
    # SAMPLE PATHS BY RULE
    # ========================================================

    print(
        "\n"
        + "=" * 80
    )

    print(
        "SAMPLE PATHS BY RULE"
    )

    print(
        "=" * 80
    )

    for (
        classification,
        rule_id
    ), paths in samples.items():

        print(
            f"\n[{classification}] "
            f"{rule_id}"
        )

        for path in paths:

            print(
                f"  {path}"
            )

    # ========================================================
    # RULE CONFLICTS
    # ========================================================

    print(
        "\n"
        + "=" * 80
    )

    print(
        "DETERMINISTIC RULE CONFLICT CHECK"
    )

    print(
        "=" * 80
    )

    print(
        f"\nConflicts found "
        f"(maximum 100 stored): "
        f"{len(conflicts):,}"
    )

    if conflicts:

        print(
            "\nFiles below independently matched "
            "multiple deterministic rules:"
        )

        for path, matches in conflicts:

            print(
                f"\nPATH: {path}"
            )

            for (
                rule_id,
                classification
            ) in matches:

                print(
                    f"  {classification:<20} "
                    f"{rule_id}"
                )

    else:

        print(
            "\n[OK] No sampled deterministic "
            "rule conflicts were found."
        )

    # ========================================================
    # PERFORMANCE
    # ========================================================

    print(
        "\n"
        + "=" * 80
    )

    print(
        "PERFORMANCE"
    )

    print(
        "=" * 80
    )

    print(
        f"\nDiagnosis time : "
        f"{elapsed:.2f} sec"
    )

    if elapsed:

        print(
            f"Files / second: "
            f"{total_files / elapsed:,.0f}"
        )

    print(
        "\n"
        + "=" * 80
    )


if __name__ == "__main__":
    main()