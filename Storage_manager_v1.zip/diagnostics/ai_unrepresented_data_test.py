from config.settings import DB_PATH
from database.db import create_connection

from rules_v3 import (
    FileContext,
    StorageClassifier,
    AI_ANALYSIS,
    StandardUserFoldersRule,
    get_protected_rules,
    get_safe_rules,
)

from ai_analysis import (
    FolderTreeBuilder,
    StartingBoundaryResolver,
)


# ============================================================
# HELPERS
# ============================================================

def gb(size):
    return size / (1024 ** 3)


def mb(size):
    return size / (1024 ** 2)


def create_classifier():

    return StorageClassifier(
        user_rules=[
            StandardUserFoldersRule(),
        ],
        protected_rules=get_protected_rules(),
        safe_rules=get_safe_rules(),
    )


def iter_ai_analysis_files(
    conn,
    classifier,
):
    """
    Yield only AI_ANALYSIS classified files.
    """

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        """
    )

    for path, size in cursor:

        size = size or 0

        context = FileContext.create(
            path,
            size,
        )

        result = classifier.classify_context(
            context
        )

        if result.classification == AI_ANALYSIS:

            yield (
                path,
                size,
            )


# ============================================================
# PATH HELPERS
# ============================================================

def normalize_path(path):

    return (
        StartingBoundaryResolver
        .normalize_path(path)
    )


def is_inside_candidate(
    path,
    candidate_paths,
):
    """
    Check whether a file/folder path belongs to any resolved
    candidate subtree.
    """

    normalized = normalize_path(
        path
    )

    for candidate_path in candidate_paths:

        if normalized == candidate_path:
            return True

        prefix = (
            candidate_path.rstrip("\\")
            + "\\"
        )

        if normalized.startswith(
            prefix
        ):
            return True

    return False


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 80)
    print(
        "STORAGE MANAGER — UNREPRESENTED AI DATA TEST"
    )
    print("=" * 80)

    classifier = create_classifier()

    conn = create_connection(
        DB_PATH
    )

    # ========================================================
    # BUILD TREE
    # ========================================================

    print(
        "\nBuilding AI_ANALYSIS tree..."
    )

    tree = FolderTreeBuilder().build(
        iter_ai_analysis_files(
            conn,
            classifier,
        )
    )

    # ========================================================
    # RESOLVE CANDIDATES
    # ========================================================

    resolver = StartingBoundaryResolver(
        tree
    )

    candidates = resolver.resolve()

    candidate_paths = {
        normalize_path(
            node.path
        )
        for node in candidates
    }

    # ========================================================
    # FIND UNREPRESENTED FILES
    # ========================================================

    print(
        "\nScanning for AI_ANALYSIS files outside "
        "candidate subtrees..."
    )

    missing_files = []

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        """
    )

    for path, size in cursor:

        size = size or 0

        context = FileContext.create(
            path,
            size,
        )

        result = classifier.classify_context(
            context
        )

        if (
            result.classification
            != AI_ANALYSIS
        ):
            continue

        if not is_inside_candidate(
            path,
            candidate_paths,
        ):

            missing_files.append(
                (
                    path,
                    size,
                )
            )

    conn.close()

    # ========================================================
    # SUMMARY
    # ========================================================

    total_missing_size = sum(
        size
        for _, size in missing_files
    )

    print("\n" + "=" * 80)
    print("UNREPRESENTED DATA SUMMARY")
    print("=" * 80)

    print(
        f"\nMissing files : "
        f"{len(missing_files):,}"
    )

    print(
        f"Missing size  : "
        f"{gb(total_missing_size):.3f} GB"
    )

    if not missing_files:

        print(
            "\n[OK] All AI_ANALYSIS files are "
            "represented by candidate subtrees."
        )

        return

    # ========================================================
    # LARGEST MISSING FILES
    # ========================================================

    missing_files.sort(
        key=lambda item:
            item[1],
        reverse=True,
    )

    print("\n" + "=" * 80)
    print("LARGEST UNREPRESENTED FILES")
    print("=" * 80)

    for index, (
        path,
        size,
    ) in enumerate(
        missing_files[:50],
        start=1,
    ):

        if size >= 1024 ** 3:

            size_text = (
                f"{gb(size):.3f} GB"
            )

        else:

            size_text = (
                f"{mb(size):.2f} MB"
            )

        print(
            f"\n[{index}] {size_text}"
        )

        print(
            f"    {path}"
        )

    # ========================================================
    # SIZE CHECK
    # ========================================================

    represented_size = sum(
        node.total_size
        for node in candidates
    )

    represented_files = sum(
        node.total_file_count
        for node in candidates
    )

    reconstructed_size = (
        represented_size
        + total_missing_size
    )

    reconstructed_files = (
        represented_files
        + len(missing_files)
    )

    print("\n" + "=" * 80)
    print("INTEGRITY CHECK")
    print("=" * 80)

    print(
        f"\nAI tree files          : "
        f"{tree.total_input_files:,}"
    )

    print(
        f"Candidate files        : "
        f"{represented_files:,}"
    )

    print(
        f"Unrepresented files    : "
        f"{len(missing_files):,}"
    )

    print(
        f"Reconstructed files    : "
        f"{reconstructed_files:,}"
    )

    print(
        f"\nAI tree size           : "
        f"{gb(tree.total_input_size):.3f} GB"
    )

    print(
        f"Candidate size         : "
        f"{gb(represented_size):.3f} GB"
    )

    print(
        f"Unrepresented size     : "
        f"{gb(total_missing_size):.3f} GB"
    )

    print(
        f"Reconstructed size     : "
        f"{gb(reconstructed_size):.3f} GB"
    )

    file_difference = (
        tree.total_input_files
        - reconstructed_files
    )

    size_difference = (
        tree.total_input_size
        - reconstructed_size
    )

    print(
        f"\nFile difference        : "
        f"{file_difference:,}"
    )

    print(
        f"Size difference        : "
        f"{gb(size_difference):.6f} GB"
    )

    print("\n" + "=" * 80)


if __name__ == "__main__":
    main()