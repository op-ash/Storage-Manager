from core.rule_engine import (
    RuleEngine
)


TEST_PATHS = [

    r"C:\Windows\System32\kernel32.dll",

    r"C:\Windows\Temp\example.tmp",

    r"C:\Users\aashi\AppData\Local\Temp\test.tmp",

    r"C:\Users\aashi\AppData\Local\Google\Chrome\User Data\Default\Cache\data.bin",

    r"C:\Users\aashi\AppData\Local\Google\Chrome\User Data\Profile 7\Code Cache\js\example",

    r"C:\Users\aashi\AppData\Local\SomeUnknownApp\Cache\data.bin",

    r"C:\Users\aashi\AppData\Local\CrashDumps\some_app.dmp",

    r"C:\Users\aashi\Documents\important.docx",

]


def main():

    engine = RuleEngine()


    print(
        "=" * 70
    )

    print(
        "RULE ENGINE TEST"
    )

    print(
        "=" * 70
    )


    for path in TEST_PATHS:

        result = engine.analyze(
            path
        )


        print(
            f"\nPATH:\n{path}"
        )


        if result is None:

            print(
                "RESULT     : UNKNOWN"
            )

            print(
                "NEXT STEP  : AI / Future Rules"
            )

            continue


        print(
            f"RULE       : "
            f"{result.rule_id}"
        )

        print(
            f"CATEGORY   : "
            f"{result.category}"
        )

        print(
            f"RISK       : "
            f"{result.risk_level}"
        )

        print(
            f"ACTION     : "
            f"{result.action}"
        )

        print(
            f"CONFIDENCE : "
            f"{result.confidence:.0%}"
        )

        print(
            f"REASON     : "
            f"{result.reason}"
        )


if __name__ == "__main__":

    main()