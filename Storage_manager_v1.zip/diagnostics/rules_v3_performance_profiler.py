import time
from collections import defaultdict

from config.settings import DB_PATH
from database.db import create_connection

from rules_v3 import (
    FileContext,
    StorageClassifier,
    StandardUserFoldersRule,
    get_protected_rules,
    get_safe_rules,
)


def create_classifier():

    return StorageClassifier(
        user_rules=[
            StandardUserFoldersRule(),
        ],
        protected_rules=get_protected_rules(),
        safe_rules=get_safe_rules(),
    )


def main():

    print("=" * 80)
    print("STORAGE MANAGER — V3 PERFORMANCE PROFILER")
    print("=" * 80)

    classifier = create_classifier()

    conn = create_connection(
        DB_PATH
    )

    # ========================================================
    # TIMERS
    # ========================================================

    sqlite_time = 0.0
    context_time = 0.0
    classification_time = 0.0
    stats_time = 0.0

    total_files = 0

    classification_counts = defaultdict(
        int
    )

    # ========================================================
    # PREPARE CURSOR
    # ========================================================

    cursor_start = time.perf_counter()

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        """
    )

    cursor_prepare_time = (
        time.perf_counter()
        - cursor_start
    )

    # ========================================================
    # FULL PRODUCTION-LIKE LOOP
    # ========================================================

    print(
        "\nProfiling production classification..."
    )

    full_start = time.perf_counter()

    iterator = iter(cursor)

    while True:

        # ----------------------------------------------------
        # SQLITE ROW FETCH
        # ----------------------------------------------------

        fetch_start = time.perf_counter()

        try:
            row = next(iterator)

        except StopIteration:

            sqlite_time += (
                time.perf_counter()
                - fetch_start
            )

            break

        sqlite_time += (
            time.perf_counter()
            - fetch_start
        )

        path, size = row

        size = size or 0

        # ----------------------------------------------------
        # FILE CONTEXT CREATION
        # ----------------------------------------------------

        context_start = (
            time.perf_counter()
        )

        context = FileContext.create(
            path,
            size
        )

        context_time += (
            time.perf_counter()
            - context_start
        )

        # ----------------------------------------------------
        # CLASSIFICATION
        # ----------------------------------------------------

        classify_start = (
            time.perf_counter()
        )

        result = (
            classifier.classify_context(
                context
            )
        )

        classification_time += (
            time.perf_counter()
            - classify_start
        )

        # ----------------------------------------------------
        # RESULT ACCOUNTING
        # ----------------------------------------------------

        stats_start = (
            time.perf_counter()
        )

        classification_counts[
            result.classification
        ] += 1

        total_files += 1

        stats_time += (
            time.perf_counter()
            - stats_start
        )

    full_elapsed = (
        time.perf_counter()
        - full_start
    )

    conn.close()

    # ========================================================
    # CALCULATE LOOP OVERHEAD
    # ========================================================

    measured_work = (
        sqlite_time
        + context_time
        + classification_time
        + stats_time
    )

    loop_overhead = (
        full_elapsed
        - measured_work
    )

    # ========================================================
    # OUTPUT
    # ========================================================

    print("\n" + "=" * 80)
    print("PROFILE RESULTS")
    print("=" * 80)

    print(
        f"\nTotal files              : "
        f"{total_files:,}"
    )

    print(
        f"\nCursor preparation       : "
        f"{cursor_prepare_time:.4f} sec"
    )

    print(
        f"SQLite row fetching      : "
        f"{sqlite_time:.4f} sec"
    )

    print(
        f"FileContext.create       : "
        f"{context_time:.4f} sec"
    )

    print(
        f"classify_context          : "
        f"{classification_time:.4f} sec"
    )

    print(
        f"Stats accounting         : "
        f"{stats_time:.4f} sec"
    )

    print(
        f"Loop/timer overhead      : "
        f"{loop_overhead:.4f} sec"
    )

    print(
        f"\nFULL LOOP TIME           : "
        f"{full_elapsed:.4f} sec"
    )

    # ========================================================
    # PERCENTAGES
    # ========================================================

    print("\n" + "=" * 80)
    print("TIME DISTRIBUTION")
    print("=" * 80)

    components = (
        (
            "SQLite Fetch",
            sqlite_time,
        ),
        (
            "FileContext",
            context_time,
        ),
        (
            "Classification",
            classification_time,
        ),
        (
            "Stats",
            stats_time,
        ),
        (
            "Loop/Timer Overhead",
            loop_overhead,
        ),
    )

    for name, value in components:

        percentage = (
            value
            / full_elapsed
            * 100
            if full_elapsed
            else 0
        )

        print(
            f"{name:<25} | "
            f"{value:>8.4f} sec | "
            f"{percentage:>6.2f}%"
        )

    # ========================================================
    # PER FILE COST
    # ========================================================

    print("\n" + "=" * 80)
    print("PER FILE COST")
    print("=" * 80)

    if total_files:

        print(
            f"\nFileContext.create : "
            f"{context_time / total_files * 1_000_000:.2f} µs/file"
        )

        print(
            f"classify_context    : "
            f"{classification_time / total_files * 1_000_000:.2f} µs/file"
        )

        print(
            f"SQLite fetch       : "
            f"{sqlite_time / total_files * 1_000_000:.2f} µs/file"
        )

        print(
            f"\nOverall            : "
            f"{full_elapsed / total_files * 1_000_000:.2f} µs/file"
        )

    # ========================================================
    # CLASSIFICATION COUNTS
    # ========================================================

    print("\n" + "=" * 80)
    print("CLASSIFICATION COUNTS")
    print("=" * 80)

    for classification, count in (
        classification_counts.items()
    ):

        print(
            f"{classification:<22} | "
            f"{count:>10,}"
        )

    # ========================================================
    # PERFORMANCE
    # ========================================================

    print("\n" + "=" * 80)
    print("OVERALL PERFORMANCE")
    print("=" * 80)

    if full_elapsed:

        print(
            f"\nFiles / second : "
            f"{total_files / full_elapsed:,.0f}"
        )

        print(
            f"Time / 100k    : "
            f"{full_elapsed / total_files * 100000:.2f} sec"
        )

    print("\n" + "=" * 80)


if __name__ == "__main__":
    main()