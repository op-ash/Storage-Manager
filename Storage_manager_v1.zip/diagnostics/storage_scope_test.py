from core.storage_scope import (
    StorageScopeClassifier
)


TEST_PATHS = [

    # --------------------------------------------------------
    # USER DATA
    # --------------------------------------------------------

    r"C:\Users\aashi\Downloads\movie.mp4",

    r"C:\Users\aashi\Documents\resume.pdf",

    r"C:\Users\aashi\Pictures\photo.jpg",

    r"C:\Users\aashi\Videos\video.mp4",

    r"C:\Users\aashi\Desktop\project.zip",

    # --------------------------------------------------------
    # TECHNICAL STORAGE
    # --------------------------------------------------------

    r"C:\Users\aashi\AppData\Local\Google\Chrome\User Data\Default\Cache\data.bin",

    r"C:\Users\aashi\AppData\Roaming\Code\CachedData\file",

    r"C:\ProgramData\NVIDIA Corporation\Downloader\file.exe",

    r"C:\Windows\Temp\example.tmp",

    r"C:\$Recycle.Bin\example.tmp",

    # --------------------------------------------------------
    # OTHER
    # --------------------------------------------------------

    r"C:\RandomFolder\something.bin",

]


def main():

    classifier = (
        StorageScopeClassifier()
    )

    print(
        "=" * 75
    )

    print(
        "STORAGE MANAGER — STORAGE SCOPE TEST"
    )

    print(
        "=" * 75
    )

    for path in TEST_PATHS:

        scope = classifier.classify(
            path
        )

        print()

        print(
            f"PATH  : {path}"
        )

        print(
            f"SCOPE : {scope.value}"
        )


if __name__ == "__main__":

    main()