import os
import time
from collections import defaultdict

from config.settings import DB_PATH
from core.rule_engine import RuleEngine
from database.db import create_connection


# ============================================================
# CONFIGURATION
# ============================================================

TARGET_FOLDERS = [

    r"C:\Users\aashi\AppData\Local\Google",

    r"C:\ProgramData\NVIDIA Corporation",

    r"C:\Users\aashi\AppData\Local\CapCut",

    r"C:\Users\aashi\.cache",

    r"C:\Users\aashi\AppData\Roaming\Code",

    r"C:\Users\aashi\AppData\Local\BraveSoftware",

    r"C:\Users\aashi\AppData\Roaming\Notion",

]


# How many directory levels below target to group
DEPTH = 3

# Results shown per target
TOP_RESULTS = 25


# ============================================================
# HELPERS
# ============================================================

def gb(size):

    return size / (1024 ** 3)


def get_relative_group(
    file_path,
    target_folder,
    depth
):

    """
    Groups a file path N directory levels
    below the selected target folder.

    Example:

    Target:
    C:\\Users\\aashi\\AppData\\Local\\Google

    File:
    C:\\Users\\aashi\\AppData\\Local\\Google\\Chrome\\User Data\\Default\\file

    Depth 3 result:
    Chrome\\User Data\\Default
    """

    relative_path = os.path.relpath(
        file_path,
        target_folder
    )

    parts = relative_path.split(
        os.sep
    )

    # Remove filename
    directory_parts = parts[:-1]


    if not directory_parts:

        return "[ROOT FILES]"


    selected_parts = (
        directory_parts[:depth]
    )


    return os.path.join(
        *selected_parts
    )


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 85)

    print(
        "STORAGE MANAGER — UNKNOWN STORAGE DEEP DIVE"
    )

    print("=" * 85)


    conn = create_connection(
        DB_PATH
    )


    engine = RuleEngine()


    print(
        "\nLoading and analyzing indexed files..."
    )


    start = time.perf_counter()


    # --------------------------------------------------------
    # Prepare stats for every target
    # --------------------------------------------------------

    target_stats = {}


    for target in TARGET_FOLDERS:

        target_stats[target] = {

            "files": 0,

            "size": 0,

            "groups": defaultdict(
                lambda: {
                    "files": 0,
                    "size": 0
                }
            )

        }


    # --------------------------------------------------------
    # Read database
    # --------------------------------------------------------

    cursor = conn.execute(
        """
        SELECT
            path,
            size

        FROM files
        """
    )


    for path, size in cursor:

        size = size or 0


        # ----------------------------------------------------
        # Only UNKNOWN files
        # ----------------------------------------------------

        result = engine.analyze(
            path,
            size
        )


        if result is not None:

            continue


        normalized_path = (
            os.path.normcase(
                os.path.normpath(path)
            )
        )


        # ----------------------------------------------------
        # Check target folders
        # ----------------------------------------------------

        for target in TARGET_FOLDERS:

            normalized_target = (
                os.path.normcase(
                    os.path.normpath(target)
                )
            )


            # Ensure proper directory boundary

            if not (

                normalized_path
                == normalized_target

                or normalized_path.startswith(
                    normalized_target
                    + os.sep
                )

            ):

                continue


            stats = (
                target_stats[target]
            )


            stats["files"] += 1

            stats["size"] += size


            group = get_relative_group(

                path,

                target,

                DEPTH

            )


            stats["groups"][
                group
            ]["files"] += 1


            stats["groups"][
                group
            ]["size"] += size


            # A file should normally belong
            # to only one configured target.

            break


    analysis_time = (

        time.perf_counter()

        - start

    )


    # ========================================================
    # PRINT RESULTS
    # ========================================================

    for target in TARGET_FOLDERS:

        stats = (
            target_stats[target]
        )


        print(
            "\n\n"
            + "=" * 85
        )


        print(
            f"TARGET: {target}"
        )


        print(
            "=" * 85
        )


        print(
            f"\nUnknown files : "
            f"{stats['files']:,}"
        )


        print(
            f"Unknown size  : "
            f"{gb(stats['size']):.2f} GB"
        )


        # ----------------------------------------------------
        # SORT GROUPS
        # ----------------------------------------------------

        sorted_groups = sorted(

            stats["groups"].items(),

            key=lambda item:
                item[1]["size"],

            reverse=True

        )


        print(
            f"\nTOP {TOP_RESULTS} "
            f"UNKNOWN SUBFOLDERS "
            f"(Depth {DEPTH})"
        )


        print(
            "-" * 85
        )


        for index, (
            group,
            group_stats

        ) in enumerate(

            sorted_groups[
                :TOP_RESULTS
            ],

            start=1

        ):


            share = 0


            if stats["size"] > 0:

                share = (

                    group_stats["size"]

                    / stats["size"]

                    * 100

                )


            print(
                f"\n[{index}]"
            )


            print(
                f"Folder : {group}"
            )


            print(
                f"Size   : "
                f"{gb(group_stats['size']):.3f} GB"
            )


            print(
                f"Files  : "
                f"{group_stats['files']:,}"
            )


            print(
                f"Share  : "
                f"{share:.2f}%"
            )


    # ========================================================
    # PERFORMANCE
    # ========================================================

    print(
        "\n\n"
        + "=" * 85
    )


    print(
        "PERFORMANCE"
    )


    print(
        "=" * 85
    )


    print(
        f"\nAnalysis time: "
        f"{analysis_time:.2f} sec"
    )


    print(
        f"Targets analyzed: "
        f"{len(TARGET_FOLDERS)}"
    )


    print(
        f"Grouping depth: "
        f"{DEPTH}"
    )


    print(
        "=" * 85
    )


    conn.close()


if __name__ == "__main__":

    main()