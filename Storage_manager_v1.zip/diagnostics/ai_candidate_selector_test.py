import time

from config.settings import DB_PATH
from database.db import create_connection

from rules_v3 import (
    FileContext,
    StorageClassifier,
    AI_ANALYSIS,
    StandardUserFoldersRule,
    get_protected_rules,
    get_safe_rules,
)

from ai_analysis import (
    FolderTreeBuilder,
    StartingBoundaryResolver,
    AdaptiveCandidateSelector,
)


# ============================================================
# CONFIG
# ============================================================

MAX_CANDIDATES = 20
TARGET_COVERAGE = 0.70
SOFT_MIN_SIZE_MB = 200


# ============================================================
# HELPERS
# ============================================================

def gb(size):
    return size / (1024 ** 3)


def mb(size):
    return size / (1024 ** 2)


def create_classifier():

    return StorageClassifier(
        user_rules=[
            StandardUserFoldersRule(),
        ],
        protected_rules=get_protected_rules(),
        safe_rules=get_safe_rules(),
    )


def iter_ai_analysis_files(
    conn,
    classifier,
):

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        """
    )

    for path, size in cursor:

        size = size or 0

        context = FileContext.create(
            path,
            size,
        )

        result = classifier.classify_context(
            context
        )

        if result.classification == AI_ANALYSIS:

            yield (
                path,
                size,
            )


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 80)
    print(
        "STORAGE MANAGER — ADAPTIVE AI CANDIDATE SELECTOR TEST"
    )
    print("=" * 80)

    print(
        f"\nMax candidates    : {MAX_CANDIDATES}"
    )

    print(
        f"Target coverage   : "
        f"{TARGET_COVERAGE * 100:.0f}%"
    )

    print(
        f"Soft minimum size : "
        f"{SOFT_MIN_SIZE_MB} MB"
    )

    # ========================================================
    # BUILD AI TREE
    # ========================================================

    classifier = create_classifier()

    conn = create_connection(
        DB_PATH
    )

    start = time.perf_counter()

    tree = FolderTreeBuilder().build(
        iter_ai_analysis_files(
            conn,
            classifier,
        )
    )

    conn.close()

    tree_time = (
        time.perf_counter()
        - start
    )

    # ========================================================
    # RESOLVE STARTING POOL
    # ========================================================

    resolver = StartingBoundaryResolver(
        tree
    )

    candidates = resolver.resolve()

    # ========================================================
    # SELECT CANDIDATES
    # ========================================================

    selector = AdaptiveCandidateSelector(
        max_candidates=MAX_CANDIDATES,
        target_coverage=TARGET_COVERAGE,
        soft_min_size_mb=SOFT_MIN_SIZE_MB,
    )

    selection_start = time.perf_counter()

    result = selector.select(
        candidates
    )

    selection_time = (
        time.perf_counter()
        - selection_start
    )

    # ========================================================
    # STARTING POOL
    # ========================================================

    print("\n" + "=" * 80)
    print("STARTING CANDIDATE POOL")
    print("=" * 80)

    print(
        f"\nAvailable folders : "
        f"{result.available_count:,}"
    )

    print(
        f"Available size    : "
        f"{gb(result.available_size):.2f} GB"
    )

    # ========================================================
    # SELECTED CANDIDATES
    # ========================================================

    print("\n" + "=" * 80)
    print("SELECTED AI CANDIDATES")
    print("=" * 80)

    cumulative_size = 0

    for index, node in enumerate(
        result.selected,
        start=1,
    ):

        cumulative_size += (
            node.total_size
        )

        individual_percent = (
            node.total_size
            / result.available_size
            * 100
            if result.available_size
            else 0
        )

        cumulative_percent = (
            cumulative_size
            / result.available_size
            * 100
            if result.available_size
            else 0
        )

        print(
            f"\n[{index}] {node.path}"
        )

        print(
            f"    Size       : "
            f"{gb(node.total_size):.2f} GB"
        )

        print(
            f"    Files      : "
            f"{node.total_file_count:,}"
        )

        print(
            f"    Children   : "
            f"{node.child_count:,}"
        )

        print(
            f"    Pool share : "
            f"{individual_percent:.2f}%"
        )

        print(
            f"    Cumulative : "
            f"{cumulative_percent:.2f}%"
        )

        # Show only a compact preview.
        children = sorted(
            node.children.values(),
            key=lambda child:
                child.total_size,
            reverse=True,
        )

        if children:

            print(
                "    Top children:"
            )

            for child in children[:3]:

                if child.total_size >= (
                    1024 ** 3
                ):

                    size_text = (
                        f"{gb(child.total_size):.2f} GB"
                    )

                else:

                    size_text = (
                        f"{mb(child.total_size):.0f} MB"
                    )

                print(
                    f"      - "
                    f"{child.name:<30} "
                    f"{size_text}"
                )

    # ========================================================
    # SELECTION SUMMARY
    # ========================================================

    print("\n" + "=" * 80)
    print("SELECTION SUMMARY")
    print("=" * 80)

    print(
        f"\nSelected folders : "
        f"{result.selected_count:,}"
    )

    print(
        f"Selected size    : "
        f"{gb(result.selected_size):.2f} GB"
    )

    print(
        f"Pool coverage    : "
        f"{result.coverage * 100:.2f}%"
    )

    unselected_size = (
        result.available_size
        - result.selected_size
    )

    print(
        f"Unselected size  : "
        f"{gb(unselected_size):.2f} GB"
    )

    # ========================================================
    # FULL AI ANALYSIS COVERAGE
    #
    # Important because current StartingBoundaryResolver may
    # not yet represent 100% of AI_ANALYSIS data.
    # ========================================================

    full_ai_size = (
        tree.total_input_size
    )

    full_ai_coverage = (
        result.selected_size
        / full_ai_size
        * 100
        if full_ai_size
        else 0
    )

    unresolved_outside_pool = (
        full_ai_size
        - result.available_size
    )

    print("\n" + "=" * 80)
    print("FULL AI_ANALYSIS PERSPECTIVE")
    print("=" * 80)

    print(
        f"\nTotal AI_ANALYSIS       : "
        f"{gb(full_ai_size):.2f} GB"
    )

    print(
        f"Starting pool           : "
        f"{gb(result.available_size):.2f} GB"
    )

    print(
        f"Selected for next pass  : "
        f"{gb(result.selected_size):.2f} GB"
    )

    print(
        f"Selected vs full AI     : "
        f"{full_ai_coverage:.2f}%"
    )

    print(
        f"Outside starting pool   : "
        f"{gb(unresolved_outside_pool):.2f} GB"
    )

    # ========================================================
    # PERFORMANCE
    # ========================================================

    print("\n" + "=" * 80)
    print("PERFORMANCE")
    print("=" * 80)

    print(
        f"\nTree + classification : "
        f"{tree_time:.2f} sec"
    )

    print(
        f"Candidate selection   : "
        f"{selection_time:.6f} sec"
    )

    print("\n" + "=" * 80)


if __name__ == "__main__":
    main()