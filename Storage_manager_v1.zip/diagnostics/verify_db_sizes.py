import os

from config.settings import DB_PATH
from database.db import create_connection


FILES_TO_CHECK = [
    "Lens_Studio_5.22.1_win_setup.exe",
    "plant_library_for_b3.3+.rar",
    "blender-5.1.2-windows-x64.msi",
]


def format_size(size):
    if size is None:
        return "NULL"

    mb = size / (1024 ** 2)
    gb = size / (1024 ** 3)

    if gb >= 1:
        return f"{gb:.3f} GB"

    return f"{mb:.2f} MB"


def main():

    print("=" * 75)
    print("STORAGE MANAGER — DATABASE SIZE VERIFICATION")
    print("=" * 75)

    conn = create_connection(DB_PATH)

    for filename in FILES_TO_CHECK:

        print(f"\nSearching: {filename}")

        cursor = conn.execute(
            """
            SELECT
                path,
                size
            FROM files
            WHERE path LIKE ?
            """,
            (f"%{filename}",)
        )

        rows = cursor.fetchall()

        if not rows:
            print("NOT FOUND IN DATABASE")
            continue

        for path, db_size in rows:

            print(f"\nPath            : {path}")
            print(f"DB size         : {format_size(db_size)}")
            print(f"DB size bytes   : {db_size:,}")

            # Compare directly with Windows filesystem
            try:
                actual_size = os.path.getsize(path)

                print(
                    f"Filesystem size : "
                    f"{format_size(actual_size)}"
                )

                print(
                    f"Filesystem bytes: "
                    f"{actual_size:,}"
                )

                difference = abs(
                    actual_size - db_size
                )

                print(
                    f"Difference      : "
                    f"{difference:,} bytes"
                )

                if difference == 0:
                    print("RESULT          : EXACT MATCH [OK]")
                else:
                    print("RESULT          : SIZE MISMATCH [WARNING]")

            except OSError as error:

                print(
                    f"Filesystem check failed: {error}"
                )

    conn.close()

    print("\n" + "=" * 75)


if __name__ == "__main__":
    main()