import time

from config.settings import DB_PATH
from database.db import create_connection

from rules.rules_v2 import get_rules
from rules.rules_v2.router import RuleRouter
from rules.rules_v2.context import RuleContext

from analysis import (
    CleanupClassifier,
    CleanupAggregator,
)


def gb(size):
    return size / (1024 ** 3)


def analyze(
    context,
    router
):
    """
    Run only the relevant Rulebook V2 rules
    selected by the RuleRouter.
    """

    relevant_rules = (
        router.get_rules(context)
    )

    for rule in relevant_rules:

        result = rule.match_context(
            context
        )

        if result is not None:
            return result

    return None


def main():

    print("=" * 80)
    print("STORAGE MANAGER — CLEANUP ANALYSIS TEST")
    print("=" * 80)

    # ---------------------------------------------------------
    # INITIALIZE
    # ---------------------------------------------------------

    conn = create_connection(
        DB_PATH
    )

    rules = get_rules()

    router = RuleRouter(
        rules
    )

    classifier = (
        CleanupClassifier()
    )

    aggregator = (
        CleanupAggregator()
    )

    # ---------------------------------------------------------
    # COUNTERS
    # ---------------------------------------------------------

    total_files = 0
    total_size = 0

    unmatched_files = 0
    unmatched_size = 0

    # ---------------------------------------------------------
    # ANALYSIS
    # ---------------------------------------------------------

    print(
        "\nAnalyzing technical storage..."
    )

    start = time.perf_counter()

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        WHERE scope = 'TECHNICAL'
        """
    )

    for path, size in cursor:

        size = size or 0

        context = RuleContext.create(
            path,
            size
        )

        total_files += 1
        total_size += size

        # -----------------------------------------------------
        # RULE ENGINE
        # -----------------------------------------------------

        result = analyze(
            context,
            router
        )

        # -----------------------------------------------------
        # CLASSIFICATION
        # -----------------------------------------------------

        item = classifier.classify(
            context,
            result
        )

        if item is None:

            unmatched_files += 1
            unmatched_size += size

            continue

        # -----------------------------------------------------
        # AGGREGATION
        # -----------------------------------------------------

        aggregator.add(
            item
        )

    elapsed = (
        time.perf_counter()
        - start
    )

    conn.close()

    # ---------------------------------------------------------
    # RESULTS
    # ---------------------------------------------------------

    groups = (
        aggregator.get_groups()
    )

    summary = (
        aggregator.get_action_summary()
    )

    # =========================================================
    # TECHNICAL STORAGE SUMMARY
    # =========================================================

    print(
        "\n"
        + "=" * 80
    )

    print(
        "TECHNICAL STORAGE SUMMARY"
    )

    print(
        "=" * 80
    )

    print(
        f"\nTotal technical files : "
        f"{total_files:,}"
    )

    print(
        f"Total technical size  : "
        f"{gb(total_size):.2f} GB"
    )

    print(
        f"Unmatched files       : "
        f"{unmatched_files:,}"
    )

    print(
        f"Unmatched size        : "
        f"{gb(unmatched_size):.2f} GB"
    )

    # =========================================================
    # ACTION SUMMARY
    # =========================================================

    print(
        "\n"
        + "=" * 80
    )

    print(
        "ACTION SUMMARY"
    )

    print(
        "=" * 80
    )

    for action in (
        "CLEAN",
        "REVIEW",
        "KEEP",
    ):

        stats = summary.get(
            action,
            {
                "files": 0,
                "size": 0,
            }
        )

        print(
            f"{action:<10} | "
            f"{stats['files']:>10,} files | "
            f"{gb(stats['size']):>10.2f} GB"
        )

    # =========================================================
    # SAFE TO CLEAN
    # =========================================================

    print(
        "\n"
        + "=" * 80
    )

    print(
        "SAFE TO CLEAN"
    )

    print(
        "=" * 80
    )

    clean_groups = (
        aggregator.get_groups_by_action(
            "CLEAN"
        )
    )

    for group in clean_groups:

        print(
            f"\n{group.rule_id}"
        )

        print(
            f"  Category   : "
            f"{group.category}"
        )

        print(
            f"  Files      : "
            f"{group.files:,}"
        )

        print(
            f"  Size       : "
            f"{gb(group.size):.2f} GB"
        )

        print(
            f"  Risk       : "
            f"{group.risk}"
        )

        print(
            f"  Confidence : "
            f"{group.confidence:.0%}"
        )

        print(
            f"  Reason     : "
            f"{group.reason}"
        )

    # =========================================================
    # REVIEW
    # =========================================================

    print(
        "\n"
        + "=" * 80
    )

    print(
        "NEEDS REVIEW"
    )

    print(
        "=" * 80
    )

    review_groups = (
        aggregator.get_groups_by_action(
            "REVIEW"
        )
    )

    for group in review_groups:

        print(
            f"\n{group.rule_id}"
        )

        print(
            f"  Category   : "
            f"{group.category}"
        )

        print(
            f"  Files      : "
            f"{group.files:,}"
        )

        print(
            f"  Size       : "
            f"{gb(group.size):.2f} GB"
        )

        print(
            f"  Risk       : "
            f"{group.risk}"
        )

        print(
            f"  Confidence : "
            f"{group.confidence:.0%}"
        )

        print(
            f"  Reason     : "
            f"{group.reason}"
        )

    # =========================================================
    # KEEP / PROTECTED
    # =========================================================

    print(
        "\n"
        + "=" * 80
    )

    print(
        "KEEP / PROTECTED"
    )

    print(
        "=" * 80
    )

    keep_groups = (
        aggregator.get_groups_by_action(
            "KEEP"
        )
    )

    for group in keep_groups:

        print(
            f"\n{group.rule_id}"
        )

        print(
            f"  Category   : "
            f"{group.category}"
        )

        print(
            f"  Files      : "
            f"{group.files:,}"
        )

        print(
            f"  Size       : "
            f"{gb(group.size):.2f} GB"
        )

        print(
            f"  Risk       : "
            f"{group.risk}"
        )

        print(
            f"  Confidence : "
            f"{group.confidence:.0%}"
        )

        print(
            f"  Reason     : "
            f"{group.reason}"
        )

    # =========================================================
    # RECOVERY ESTIMATE
    # =========================================================

    clean_size = summary.get(
        "CLEAN",
        {}
    ).get(
        "size",
        0
    )

    review_size = summary.get(
        "REVIEW",
        {}
    ).get(
        "size",
        0
    )

    print(
        "\n"
        + "=" * 80
    )

    print(
        "STORAGE RECOVERY ESTIMATE"
    )

    print(
        "=" * 80
    )

    print(
        f"\nSafe cleanup now       : "
        f"{gb(clean_size):.2f} GB"
    )

    print(
        f"Additional review data : "
        f"{gb(review_size):.2f} GB"
    )

    print(
        f"Maximum potential      : "
        f"{gb(clean_size + review_size):.2f} GB"
    )

    # =========================================================
    # PERFORMANCE
    # =========================================================

    print(
        "\n"
        + "=" * 80
    )

    print(
        "PERFORMANCE"
    )

    print(
        "=" * 80
    )

    print(
        f"\nAnalysis time : "
        f"{elapsed:.2f} sec"
    )

    if elapsed:

        print(
            f"Files / second: "
            f"{total_files / elapsed:,.0f}"
        )

    print(
        "\n"
        + "=" * 80
    )


if __name__ == "__main__":
    main()