import time

from config.settings import DB_PATH
from database.db import create_connection

from rules_v3 import (
    FileContext,
    StorageClassifier,
    AI_ANALYSIS,
    StandardUserFoldersRule,
    get_protected_rules,
    get_safe_rules,
)

from ai_analysis import (
    FolderTreeBuilder,
    StartingBoundaryResolver,
)


# ============================================================
# CONFIG
# ============================================================

# Change this to inspect another cluster.
#
# Examples:
#
#   "Google"
#   "CapCut"
#   "Microsoft"
#   "NVIDIA Corporation"
#
TARGET_NAME = "Google"

# Maximum number of levels to display below target.
MAX_DEPTH = 8

# Maximum children shown per folder.
TOP_CHILDREN = 15

# Do not expand extremely tiny branches.
# They will still be included in the parent's totals.
MIN_EXPAND_SIZE_MB = 1


# ============================================================
# HELPERS
# ============================================================

def gb(size):
    return size / (1024 ** 3)


def mb(size):
    return size / (1024 ** 2)


def create_classifier():

    return StorageClassifier(
        user_rules=[
            StandardUserFoldersRule(),
        ],
        protected_rules=get_protected_rules(),
        safe_rules=get_safe_rules(),
    )


def iter_ai_analysis_files(
    conn,
    classifier,
):
    """
    Yield ONLY files classified as AI_ANALYSIS.

    SAFE_TO_CLEAN, PROTECTED and USER_VERIFICATION files
    never enter this tree.
    """

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        """
    )

    for path, size in cursor:

        size = size or 0

        context = FileContext.create(
            path,
            size,
        )

        result = classifier.classify_context(
            context
        )

        if result.classification == AI_ANALYSIS:

            yield (
                path,
                size,
            )


# ============================================================
# TARGET SEARCH
# ============================================================

def find_nodes_by_name(
    tree,
    target_name,
):
    """
    Find all FolderNodes whose folder name matches
    TARGET_NAME case-insensitively.

    Multiple matches are returned because folders such as
    'Microsoft' may exist under both Local AppData and
    ProgramData.
    """

    target = target_name.lower()

    matches = []

    for node in tree.iter_nodes():

        if node.name.lower() == target:

            matches.append(
                node
            )

    matches.sort(
        key=lambda node:
            node.total_size,
        reverse=True,
    )

    return matches


# ============================================================
# TREE DISPLAY
# ============================================================

def print_tree(
    node,
    current_depth=0,
    max_depth=MAX_DEPTH,
):
    """
    Recursively display the largest child branches.

    IMPORTANT:

    The node totals represent ONLY AI_ANALYSIS files because
    the tree itself was built exclusively from AI_ANALYSIS.

    Small branches are not expanded, but their storage is
    still included in parent totals.
    """

    indent = "    " * current_depth

    if current_depth == 0:

        print(
            f"\n{node.path}"
        )

        print(
            f"  AI Size  : "
            f"{gb(node.total_size):.3f} GB"
        )

        print(
            f"  AI Files : "
            f"{node.total_file_count:,}"
        )

        print(
            f"  Direct   : "
            f"{mb(node.direct_size):.2f} MB "
            f"/ {node.direct_file_count:,} files"
        )

    if current_depth >= max_depth:
        return

    children = sorted(
        node.children.values(),
        key=lambda child:
            child.total_size,
        reverse=True,
    )

    visible_children = (
        children[:TOP_CHILDREN]
    )

    for child in visible_children:

        child_indent = (
            "    " * (current_depth + 1)
        )

        print(
            f"{child_indent}└─ "
            f"{child.name}"
        )

        print(
            f"{child_indent}   "
            f"Size     : "
            f"{gb(child.total_size):.3f} GB"
        )

        print(
            f"{child_indent}   "
            f"Files    : "
            f"{child.total_file_count:,}"
        )

        print(
            f"{child_indent}   "
            f"Direct   : "
            f"{mb(child.direct_size):.2f} MB "
            f"/ {child.direct_file_count:,} files"
        )

        # Do not expand tiny branches.

        if (
            child.total_size
            >= MIN_EXPAND_SIZE_MB
            * 1024
            * 1024
        ):

            print_tree(
                child,
                current_depth + 1,
                max_depth,
            )

    hidden_children = (
        len(children)
        - len(visible_children)
    )

    if hidden_children > 0:

        hidden_size = sum(
            child.total_size
            for child in children[
                TOP_CHILDREN:
            ]
        )

        hidden_files = sum(
            child.total_file_count
            for child in children[
                TOP_CHILDREN:
            ]
        )

        hidden_indent = (
            "    " * (current_depth + 1)
        )

        print(
            f"{hidden_indent}└─ "
            f"[{hidden_children:,} more children]"
        )

        print(
            f"{hidden_indent}   "
            f"Combined size  : "
            f"{gb(hidden_size):.3f} GB"
        )

        print(
            f"{hidden_indent}   "
            f"Combined files : "
            f"{hidden_files:,}"
        )


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 80)
    print(
        "STORAGE MANAGER — AI TREE DEEP INSPECTOR"
    )
    print("=" * 80)

    print(
        f"\nTarget folder : {TARGET_NAME}"
    )

    print(
        "\nNOTE: This tree contains ONLY "
        "AI_ANALYSIS classified files."
    )

    classifier = create_classifier()

    conn = create_connection(
        DB_PATH
    )

    print(
        "\nBuilding AI_ANALYSIS folder tree..."
    )

    start = time.perf_counter()

    tree = FolderTreeBuilder().build(
        iter_ai_analysis_files(
            conn,
            classifier,
        )
    )

    conn.close()

    build_elapsed = (
        time.perf_counter()
        - start
    )

    # ========================================================
    # FIND TARGETS
    # ========================================================

    matches = find_nodes_by_name(
        tree,
        TARGET_NAME,
    )

    print("\n" + "=" * 80)
    print("TARGET MATCHES")
    print("=" * 80)

    if not matches:

        print(
            f"\nNo AI_ANALYSIS folder named "
            f"'{TARGET_NAME}' was found."
        )

        return

    print(
        f"\nMatches found : "
        f"{len(matches):,}"
    )

    # ========================================================
    # DISPLAY MATCHES
    # ========================================================

    for index, node in enumerate(
        matches,
        start=1,
    ):

        print("\n" + "=" * 80)

        print(
            f"MATCH #{index}"
        )

        print("=" * 80)

        print_tree(
            node
        )

    # ========================================================
    # SUMMARY
    # ========================================================

    total_match_size = sum(
        node.total_size
        for node in matches
    )

    total_match_files = sum(
        node.total_file_count
        for node in matches
    )

    print("\n" + "=" * 80)
    print("MATCH SUMMARY")
    print("=" * 80)

    print(
        f"\nTotal matching folders : "
        f"{len(matches):,}"
    )

    print(
        f"Total AI size          : "
        f"{gb(total_match_size):.3f} GB"
    )

    print(
        f"Total AI files         : "
        f"{total_match_files:,}"
    )

    # ========================================================
    # PERFORMANCE
    # ========================================================

    print("\n" + "=" * 80)
    print("PERFORMANCE")
    print("=" * 80)

    print(
        f"\nTree build + classification : "
        f"{build_elapsed:.2f} sec"
    )

    print("\n" + "=" * 80)


if __name__ == "__main__":
    main()