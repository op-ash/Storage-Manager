import time

from config.settings import DB_PATH
from database.db import create_connection

from rules_v3 import (
    FileContext,
    StorageClassifier,
    AI_ANALYSIS,
    StandardUserFoldersRule,
    get_protected_rules,
    get_safe_rules,
)

from ai_analysis import (
    FolderTreeBuilder,
    StartingBoundaryResolver,
)


def gb(size):
    return size / (1024 ** 3)


def create_classifier():

    return StorageClassifier(
        user_rules=[
            StandardUserFoldersRule(),
        ],
        protected_rules=get_protected_rules(),
        safe_rules=get_safe_rules(),
    )


def iter_ai_analysis_files(
    conn,
    classifier,
):

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        """
    )

    for path, size in cursor:

        size = size or 0

        context = FileContext.create(
            path,
            size,
        )

        result = classifier.classify_context(
            context
        )

        if result.classification == AI_ANALYSIS:

            yield (
                path,
                size,
            )


def main():

    print("=" * 80)
    print(
        "STORAGE MANAGER — AI STARTING CLUSTERS TEST"
    )
    print("=" * 80)

    classifier = create_classifier()

    conn = create_connection(
        DB_PATH
    )

    start = time.perf_counter()

    tree = FolderTreeBuilder().build(
        iter_ai_analysis_files(
            conn,
            classifier,
        )
    )

    conn.close()

    resolver = StartingBoundaryResolver(
        tree
    )

    boundaries = (
        resolver.discover_boundaries()
    )

    candidates = (
        resolver.resolve()
    )

    elapsed = (
        time.perf_counter()
        - start
    )

    # ========================================================
    # DISCOVERED BOUNDARIES
    # ========================================================

    print("\n" + "=" * 80)
    print("DISCOVERED WINDOWS BOUNDARIES")
    print("=" * 80)

    for name, path in boundaries.items():

        node = resolver.find_node(
            path
        )

        status = (
            "FOUND IN TREE"
            if node is not None
            else "NOT PRESENT IN AI TREE"
        )

        print(
            f"\n{name}"
        )

        print(
            f"  Path   : {path}"
        )

        print(
            f"  Status : {status}"
        )

        if node is not None:

            print(
                f"  Size   : "
                f"{gb(node.total_size):.2f} GB"
            )

            print(
                f"  Files  : "
                f"{node.total_file_count:,}"
            )

    # ========================================================
    # STARTING CANDIDATES
    # ========================================================

    print("\n" + "=" * 80)
    print("MEANINGFUL STARTING CLUSTERS")
    print("=" * 80)

    total_candidate_size = sum(
        node.total_size
        for node in candidates
    )

    total_candidate_files = sum(
        node.total_file_count
        for node in candidates
    )

    print(
        f"\nCandidate folders : "
        f"{len(candidates):,}"
    )

    print(
        f"Candidate files   : "
        f"{total_candidate_files:,}"
    )

    print(
        f"Candidate size    : "
        f"{gb(total_candidate_size):.2f} GB"
    )

    # ========================================================
    # TOP 30 CANDIDATES
    # ========================================================

    for index, node in enumerate(
        candidates[:30],
        start=1,
    ):

        print(
            f"\n[{index}] {node.path}"
        )

        print(
            f"    Size     : "
            f"{gb(node.total_size):.2f} GB"
        )

        print(
            f"    Files    : "
            f"{node.total_file_count:,}"
        )

        print(
            f"    Children : "
            f"{node.child_count:,}"
        )

        # Show top 5 direct children so we can inspect
        # whether this candidate is broad/mixed.

        children = sorted(
            node.children.values(),
            key=lambda child:
                child.total_size,
            reverse=True,
        )

        if children:

            print(
                "    Top children:"
            )

            for child in children[:5]:

                print(
                    f"      - "
                    f"{child.name:<30} "
                    f"{gb(child.total_size):>7.2f} GB"
                )

    # ========================================================
    # COVERAGE
    # ========================================================

    ai_total_size = (
        tree.total_input_size
    )

    ai_total_files = (
        tree.total_input_files
    )

    size_coverage = (
        total_candidate_size
        / ai_total_size
        * 100
        if ai_total_size
        else 0
    )

    file_coverage = (
        total_candidate_files
        / ai_total_files
        * 100
        if ai_total_files
        else 0
    )

    print("\n" + "=" * 80)
    print("STARTING POOL COVERAGE")
    print("=" * 80)

    print(
        f"\nTotal AI_ANALYSIS : "
        f"{gb(ai_total_size):.2f} GB"
    )

    print(
        f"Starting pool     : "
        f"{gb(total_candidate_size):.2f} GB"
    )

    print(
        f"Size coverage     : "
        f"{size_coverage:.2f}%"
    )

    print(
        f"\nTotal AI files    : "
        f"{ai_total_files:,}"
    )

    print(
        f"Candidate files   : "
        f"{total_candidate_files:,}"
    )

    print(
        f"File coverage     : "
        f"{file_coverage:.2f}%"
    )

    # ========================================================
    # PERFORMANCE
    # ========================================================

    print("\n" + "=" * 80)
    print("PERFORMANCE")
    print("=" * 80)

    print(
        f"\nFull test time : "
        f"{elapsed:.2f} sec"
    )

    print("\n" + "=" * 80)


if __name__ == "__main__":
    main()