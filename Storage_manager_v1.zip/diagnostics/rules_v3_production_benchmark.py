import time
from collections import defaultdict

from config.settings import DB_PATH
from database.db import create_connection

from rules_v3 import (
    FileContext,
    StorageClassifier,

    SAFE_TO_CLEAN,
    PROTECTED,
    AI_ANALYSIS,
    USER_VERIFICATION,

    StandardUserFoldersRule,
    get_protected_rules,
    get_safe_rules,
)


def gb(size):
    return size / (1024 ** 3)


def create_classifier():

    return StorageClassifier(
        user_rules=[
            StandardUserFoldersRule(),
        ],
        protected_rules=get_protected_rules(),
        safe_rules=get_safe_rules(),
    )


def main():

    print("=" * 80)
    print("STORAGE MANAGER — V3 PRODUCTION CLASSIFICATION BENCHMARK")
    print("=" * 80)

    classifier = create_classifier()

    conn = create_connection(
        DB_PATH
    )

    stats = defaultdict(
        lambda: {
            "files": 0,
            "size": 0,
        }
    )

    rule_stats = defaultdict(
        lambda: {
            "files": 0,
            "size": 0,
        }
    )

    total_files = 0
    total_size = 0

    print(
        "\nRunning production classification..."
    )

    start = time.perf_counter()

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        """
    )

    for path, size in cursor:

        size = size or 0

        context = FileContext.create(
            path,
            size
        )

        result = classifier.classify_context(
            context
        )

        total_files += 1
        total_size += size

        stats[
            result.classification
        ]["files"] += 1

        stats[
            result.classification
        ]["size"] += size

        rule_stats[
            result.rule_id
        ]["files"] += 1

        rule_stats[
            result.rule_id
        ]["size"] += size

    elapsed = (
        time.perf_counter()
        - start
    )

    conn.close()

    # ========================================================
    # SUMMARY
    # ========================================================

    print("\n" + "=" * 80)
    print("CLASSIFICATION SUMMARY")
    print("=" * 80)

    print(
        f"\nTotal files : {total_files:,}"
    )

    print(
        f"Total size  : {gb(total_size):.2f} GB\n"
    )

    classification_order = (
        USER_VERIFICATION,
        SAFE_TO_CLEAN,
        PROTECTED,
        AI_ANALYSIS,
    )

    classified_files = 0
    classified_size = 0

    for classification in classification_order:

        result = stats[
            classification
        ]

        classified_files += (
            result["files"]
        )

        classified_size += (
            result["size"]
        )

        percentage = (
            result["size"]
            / total_size
            * 100
            if total_size
            else 0
        )

        print(
            f"{classification:<22} | "
            f"{result['files']:>10,} files | "
            f"{gb(result['size']):>10.2f} GB | "
            f"{percentage:>6.2f}%"
        )

    # ========================================================
    # RULE SUMMARY
    # ========================================================

    print("\n" + "=" * 80)
    print("RULE SUMMARY")
    print("=" * 80)

    sorted_rules = sorted(
        rule_stats.items(),
        key=lambda item:
            item[1]["size"],
        reverse=True
    )

    for rule_id, result in sorted_rules:

        print(
            f"{rule_id:<38} | "
            f"{result['files']:>10,} files | "
            f"{gb(result['size']):>10.2f} GB"
        )

    # ========================================================
    # INTEGRITY
    # ========================================================

    print("\n" + "=" * 80)
    print("INTEGRITY")
    print("=" * 80)

    print(
        f"\nInput files      : {total_files:,}"
    )

    print(
        f"Classified files : {classified_files:,}"
    )

    print(
        f"Difference       : "
        f"{total_files - classified_files:,}"
    )

    print(
        f"\nSize difference  : "
        f"{gb(total_size - classified_size):.6f} GB"
    )

    # ========================================================
    # PERFORMANCE
    # ========================================================

    print("\n" + "=" * 80)
    print("PRODUCTION PERFORMANCE")
    print("=" * 80)

    print(
        f"\nClassification time : "
        f"{elapsed:.2f} sec"
    )

    if elapsed:

        print(
            f"Files / second      : "
            f"{total_files / elapsed:,.0f}"
        )

        print(
            f"Time / 100k files   : "
            f"{(elapsed / total_files) * 100000:.2f} sec"
        )

    print("\n" + "=" * 80)


if __name__ == "__main__":
    main()