import os
import time
from collections import defaultdict

from config.settings import DB_PATH
from database.db import create_connection

from rules.rules_v2 import get_rules
from rules.rules_v2.router import RuleRouter
from rules.rules_v2.context import RuleContext


TARGET_RULE = "CHROMIUM_CACHE"

CACHE_DIRECTORY_NAMES = {
    "cache",
    "code cache",
    "gpucache",
    "dawncache",
    "grshadercache",
}

SENSITIVE_NAMES = {
    "cookies",
    "history",
    "login data",
    "bookmarks",
    "extensions",
    "local storage",
    "session storage",
    "sessions",
    "web data",
    "preferences",
}


def gb(size):
    return size / (1024 ** 3)


def mb(size):
    return size / (1024 ** 2)


def analyze(context, router):

    relevant_rules = router.get_rules(
        context
    )

    for rule in relevant_rules:

        result = rule.match_context(
            context
        )

        if result is not None:
            return result

    return None


def detect_cache_type(context):

    for part in context.directory_parts:

        if part in CACHE_DIRECTORY_NAMES:
            return part

    return "unknown"


def get_cache_root(context):

    parts = list(
        context.parts
    )

    for index, part in enumerate(parts):

        if part in CACHE_DIRECTORY_NAMES:

            return os.sep.join(
                parts[:index + 1]
            )

    return os.path.dirname(
        context.path
    )


def main():

    print("=" * 80)
    print("STORAGE MANAGER — CHROMIUM CACHE SAFETY AUDIT")
    print("=" * 80)

    conn = create_connection(
        DB_PATH
    )

    rules = get_rules()

    router = RuleRouter(
        rules
    )

    total_files = 0
    total_size = 0

    cache_types = defaultdict(
        lambda: {
            "files": 0,
            "size": 0,
        }
    )

    cache_roots = defaultdict(
        lambda: {
            "files": 0,
            "size": 0,
        }
    )

    samples = defaultdict(
        list
    )

    sensitive_matches = []

    start = time.perf_counter()

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        WHERE scope = 'TECHNICAL'
        """
    )

    for path, size in cursor:

        size = size or 0

        context = RuleContext.create(
            path,
            size
        )

        result = analyze(
            context,
            router
        )

        if result is None:
            continue

        if result.rule_id != TARGET_RULE:
            continue

        total_files += 1
        total_size += size

        cache_type = detect_cache_type(
            context
        )

        cache_types[
            cache_type
        ]["files"] += 1

        cache_types[
            cache_type
        ]["size"] += size

        cache_root = get_cache_root(
            context
        )

        cache_roots[
            cache_root
        ]["files"] += 1

        cache_roots[
            cache_root
        ]["size"] += size

        if len(
            samples[cache_type]
        ) < 5:

            samples[
                cache_type
            ].append(
                context.path
            )

        # -----------------------------------------------------
        # SAFETY CHECK
        # -----------------------------------------------------

        for part in context.parts:

            if part in SENSITIVE_NAMES:

                sensitive_matches.append(
                    context.path
                )

                break

    elapsed = (
        time.perf_counter()
        - start
    )

    conn.close()

    # =========================================================
    # SUMMARY
    # =========================================================

    print("\n" + "=" * 80)
    print("MATCH SUMMARY")
    print("=" * 80)

    print(
        f"\nMatched files : "
        f"{total_files:,}"
    )

    print(
        f"Matched size  : "
        f"{gb(total_size):.2f} GB"
    )

    # =========================================================
    # CACHE TYPE BREAKDOWN
    # =========================================================

    print("\n" + "=" * 80)
    print("CACHE TYPE BREAKDOWN")
    print("=" * 80)

    sorted_types = sorted(
        cache_types.items(),
        key=lambda item:
            item[1]["size"],
        reverse=True
    )

    for cache_type, stats in sorted_types:

        print(
            f"{cache_type:<20} | "
            f"{stats['files']:>10,} files | "
            f"{gb(stats['size']):>10.2f} GB"
        )

    # =========================================================
    # TOP CACHE ROOTS
    # =========================================================

    print("\n" + "=" * 80)
    print("TOP 50 MATCHED CACHE ROOTS")
    print("=" * 80)

    sorted_roots = sorted(
        cache_roots.items(),
        key=lambda item:
            item[1]["size"],
        reverse=True
    )

    for index, (
        root,
        stats
    ) in enumerate(
        sorted_roots[:50],
        start=1
    ):

        print(
            f"\n[{index}]"
        )

        print(
            f"Path  : {root}"
        )

        print(
            f"Size  : {gb(stats['size']):.4f} GB "
            f"({mb(stats['size']):.2f} MB)"
        )

        print(
            f"Files : {stats['files']:,}"
        )

    # =========================================================
    # SAMPLE PATHS
    # =========================================================

    print("\n" + "=" * 80)
    print("SAMPLE MATCHED PATHS")
    print("=" * 80)

    for cache_type, paths in samples.items():

        print(
            f"\n[{cache_type}]"
        )

        for path in paths:

            print(
                f"  {path}"
            )

    # =========================================================
    # SENSITIVE PATH CHECK
    # =========================================================

    print("\n" + "=" * 80)
    print("SENSITIVE PATH CHECK")
    print("=" * 80)

    print(
        f"\nSensitive-name matches : "
        f"{len(sensitive_matches):,}"
    )

    if sensitive_matches:

        print(
            "\nWARNING:"
        )

        print(
            "Some CHROMIUM_CACHE results also contain "
            "a sensitive directory/file name."
        )

        print(
            "\nFirst 50 matches:"
        )

        for path in sensitive_matches[:50]:

            print(
                f"  {path}"
            )

    else:

        print(
            "\n[OK] No known sensitive path names were "
            "found inside CHROMIUM_CACHE matches."
        )

    # =========================================================
    # PERFORMANCE
    # =========================================================

    print("\n" + "=" * 80)
    print("PERFORMANCE")
    print("=" * 80)

    print(
        f"\nAudit time : "
        f"{elapsed:.2f} sec"
    )

    print("\n" + "=" * 80)


if __name__ == "__main__":
    main()