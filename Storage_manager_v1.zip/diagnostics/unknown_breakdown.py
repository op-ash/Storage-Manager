import os
import time
from collections import defaultdict

from config.settings import DB_PATH
from core.rule_engine import RuleEngine
from database.db import create_connection


def gb(size):
    return size / (1024 ** 3)


def get_group_path(path):
    """
    Groups unknown files into meaningful high-level areas.

    Examples:
    C:\\Users\\name\\Downloads\\...
        -> C:\\Users\\name\\Downloads

    C:\\Users\\name\\AppData\\Local\\Google\\...
        -> C:\\Users\\name\\AppData\\Local\\Google

    C:\\ProgramData\\NVIDIA Corporation\\...
        -> C:\\ProgramData\\NVIDIA Corporation
    """

    normalized = os.path.normpath(path)

    parts = normalized.split(os.sep)

    if len(parts) < 2:
        return normalized

    lower_parts = [
        part.lower()
        for part in parts
    ]

    # --------------------------------------------------------
    # PROGRAM DATA
    # C:\ProgramData\<Company/App>
    # --------------------------------------------------------

    if (
        len(parts) >= 3
        and lower_parts[1] == "programdata"
    ):
        return os.sep.join(
            parts[:3]
        )

    # --------------------------------------------------------
    # USER DATA
    # C:\Users\<username>\...
    # --------------------------------------------------------

    if (
        len(parts) >= 4
        and lower_parts[1] == "users"
    ):

        # AppData
        if (
            len(parts) >= 6
            and lower_parts[3] == "appdata"
        ):

            # AppData\Local\<App>
            # AppData\Roaming\<App>

            return os.sep.join(
                parts[:6]
            )

        # Downloads, Documents, OneDrive, etc.

        return os.sep.join(
            parts[:4]
        )

    # --------------------------------------------------------
    # OTHER ROOT LOCATIONS
    # --------------------------------------------------------

    return os.sep.join(
        parts[:2]
    )


def main():

    print("=" * 80)
    print("STORAGE MANAGER — UNKNOWN DATA BREAKDOWN")
    print("=" * 80)

    conn = create_connection(
        DB_PATH
    )

    engine = RuleEngine()

    groups = defaultdict(
        lambda: {
            "files": 0,
            "size": 0
        }
    )

    total_unknown_files = 0
    total_unknown_size = 0

    print(
        "\nAnalyzing UNKNOWN files..."
    )

    start = time.perf_counter()

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        """
    )

    for path, size in cursor:

        size = size or 0

        result = engine.analyze(
            path,
            size
        )

        # Already understood by Rulebook
        if result is not None:
            continue

        total_unknown_files += 1
        total_unknown_size += size

        group = get_group_path(
            path
        )

        groups[group]["files"] += 1
        groups[group]["size"] += size

    analysis_time = (
        time.perf_counter()
        - start
    )

    # --------------------------------------------------------
    # SORT BY SIZE
    # --------------------------------------------------------

    sorted_groups = sorted(
        groups.items(),
        key=lambda item:
            item[1]["size"],
        reverse=True
    )

    # --------------------------------------------------------
    # RESULTS
    # --------------------------------------------------------

    print(
        "\n" + "=" * 80
    )

    print(
        "UNKNOWN SUMMARY"
    )

    print(
        "=" * 80
    )

    print(
        f"\nUnknown files : "
        f"{total_unknown_files:,}"
    )

    print(
        f"Unknown size  : "
        f"{gb(total_unknown_size):.2f} GB"
    )

    print(
        f"Analysis time : "
        f"{analysis_time:.2f} sec"
    )

    # --------------------------------------------------------
    # TOP GROUPS
    # --------------------------------------------------------

    print(
        "\n" + "=" * 80
    )

    print(
        "TOP 50 UNKNOWN STORAGE GROUPS"
    )

    print(
        "=" * 80
    )

    for index, (
        path,
        stats
    ) in enumerate(
        sorted_groups[:50],
        start=1
    ):

        percent = 0

        if total_unknown_size > 0:

            percent = (
                stats["size"]
                / total_unknown_size
                * 100
            )

        print(
            f"\n[{index}]"
        )

        print(
            f"Path  : {path}"
        )

        print(
            f"Size  : {gb(stats['size']):.2f} GB"
        )

        print(
            f"Files : {stats['files']:,}"
        )

        print(
            f"Share : {percent:.2f}%"
        )

    conn.close()


if __name__ == "__main__":
    main()