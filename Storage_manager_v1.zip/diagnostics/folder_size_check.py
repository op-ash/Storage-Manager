import os
import time
import sqlite3
import mftparser

from config.settings import (
    DRIVE,
    DB_PATH
)


# ============================================================
# CONFIG
# ============================================================

FOLDER_TO_CHECK = (
    r"C:\Users\aashi\Downloads"
)


def format_size(size_bytes):

    return (
        size_bytes
        / 1024
        / 1024
        / 1024
    )


# ============================================================
# METHOD 1 — RAW MFT
# ============================================================

def check_mft(folder_path):

    print("\n[1] Scanning RAW MFT...")

    start = time.perf_counter()

    entries = mftparser.ScanVolume(
        DRIVE,
        only_active=True,
        microseconds=False
    )

    scan_time = (
        time.perf_counter()
        - start
    )


    # mftparser paths:
    #
    # \Users\aashi\Downloads\...
    #
    # Remove C:
    # for comparison

    relative_folder = (
        folder_path[2:]
        .rstrip("\\")
        .lower()
    )

    prefix = (
        relative_folder
        + "\\"
    )


    total_size = 0

    file_count = 0

    zero_size_files = 0


    for entry in entries:

        path = entry[5]

        size = entry[7]

        is_directory = entry[9]


        if not path:

            continue


        if is_directory:

            continue


        p = path.lower()


        if p.startswith(prefix):

            file_count += 1

            file_size = (
                size or 0
            )

            total_size += (
                file_size
            )


            if file_size == 0:

                zero_size_files += 1


    print(
        f"RAW MFT files     : "
        f"{file_count:,}"
    )

    print(
        f"RAW MFT size      : "
        f"{format_size(total_size):.2f} GB"
    )

    print(
        f"Zero-size entries : "
        f"{zero_size_files:,}"
    )

    print(
        f"MFT scan time     : "
        f"{scan_time:.2f} sec"
    )


    return {
        "size": total_size,
        "files": file_count,
        "zero": zero_size_files
    }


# ============================================================
# METHOD 2 — SQLITE FILE TABLE
# ============================================================

def check_sqlite_files(
    folder_path
):

    print(
        "\n[2] Checking SQLite files table..."
    )


    conn = sqlite3.connect(
        DB_PATH
    )


    # Match everything below:
    #
    # C:\Users\aashi\Downloads\

    prefix = (
        folder_path.rstrip("\\")
        + "\\%"
    )


    cursor = conn.execute(
        """
        SELECT
            COUNT(*),
            COALESCE(
                SUM(size),
                0
            )

        FROM files

        WHERE path LIKE ?
        """,
        (prefix,)
    )


    count, total_size = (
        cursor.fetchone()
    )


    conn.close()


    print(
        f"SQLite files      : "
        f"{count:,}"
    )

    print(
        f"SQLite size       : "
        f"{format_size(total_size):.2f} GB"
    )


    return {
        "size": total_size,
        "files": count
    }


# ============================================================
# METHOD 3 — FOLDERS TABLE
# ============================================================

def check_folder_table(
    folder_path
):

    print(
        "\n[3] Checking folders table..."
    )


    conn = sqlite3.connect(
        DB_PATH
    )


    cursor = conn.execute(
        """
        SELECT
            total_size,
            total_file_count,
            direct_size,
            direct_file_count

        FROM folders

        WHERE path = ?
        """,
        (folder_path,)
    )


    row = cursor.fetchone()


    conn.close()


    if row is None:

        print(
            "Folder not found "
            "in folders table."
        )

        return None


    (
        total_size,
        total_count,
        direct_size,
        direct_count

    ) = row


    print(
        f"Folder total files: "
        f"{total_count:,}"
    )

    print(
        f"Folder total size : "
        f"{format_size(total_size):.2f} GB"
    )

    print(
        f"Direct files      : "
        f"{direct_count:,}"
    )

    print(
        f"Direct size       : "
        f"{format_size(direct_size):.2f} GB"
    )


    return {
        "size": total_size,
        "files": total_count
    }


# ============================================================
# METHOD 4 — ACTUAL FILESYSTEM
# ============================================================

def check_filesystem(
    folder_path
):

    print(
        "\n[4] Scanning actual filesystem..."
    )


    start = time.perf_counter()


    total_size = 0

    file_count = 0

    errors = 0


    for root, dirs, files in os.walk(
        folder_path
    ):

        for filename in files:

            full_path = os.path.join(
                root,
                filename
            )


            try:

                size = os.path.getsize(
                    full_path
                )

                total_size += size

                file_count += 1


            except (
                PermissionError,
                FileNotFoundError,
                OSError
            ):

                errors += 1


    elapsed = (
        time.perf_counter()
        - start
    )


    print(
        f"Filesystem files  : "
        f"{file_count:,}"
    )

    print(
        f"Filesystem size   : "
        f"{format_size(total_size):.2f} GB"
    )

    print(
        f"Read errors       : "
        f"{errors:,}"
    )

    print(
        f"Filesystem time   : "
        f"{elapsed:.2f} sec"
    )


    return {
        "size": total_size,
        "files": file_count,
        "errors": errors
    }


# ============================================================
# COMPARISON
# ============================================================

def compare_results(
    mft,
    sqlite_files,
    folder_table,
    filesystem
):

    print(
        "\n" + "=" * 65
    )

    print(
        "COMPARISON"
    )

    print(
        "=" * 65
    )


    print(
        f"{'Method':<20}"
        f"{'Files':>15}"
        f"{'Size GB':>15}"
    )


    print(
        "-" * 50
    )


    print(
        f"{'RAW MFT':<20}"
        f"{mft['files']:>15,}"
        f"{format_size(mft['size']):>15.2f}"
    )


    print(
        f"{'SQLite files':<20}"
        f"{sqlite_files['files']:>15,}"
        f"{format_size(sqlite_files['size']):>15.2f}"
    )


    if folder_table:

        print(
            f"{'Folders table':<20}"
            f"{folder_table['files']:>15,}"
            f"{format_size(folder_table['size']):>15.2f}"
        )


    print(
        f"{'Filesystem':<20}"
        f"{filesystem['files']:>15,}"
        f"{format_size(filesystem['size']):>15.2f}"
    )


# ============================================================
# MAIN
# ============================================================

def main():

    print(
        "=" * 65
    )

    print(
        "STORAGE MANAGER — FOLDER SIZE DIAGNOSTIC"
    )

    print(
        "=" * 65
    )


    print(
        f"\nFolder:"
        f"\n{FOLDER_TO_CHECK}"
    )


    mft = check_mft(
        FOLDER_TO_CHECK
    )


    sqlite_files = (
        check_sqlite_files(
            FOLDER_TO_CHECK
        )
    )


    folder_table = (
        check_folder_table(
            FOLDER_TO_CHECK
        )
    )


    filesystem = (
        check_filesystem(
            FOLDER_TO_CHECK
        )
    )


    compare_results(
        mft,
        sqlite_files,
        folder_table,
        filesystem
    )


if __name__ == "__main__":

    main()