from ai_analysis.provider_settings import (
    AIProviderSettings,
    APIKeyStore,
)

from ai_analysis.provider_factory import (
    AIProviderFactory,
)


def main():

    print("=" * 70)
    print(
        "STORAGE MANAGER — AI PROVIDER FACTORY TEST"
    )
    print("=" * 70)

    # ========================================================
    # SETTINGS
    # ========================================================

    settings = (
        AIProviderSettings()
    )

    key_store = (
        APIKeyStore()
    )

    # Example user preference:
    #
    # Groq first
    # Gemini second
    # OpenRouter third

    settings.set_default_provider(
        "groq"
    )

    settings.set_fallback_order(
        [
            "gemini",
            "openrouter",
        ]
    )

    # ========================================================
    # BUILD REGISTRY
    # ========================================================

    factory = (
        AIProviderFactory(
            settings=settings,
            key_store=key_store,
        )
    )

    registry = (
        factory.build_registry()
    )

    available = (
        registry.get_available()
    )

    # ========================================================
    # OUTPUT
    # ========================================================

    print(
        "\nRequested provider order:"
    )

    for index, provider in enumerate(
        settings.get_provider_order(),
        start=1,
    ):

        print(
            f"{index}. {provider}"
        )

    print(
        "\nConfigured providers:"
    )

    if not available:

        print(
            "[NONE — no configured API keys found]"
        )

    for index, entry in enumerate(
        available,
        start=1,
    ):

        provider = (
            entry.config.provider
        )

        print(
            f"{index}. "
            f"{provider.provider_name}"
            f" | Model: "
            f"{provider.model_name}"
            f" | Priority: "
            f"{entry.config.priority}"
        )

    print(
        "\nAPI key status:"
    )

    for provider_name in (
        settings.get_provider_order()
    ):

        configured = (
            key_store.has_api_key(
                provider_name
            )
        )

        print(
            f"{provider_name:12} | "
            f"{'CONFIGURED' if configured else 'NOT SET'}"
        )

    print(
        "\n" + "=" * 70
    )


if __name__ == "__main__":
    main()