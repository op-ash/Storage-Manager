from ai_analysis.provider_settings import (
    AIProviderSettings,
    APIKeyStore,
)


def main():

    print("=" * 70)
    print("STORAGE MANAGER — AI PROVIDER SETTINGS TEST")
    print("=" * 70)

    settings = (
        AIProviderSettings()
    )

    key_store = (
        APIKeyStore()
    )

    # ========================================================
    # PROVIDER ORDER
    # ========================================================

    settings.set_default_provider(
        "groq"
    )

    settings.set_fallback_order(
        [
            "gemini",
            "openrouter",
        ]
    )

    print("\nProvider order:")

    for index, provider in enumerate(
        settings.get_provider_order(),
        start=1,
    ):

        print(
            f"{index}. {provider}"
        )

    # ========================================================
    # API KEY STATUS
    # ========================================================

    print("\nAPI key status:")

    for provider in (
        settings.get_provider_order()
    ):

        has_key = (
            key_store.has_api_key(
                provider
            )
        )

        masked_key = (
            key_store.get_masked_key(
                provider
            )
        )

        print(
            f"{provider:12} | "
            f"Configured: {has_key} | "
            f"Key: {masked_key or '[NOT SET]'}"
        )

    print("\n" + "=" * 70)


if __name__ == "__main__":
    main()