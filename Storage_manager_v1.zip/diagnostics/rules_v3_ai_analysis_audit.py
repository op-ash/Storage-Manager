import os
import time
from collections import defaultdict

from config.settings import DB_PATH
from database.db import create_connection

from rules_v3 import (
    FileContext,
    StorageClassifier,
    AI_ANALYSIS,
    StandardUserFoldersRule,
    get_protected_rules,
    get_safe_rules,
)


def gb(size):
    return size / (1024 ** 3)


def mb(size):
    return size / (1024 ** 2)


def create_classifier():

    return StorageClassifier(
        user_rules=[
            StandardUserFoldersRule(),
        ],
        protected_rules=get_protected_rules(),
        safe_rules=get_safe_rules(),
    )


def get_group(path):
    """
    Groups AI_ANALYSIS files into useful application-level
    or high-level storage locations.

    Examples:

    C:\\Users\\aashi\\AppData\\Local\\Google
    C:\\Users\\aashi\\AppData\\Roaming\\Code
    C:\\Users\\aashi\\.cache
    C:\\ProgramData\\NVIDIA Corporation
    """

    path = os.path.normpath(path)

    parts = [
        part
        for part in path.replace("/", "\\").split("\\")
        if part
    ]

    lower = [
        part.lower()
        for part in parts
    ]

    # --------------------------------------------------------
    # USER PROFILE
    # --------------------------------------------------------

    if (
        len(parts) >= 3
        and lower[1] == "users"
    ):

        # AppData\Local\<App>
        # AppData\Roaming\<App>
        # AppData\LocalLow\<App>

        if (
            len(parts) >= 6
            and lower[3] == "appdata"
        ):

            return "\\".join(
                parts[:6]
            )

        # Hidden/profile-level folders:
        #
        # C:\Users\aashi\.cache
        # C:\Users\aashi\.config
        # etc.

        if len(parts) >= 4:

            return "\\".join(
                parts[:4]
            )

    # --------------------------------------------------------
    # PROGRAMDATA
    # --------------------------------------------------------

    if (
        len(parts) >= 3
        and lower[1] == "programdata"
    ):

        return "\\".join(
            parts[:3]
        )

    # --------------------------------------------------------
    # PROGRAM FILES
    # --------------------------------------------------------

    if (
        len(parts) >= 3
        and lower[1] in (
            "program files",
            "program files (x86)",
        )
    ):

        return "\\".join(
            parts[:3]
        )

    # --------------------------------------------------------
    # WINDOWS
    # --------------------------------------------------------

    if (
        len(parts) >= 3
        and lower[1] == "windows"
    ):

        return "\\".join(
            parts[:3]
        )

    # --------------------------------------------------------
    # FALLBACK
    # --------------------------------------------------------

    return "\\".join(
        parts[:3]
    )


def main():

    print("=" * 80)
    print("STORAGE MANAGER — V3 AI_ANALYSIS AUDIT")
    print("=" * 80)

    classifier = create_classifier()

    conn = create_connection(
        DB_PATH
    )

    groups = defaultdict(
        lambda: {
            "files": 0,
            "size": 0,
            "largest": [],
        }
    )

    total_ai_files = 0
    total_ai_size = 0

    start = time.perf_counter()

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        """
    )

    for path, size in cursor:

        size = size or 0

        context = FileContext.create(
            path,
            size
        )

        result = classifier.classify_context(
            context
        )

        if result.classification != AI_ANALYSIS:
            continue

        total_ai_files += 1
        total_ai_size += size

        group = get_group(
            path
        )

        data = groups[
            group
        ]

        data["files"] += 1
        data["size"] += size

        # Keep top 10 largest files per group.
        # This diagnostic is intentionally simple.

        data["largest"].append(
            (
                size,
                path,
            )
        )

    elapsed = (
        time.perf_counter()
        - start
    )

    conn.close()

    # ========================================================
    # SUMMARY
    # ========================================================

    print("\n" + "=" * 80)
    print("AI_ANALYSIS SUMMARY")
    print("=" * 80)

    print(
        f"\nFiles : {total_ai_files:,}"
    )

    print(
        f"Size  : {gb(total_ai_size):.2f} GB"
    )

    # ========================================================
    # TOP GROUPS
    # ========================================================

    print("\n" + "=" * 80)
    print("TOP AI_ANALYSIS GROUPS")
    print("=" * 80)

    sorted_groups = sorted(
        groups.items(),
        key=lambda item:
            item[1]["size"],
        reverse=True
    )

    for index, (
        group,
        data
    ) in enumerate(
        sorted_groups[:50],
        start=1
    ):

        share = (
            data["size"]
            / total_ai_size
            * 100
            if total_ai_size
            else 0
        )

        print(
            f"\n[{index}]"
        )

        print(
            f"Path  : {group}"
        )

        print(
            f"Size  : {gb(data['size']):.2f} GB"
        )

        print(
            f"Files : {data['files']:,}"
        )

        print(
            f"Share : {share:.2f}%"
        )

        # ----------------------------------------------------
        # TOP 10 LARGEST FILES
        # ----------------------------------------------------

        largest = sorted(
            data["largest"],
            key=lambda item:
                item[0],
            reverse=True
        )[:10]

        print(
            "Largest files:"
        )

        for file_size, file_path in largest:

            print(
                f"  {mb(file_size):>10.2f} MB | "
                f"{file_path}"
            )

    # ========================================================
    # GROUP TOTAL CHECK
    # ========================================================

    grouped_size = sum(
        data["size"]
        for data in groups.values()
    )

    grouped_files = sum(
        data["files"]
        for data in groups.values()
    )

    print("\n" + "=" * 80)
    print("INTEGRITY")
    print("=" * 80)

    print(
        f"\nAI files       : {total_ai_files:,}"
    )

    print(
        f"Grouped files  : {grouped_files:,}"
    )

    print(
        f"Difference     : "
        f"{total_ai_files - grouped_files:,}"
    )

    print(
        f"\nAI size        : {gb(total_ai_size):.4f} GB"
    )

    print(
        f"Grouped size   : {gb(grouped_size):.4f} GB"
    )

    print(
        f"Size difference: "
        f"{gb(total_ai_size - grouped_size):.6f} GB"
    )

    # ========================================================
    # PERFORMANCE
    # ========================================================

    print("\n" + "=" * 80)
    print("PERFORMANCE")
    print("=" * 80)

    print(
        f"\nAudit time : {elapsed:.2f} sec"
    )

    print("\n" + "=" * 80)


if __name__ == "__main__":
    main()