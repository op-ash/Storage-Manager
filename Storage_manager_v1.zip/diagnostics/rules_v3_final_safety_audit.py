import os
import time
import heapq
from collections import defaultdict

from config.settings import DB_PATH
from database.db import create_connection

from rules_v3 import (
    FileContext,
    StorageClassifier,
    SAFE_TO_CLEAN,
    StandardUserFoldersRule,
    get_protected_rules,
    get_safe_rules,
)


# ============================================================
# CONFIG
# ============================================================

TOP_PATHS = 30
TOP_FILES = 20
SAMPLES_PER_RULE = 10


# ============================================================
# HELPERS
# ============================================================

def gb(size):
    return size / (1024 ** 3)


def mb(size):
    return size / (1024 ** 2)


def create_classifier():

    return StorageClassifier(
        user_rules=[
            StandardUserFoldersRule(),
        ],
        protected_rules=get_protected_rules(),
        safe_rules=get_safe_rules(),
    )


def get_parent_group(path, depth=2):
    """
    Groups files a few directories above the file itself.

    Used only for human-readable safety inspection.
    """

    normalized = path.replace(
        "/",
        "\\"
    )

    parts = [
        part
        for part in normalized.split("\\")
        if part
    ]

    if len(parts) <= depth:
        return normalized

    return "\\".join(
        parts[:-depth]
    )


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 80)
    print("STORAGE MANAGER — RULEBOOK V3 FINAL SAFETY AUDIT")
    print("=" * 80)

    classifier = create_classifier()

    conn = create_connection(
        DB_PATH
    )

    # --------------------------------------------------------
    # STATS
    # --------------------------------------------------------

    total_safe_files = 0
    total_safe_size = 0

    rule_stats = defaultdict(
        lambda: {
            "files": 0,
            "size": 0,
        }
    )

    rule_paths = defaultdict(
        lambda: defaultdict(
            lambda: {
                "files": 0,
                "size": 0,
            }
        )
    )

    samples = defaultdict(
        list
    )

    largest_files = []

    warnings = []

    # --------------------------------------------------------
    # Sensitive browser data that must NEVER be classified
    # as SAFE_TO_CLEAN by the Chromium cache rule.
    # --------------------------------------------------------

    browser_sensitive_names = {
        "cookies",
        "history",
        "login data",
        "bookmarks",
        "extensions",
        "local storage",
        "session storage",
        "sessions",
        "web data",
        "preferences",
    }

    # ========================================================
    # SCAN
    # ========================================================

    print(
        "\nAuditing SAFE_TO_CLEAN classification..."
    )

    start = time.perf_counter()

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        """
    )

    for path, size in cursor:

        size = size or 0

        context = FileContext.create(
            path,
            size
        )

        result = classifier.classify_context(
            context
        )

        if result.classification != SAFE_TO_CLEAN:
            continue

        total_safe_files += 1
        total_safe_size += size

        rule_id = result.rule_id

        # ----------------------------------------------------
        # RULE STATS
        # ----------------------------------------------------

        rule_stats[
            rule_id
        ]["files"] += 1

        rule_stats[
            rule_id
        ]["size"] += size

        # ----------------------------------------------------
        # PATH GROUPS
        # ----------------------------------------------------

        group = get_parent_group(
            path
        )

        rule_paths[
            rule_id
        ][
            group
        ]["files"] += 1

        rule_paths[
            rule_id
        ][
            group
        ]["size"] += size

        # ----------------------------------------------------
        # SAMPLES
        # ----------------------------------------------------

        if len(
            samples[
                rule_id
            ]
        ) < SAMPLES_PER_RULE:

            samples[
                rule_id
            ].append(
                path
            )

        # ----------------------------------------------------
        # GLOBAL TOP LARGEST SAFE FILES
        # ----------------------------------------------------

        item = (
            size,
            total_safe_files,
            path,
            rule_id,
        )

        if len(
            largest_files
        ) < TOP_FILES:

            heapq.heappush(
                largest_files,
                item
            )

        elif size > largest_files[0][0]:

            heapq.heapreplace(
                largest_files,
                item
            )

        # ====================================================
        # SAFETY ASSERTIONS
        # ====================================================

        lower_path = context.lower_path

        # ----------------------------------------------------
        # CHROMIUM CACHE SAFETY
        # ----------------------------------------------------

        if (
            rule_id
            == "SAFE_VERIFIED_CHROMIUM_CACHE"
        ):

            parts = context.parts

            sensitive_found = [
                name
                for name in browser_sensitive_names
                if name in parts
            ]

            if sensitive_found:

                warnings.append(
                    (
                        "CRITICAL_BROWSER_SENSITIVE_DATA",
                        path,
                        (
                            "Sensitive browser path component "
                            f"found: {sensitive_found}"
                        ),
                    )
                )

        # ----------------------------------------------------
        # WINDOWS TEMP BOUNDARY
        # ----------------------------------------------------

        elif (
            rule_id
            == "SAFE_WINDOWS_TEMP"
        ):

            windir = os.environ.get(
                "WINDIR",
                r"C:\Windows"
            )

            expected = (
                os.path.normpath(
                    os.path.join(
                        windir,
                        "Temp"
                    )
                )
                .replace(
                    "/",
                    "\\"
                )
                .lower()
            )

            if not (
                lower_path == expected
                or lower_path.startswith(
                    expected + "\\"
                )
            ):

                warnings.append(
                    (
                        "CRITICAL_WINDOWS_TEMP_BOUNDARY",
                        path,
                        "File escaped expected Windows Temp boundary.",
                    )
                )

        # ----------------------------------------------------
        # USER TEMP BOUNDARY
        # ----------------------------------------------------

        elif (
            rule_id
            == "SAFE_USER_TEMP"
        ):

            temp = os.environ.get(
                "TEMP"
            )

            if temp:

                expected = (
                    os.path.normpath(
                        temp
                    )
                    .replace(
                        "/",
                        "\\"
                    )
                    .lower()
                )

                if not (
                    lower_path == expected
                    or lower_path.startswith(
                        expected + "\\"
                    )
                ):

                    warnings.append(
                        (
                            "CRITICAL_USER_TEMP_BOUNDARY",
                            path,
                            "File escaped expected user Temp boundary.",
                        )
                    )

        # ----------------------------------------------------
        # CRASH DUMP SAFETY
        # ----------------------------------------------------

        elif (
            rule_id
            == "SAFE_USER_CRASH_DUMP"
        ):

            if not lower_path.endswith(
                ".dmp"
            ):

                warnings.append(
                    (
                        "CRITICAL_INVALID_CRASH_DUMP",
                        path,
                        "Non-DMP file classified as verified crash dump.",
                    )
                )

    elapsed = (
        time.perf_counter()
        - start
    )

    conn.close()

    # ========================================================
    # SUMMARY
    # ========================================================

    print("\n" + "=" * 80)
    print("SAFE_TO_CLEAN SUMMARY")
    print("=" * 80)

    print(
        f"\nFiles : {total_safe_files:,}"
    )

    print(
        f"Size  : {gb(total_safe_size):.2f} GB"
    )

    # ========================================================
    # RULE BREAKDOWN
    # ========================================================

    print("\n" + "=" * 80)
    print("SAFE RULE BREAKDOWN")
    print("=" * 80)

    sorted_rules = sorted(
        rule_stats.items(),
        key=lambda item:
            item[1]["size"],
        reverse=True
    )

    for rule_id, stats in sorted_rules:

        print(
            f"\n{rule_id}"
        )

        print(
            f"  Files : "
            f"{stats['files']:,}"
        )

        print(
            f"  Size  : "
            f"{gb(stats['size']):.2f} GB"
        )

    # ========================================================
    # TOP PATH GROUPS
    # ========================================================

    for rule_id, _ in sorted_rules:

        print("\n" + "=" * 80)

        print(
            f"TOP PATHS — {rule_id}"
        )

        print("=" * 80)

        paths = sorted(
            rule_paths[
                rule_id
            ].items(),
            key=lambda item:
                item[1]["size"],
            reverse=True
        )

        for index, (
            path,
            stats
        ) in enumerate(
            paths[:TOP_PATHS],
            start=1
        ):

            print(
                f"\n[{index}] "
                f"{path}"
            )

            print(
                f"    Files : "
                f"{stats['files']:,}"
            )

            print(
                f"    Size  : "
                f"{gb(stats['size']):.3f} GB"
            )

    # ========================================================
    # LARGEST SAFE FILES
    # ========================================================

    print("\n" + "=" * 80)
    print("TOP LARGEST SAFE FILES")
    print("=" * 80)

    largest_files.sort(
        reverse=True
    )

    for (
        size,
        _,
        path,
        rule_id
    ) in largest_files:

        print(
            f"\n{mb(size):>10.2f} MB"
            f" | {rule_id}"
        )

        print(
            f"  {path}"
        )

    # ========================================================
    # SAMPLE PATHS
    # ========================================================

    print("\n" + "=" * 80)
    print("SAMPLE PATHS BY SAFE RULE")
    print("=" * 80)

    for rule_id, paths in samples.items():

        print(
            f"\n[{rule_id}]"
        )

        for path in paths:

            print(
                f"  {path}"
            )

    # ========================================================
    # WARNINGS
    # ========================================================

    print("\n" + "=" * 80)
    print("SAFETY WARNINGS")
    print("=" * 80)

    if not warnings:

        print(
            "\n[OK] No critical SAFE_TO_CLEAN "
            "safety violations detected."
        )

    else:

        print(
            f"\n[CRITICAL] "
            f"{len(warnings):,} safety warnings detected."
        )

        for (
            warning_type,
            path,
            reason
        ) in warnings[:100]:

            print(
                f"\n{warning_type}"
            )

            print(
                f"Path   : {path}"
            )

            print(
                f"Reason : {reason}"
            )

    # ========================================================
    # PERFORMANCE
    # ========================================================

    print("\n" + "=" * 80)
    print("PERFORMANCE")
    print("=" * 80)

    print(
        f"\nAudit time : "
        f"{elapsed:.2f} sec"
    )

    print("\n" + "=" * 80)


if __name__ == "__main__":
    main()