import os
import time
from collections import defaultdict

from config.settings import DB_PATH
from database.db import create_connection

from rules.rules_v2 import get_rules
from rules.rules_v2.router import RuleRouter
from rules.rules_v2.context import RuleContext


CLEAN_ACTION = "CLEAN"

SENSITIVE_NAMES = {
    "cookies",
    "history",
    "login data",
    "bookmarks",
    "extensions",
    "local storage",
    "session storage",
    "sessions",
    "web data",
    "preferences",
    "password",
    "passwords",
    "credentials",
    "wallet",
}


def gb(size):
    return size / (1024 ** 3)


def mb(size):
    return size / (1024 ** 2)


def analyze(context, router):

    relevant_rules = router.get_rules(
        context
    )

    for rule in relevant_rules:

        result = rule.match_context(
            context
        )

        if result is not None:
            return result

    return None


def get_parent_group(path):

    return os.path.dirname(
        path
    )


def main():

    print("=" * 80)
    print("STORAGE MANAGER — ALL CLEAN SAFETY AUDIT")
    print("=" * 80)

    conn = create_connection(
        DB_PATH
    )

    rules = get_rules()

    router = RuleRouter(
        rules
    )

    # ---------------------------------------------------------
    # STATS
    # ---------------------------------------------------------

    total_clean_files = 0
    total_clean_size = 0

    rule_stats = defaultdict(
        lambda: {
            "files": 0,
            "size": 0,
        }
    )

    parent_groups = defaultdict(
        lambda: {
            "files": 0,
            "size": 0,
            "rule_id": None,
        }
    )

    samples = defaultdict(
        list
    )

    sensitive_matches = defaultdict(
        list
    )

    start = time.perf_counter()

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        WHERE scope = 'TECHNICAL'
        """
    )

    for path, size in cursor:

        size = size or 0

        context = RuleContext.create(
            path,
            size
        )

        result = analyze(
            context,
            router
        )

        if result is None:
            continue

        if result.action != CLEAN_ACTION:
            continue

        # -----------------------------------------------------
        # CLEAN MATCH
        # -----------------------------------------------------

        total_clean_files += 1
        total_clean_size += size

        rule_id = result.rule_id

        rule_stats[
            rule_id
        ]["files"] += 1

        rule_stats[
            rule_id
        ]["size"] += size

        # -----------------------------------------------------
        # SAMPLE PATHS
        # -----------------------------------------------------

        if len(
            samples[rule_id]
        ) < 10:

            samples[
                rule_id
            ].append(
                context.path
            )

        # -----------------------------------------------------
        # PARENT DIRECTORY GROUP
        # -----------------------------------------------------

        parent = get_parent_group(
            context.path
        )

        parent_groups[
            parent
        ]["files"] += 1

        parent_groups[
            parent
        ]["size"] += size

        parent_groups[
            parent
        ]["rule_id"] = rule_id

        # -----------------------------------------------------
        # SENSITIVE NAME AUDIT
        # -----------------------------------------------------

        for part in context.parts:

            if part in SENSITIVE_NAMES:

                if len(
                    sensitive_matches[
                        rule_id
                    ]
                ) < 100:

                    sensitive_matches[
                        rule_id
                    ].append(
                        context.path
                    )

                break

    elapsed = (
        time.perf_counter()
        - start
    )

    conn.close()

    # =========================================================
    # CLEAN SUMMARY
    # =========================================================

    print("\n" + "=" * 80)
    print("CLEAN SUMMARY")
    print("=" * 80)

    print(
        f"\nTotal CLEAN files : "
        f"{total_clean_files:,}"
    )

    print(
        f"Total CLEAN size  : "
        f"{gb(total_clean_size):.2f} GB"
    )

    # =========================================================
    # RULE BREAKDOWN
    # =========================================================

    print("\n" + "=" * 80)
    print("CLEAN RULE BREAKDOWN")
    print("=" * 80)

    sorted_rules = sorted(
        rule_stats.items(),
        key=lambda item:
            item[1]["size"],
        reverse=True
    )

    for rule_id, stats in sorted_rules:

        print(
            f"{rule_id:<32} | "
            f"{stats['files']:>10,} files | "
            f"{gb(stats['size']):>10.2f} GB"
        )

    # =========================================================
    # SAMPLE PATHS
    # =========================================================

    print("\n" + "=" * 80)
    print("SAMPLE PATHS BY CLEAN RULE")
    print("=" * 80)

    for rule_id, paths in samples.items():

        print(
            f"\n[{rule_id}]"
        )

        for path in paths:

            print(
                f"  {path}"
            )

    # =========================================================
    # TOP CLEAN PARENT DIRECTORIES
    # =========================================================

    print("\n" + "=" * 80)
    print("TOP 100 CLEAN PARENT DIRECTORIES")
    print("=" * 80)

    sorted_parents = sorted(
        parent_groups.items(),
        key=lambda item:
            item[1]["size"],
        reverse=True
    )

    for index, (
        parent,
        stats
    ) in enumerate(
        sorted_parents[:100],
        start=1
    ):

        print(
            f"\n[{index}]"
        )

        print(
            f"Rule  : "
            f"{stats['rule_id']}"
        )

        print(
            f"Path  : "
            f"{parent}"
        )

        print(
            f"Size  : "
            f"{gb(stats['size']):.4f} GB "
            f"({mb(stats['size']):.2f} MB)"
        )

        print(
            f"Files : "
            f"{stats['files']:,}"
        )

    # =========================================================
    # SENSITIVE NAME AUDIT
    # =========================================================

    print("\n" + "=" * 80)
    print("SENSITIVE NAME AUDIT")
    print("=" * 80)

    total_sensitive = sum(
        len(paths)
        for paths
        in sensitive_matches.values()
    )

    print(
        f"\nSensitive-name matches : "
        f"{total_sensitive:,}"
    )

    if not sensitive_matches:

        print(
            "\n[OK] No known sensitive names were found "
            "inside CLEAN-classified paths."
        )

    else:

        print(
            "\nWARNING:"
        )

        print(
            "Some CLEAN-classified paths contain known "
            "sensitive directory or file names."
        )

        for rule_id, paths in (
            sensitive_matches.items()
        ):

            print(
                f"\n[{rule_id}]"
            )

            print(
                f"Matches shown : "
                f"{len(paths):,}"
            )

            for path in paths:

                print(
                    f"  {path}"
                )

    # =========================================================
    # PERFORMANCE
    # =========================================================

    print("\n" + "=" * 80)
    print("PERFORMANCE")
    print("=" * 80)

    print(
        f"\nAudit time : "
        f"{elapsed:.2f} sec"
    )

    print("\n" + "=" * 80)


if __name__ == "__main__":
    main()