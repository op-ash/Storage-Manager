import time
import threading
from collections import defaultdict

from config.settings import (
    DB_PATH,
    GROQ_API_KEY,
    GEMINI_API_KEY,
    OPENROUTER_API_KEY,
    AI_DEFAULT_PROVIDER,
    AI_FALLBACK_PROVIDERS,
    AI_MAX_WORKERS,
    AI_DEEP_BATCH_SIZE,
    AI_SHALLOW_BATCH_SIZE,
    AI_DEEP_DRILL_THRESHOLD,
    AI_MAX_ANALYSIS_ROUNDS,
    AI_MINIMUM_CHILD_SIZE,
    AI_MAX_CHILDREN_PER_EXPANSION,
)

from database.db import (
    create_connection,
)

from rules_v3 import (
    FileContext,
    StorageClassifier,
    AI_ANALYSIS,
    StandardUserFoldersRule,
    get_protected_rules,
    get_safe_rules,
)

from ai_analysis import (
    FolderTreeBuilder,
    StartingBoundaryResolver,
    DirectFileClusterBuilder,
)

from ai_analysis.provider_settings import (
    AIProviderSettings,
    APIKeyStore,
    SUPPORTED_PROVIDERS,
)

from ai_analysis.pipeline import (
    AIAnalysisPipeline,
    AIAnalysisPipelineConfig,
)


# ============================================================
# DIAGNOSTIC CONFIG
# ============================================================

# Start with 20 meaningful clusters.
# Set to None later to test every starting cluster.
MAX_INITIAL_CLUSTERS = 20


# ============================================================
# HELPERS
# ============================================================

def format_size(size):

    if size >= 1024 ** 3:

        return (
            f"{size / (1024 ** 3):.2f} GB"
        )

    return (
        f"{size / (1024 ** 2):.2f} MB"
    )


def create_classifier():

    return StorageClassifier(
        user_rules=[
            StandardUserFoldersRule(),
        ],
        protected_rules=(
            get_protected_rules()
        ),
        safe_rules=(
            get_safe_rules()
        ),
    )


def load_ai_analysis_files(
    conn,
    classifier,
):

    files = []

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        """
    )

    for path, size in cursor:

        size = size or 0

        context = (
            FileContext.create(
                path,
                size,
            )
        )

        result = (
            classifier.classify_context(
                context
            )
        )

        if (
            result.classification
            == AI_ANALYSIS
        ):

            files.append(
                (
                    path,
                    size,
                )
            )

    return files


def cluster_size(
    cluster,
):

    return getattr(
        cluster,
        "total_size",
        0,
    )


def cluster_path(
    cluster,
):

    path = getattr(
        cluster,
        "path",
        None,
    )

    if path is not None:

        return path

    return getattr(
        cluster,
        "parent_path",
        "UNKNOWN",
    )

# ============================================================
# DIAGNOSTIC PAYLOAD BUILDER
# ============================================================

class DiagnosticPayloadBuilder:
    """
    Transparent wrapper around the production payload builder.

    Records every build_batches() call without changing
    production batching behavior.

    Each call normally represents one iterative AI round.
    """

    def __init__(
        self,
        payload_builder,
    ):

        self.payload_builder = payload_builder

        self.rounds = []

        self._lock = threading.Lock()

    def build_batches(
        self,
        clusters,
    ):

        # Materialize once for safe counting.
        clusters = list(clusters)

        # Call the REAL production method.
        batches = self.payload_builder.build_batches(
            clusters
        )

        batches = list(batches)

        round_data = {
            "clusters": len(clusters),
            "batches": [],
        }

        for batch in batches:

            batch_id = getattr(
                batch,
                "batch_id",
                "UNKNOWN",
            )

            # Try to find the actual cluster collection
            # without changing production behavior.
            batch_clusters = getattr(
                batch,
                "clusters",
                None,
            )

            if batch_clusters is None:

                batch_clusters = getattr(
                    batch,
                    "items",
                    None,
                )

            if batch_clusters is None:

                batch_clusters = getattr(
                    batch,
                    "payloads",
                    None,
                )

            if batch_clusters is None:

                cluster_count = "UNKNOWN"

            else:

                try:
                    cluster_count = len(
                        batch_clusters
                    )

                except TypeError:
                    cluster_count = "UNKNOWN"

            # Detect batch type from batch_id.
            batch_id_string = str(
                batch_id
            ).lower()

            if batch_id_string.startswith(
                "deep"
            ):

                batch_type = "DEEP"

            elif batch_id_string.startswith(
                "shallow"
            ):

                batch_type = "SHALLOW"

            else:

                batch_type = "UNKNOWN"

            round_data[
                "batches"
            ].append(
                {
                    "batch_id": batch_id,
                    "batch_type": batch_type,
                    "cluster_count": cluster_count,
                }
            )

        with self._lock:

            self.rounds.append(
                round_data
            )

        # Return original production batches unchanged.
        return batches

# ============================================================
# API KEY SETUP
# ============================================================

def configure_api_keys():

    """
    Development diagnostic bridge.

    Reads API keys from config/settings.py and stores them
    using the existing secure APIKeyStore.

    Production UI will write directly to APIKeyStore instead.
    """

    print("\n" + "=" * 80)
    print("AI PROVIDER KEY SETUP")
    print("=" * 80)

    key_store = (
        APIKeyStore()
    )

    configured_keys = {
        "groq": GROQ_API_KEY,
        "gemini": GEMINI_API_KEY,
        "openrouter": OPENROUTER_API_KEY,
    }

    available_providers = []

    for (
        provider_name,
        api_key,
    ) in configured_keys.items():

        api_key = (
            api_key.strip()
            if api_key
            else ""
        )

        if api_key:

            key_store.set_api_key(
                provider_name,
                api_key,
            )

            available_providers.append(
                provider_name
            )

            print(
                f"\n[OK] "
                f"{provider_name.upper()} "
                f"API key configured"
            )

        else:

            print(
                f"\n[SKIP] "
                f"{provider_name.upper()} "
                f"API key not configured"
            )

    if not available_providers:

        raise RuntimeError(
            "No AI API keys are configured. "
            "Add at least one API key in "
            "config/settings.py."
        )

    return (
        key_store,
        available_providers,
    )


# ============================================================
# PROVIDER SETTINGS
# ============================================================

def create_provider_settings(
    available_providers,
):

    settings = (
        AIProviderSettings()
    )

    # Disable providers that do not have an API key.
    for provider_name in (
        SUPPORTED_PROVIDERS
    ):

        settings.set_enabled(
            provider_name,
            provider_name
            in available_providers,
        )

    # ========================================================
    # DEFAULT PROVIDER
    # ========================================================

    requested_default = (
        AI_DEFAULT_PROVIDER
        .strip()
        .lower()
    )

    if (
        requested_default
        in available_providers
    ):

        default_provider = (
            requested_default
        )

    else:

        default_provider = (
            available_providers[0]
        )

        print(
            "\n[WARNING] Configured default provider "
            f"'{requested_default}' has no API key."
        )

        print(
            f"Using '{default_provider}' instead."
        )

    settings.set_default_provider(
        default_provider
    )

    # ========================================================
    # FALLBACK ORDER
    # ========================================================

    fallback_order = [

        provider

        for provider
        in AI_FALLBACK_PROVIDERS

        if (
            provider
            in available_providers

            and provider
            != default_provider
        )
    ]

    # Include any configured provider that was accidentally
    # omitted from AI_FALLBACK_PROVIDERS.
    for provider in (
        available_providers
    ):

        if (
            provider
            == default_provider
        ):
            continue

        if provider not in (
            fallback_order
        ):

            fallback_order.append(
                provider
            )

    settings.set_fallback_order(
        fallback_order
    )

    return settings


# ============================================================
# PRINT PROVIDER CONFIG
# ============================================================

def print_provider_configuration(
    settings,
    key_store,
):

    print("\n" + "=" * 80)
    print("ACTIVE AI PROVIDERS")
    print("=" * 80)

    order = (
        settings.get_provider_order()
    )

    for index, provider in enumerate(
        order,
        start=1,
    ):

        role = (
            "DEFAULT"
            if index == 1
            else f"FALLBACK {index - 1}"
        )

        masked_key = (
            key_store.get_masked_key(
                provider
            )
        )

        print(
            f"\n[{index}] "
            f"{provider.upper()}"
        )

        print(
            f"    Role : {role}"
        )

        print(
            f"    Key  : {masked_key}"
        )


# ============================================================
# MAIN
# ============================================================

def main():

    diagnostic_start = (
        time.perf_counter()
    )

    print("=" * 80)

    print(
        "STORAGE MANAGER — "
        "PRODUCTION AI PIPELINE DIAGNOSTIC"
    )

    print("=" * 80)

    # ========================================================
    # 1. API KEYS
    # ========================================================

    key_store, available_providers = (
        configure_api_keys()
    )

    provider_settings = (
        create_provider_settings(
            available_providers
        )
    )

    print_provider_configuration(
        provider_settings,
        key_store,
    )

    # ========================================================
    # 2. LOAD AI_ANALYSIS DATA
    # ========================================================

    print("\n" + "=" * 80)
    print("LOADING AI_ANALYSIS DATA")
    print("=" * 80)

    classifier = (
        create_classifier()
    )

    conn = (
        create_connection(
            DB_PATH
        )
    )

    load_start = (
        time.perf_counter()
    )

    ai_files = (
        load_ai_analysis_files(
            conn,
            classifier,
        )
    )

    conn.close()

    load_time = (
        time.perf_counter()
        - load_start
    )

    ai_file_count = (
        len(
            ai_files
        )
    )

    ai_size = sum(
        size
        for _, size
        in ai_files
    )

    print(
        f"\nAI files : "
        f"{ai_file_count:,}"
    )

    print(
        f"AI size  : "
        f"{format_size(ai_size)}"
    )

    print(
        f"Load time: "
        f"{load_time:.2f} sec"
    )

    if not ai_files:

        raise RuntimeError(
            "No AI_ANALYSIS files found."
        )

    # ========================================================
    # 3. BUILD AI TREE
    # ========================================================

    print("\n" + "=" * 80)
    print("BUILDING AI CLUSTERS")
    print("=" * 80)

    cluster_start = (
        time.perf_counter()
    )

    tree = (
        FolderTreeBuilder()
        .build(
            ai_files
        )
    )

    resolver = (
        StartingBoundaryResolver(
            tree
        )
    )

    folder_clusters = (
        resolver.resolve()
    )

    direct_clusters = (
        DirectFileClusterBuilder()
        .build(
            files=(
                ai_files
            ),
            folder_candidates=(
                folder_clusters
            ),
        )
    )

    cluster_time = (
        time.perf_counter()
        - cluster_start
    )

    print(
        f"\nFolder clusters      : "
        f"{len(folder_clusters):,}"
    )

    print(
        f"Direct-file clusters : "
        f"{len(direct_clusters):,}"
    )

    print(
        f"Cluster build time   : "
        f"{cluster_time:.2f} sec"
    )

    # ========================================================
    # 4. INITIAL CLUSTERS
    # ========================================================

    all_clusters = (
        list(
            folder_clusters
        )
        + list(
            direct_clusters
        )
    )

    all_clusters.sort(
        key=cluster_size,
        reverse=True,
    )

    if (
        MAX_INITIAL_CLUSTERS
        is None
    ):

        initial_clusters = (
            all_clusters
        )

    else:

        initial_clusters = (
            all_clusters[
                :MAX_INITIAL_CLUSTERS
            ]
        )

    initial_size = sum(
        cluster_size(
            cluster
        )
        for cluster
        in initial_clusters
    )

    print("\n" + "=" * 80)
    print("INITIAL AI CLUSTERS")
    print("=" * 80)

    print(
        f"\nClusters : "
        f"{len(initial_clusters):,}"
    )

    print(
        f"Size     : "
        f"{format_size(initial_size)}"
    )

    for index, cluster in enumerate(
        initial_clusters,
        start=1,
    ):

        print(
            f"\n[{index}] "
            f"{format_size(cluster_size(cluster))}"
        )

        print(
            f"    "
            f"{cluster_path(cluster)}"
        )

    # ========================================================
    # 5. BUILD PRODUCTION AI PIPELINE
    # ========================================================

    print("\n" + "=" * 80)
    print("BUILDING PRODUCTION AI PIPELINE")
    print("=" * 80)

    pipeline_config = (
        AIAnalysisPipelineConfig(

            deep_batch_size=(
                AI_DEEP_BATCH_SIZE
            ),

            shallow_batch_size=(
                AI_SHALLOW_BATCH_SIZE
            ),

            deep_drill_threshold=(
                AI_DEEP_DRILL_THRESHOLD
            ),

            max_workers=(
                AI_MAX_WORKERS
            ),

            continue_on_error=True,

            max_rounds=(
                AI_MAX_ANALYSIS_ROUNDS
            ),

            minimum_child_size=(
                AI_MINIMUM_CHILD_SIZE
            ),

            max_children_per_expansion=(
                AI_MAX_CHILDREN_PER_EXPANSION
            ),
        )
    )

    pipeline = (
        AIAnalysisPipeline(
            settings=(
                provider_settings
            ),
            key_store=(
                key_store
            ),
            config=(
                pipeline_config
            ),
        )
    )

    # ============================================================
    # INSTALL DIAGNOSTIC BATCH TRACKER
    # ============================================================

    diagnostic_payload_builder = (
        DiagnosticPayloadBuilder(
            pipeline.payload_builder
        )
    )

    # Replace only the orchestrator reference.
    #
    # The underlying production PayloadBuilder remains unchanged.
    pipeline.orchestrator.payload_builder = (
        diagnostic_payload_builder
    )

    print(
        "\n[OK] Production AI pipeline created"
    )

    print(
        f"Concurrent workers : "
        f"{AI_MAX_WORKERS}"
    )

    print(
        f"Deep batch size    : "
        f"{AI_DEEP_BATCH_SIZE}"
    )

    print(
        f"Shallow batch size : "
        f"{AI_SHALLOW_BATCH_SIZE}"
    )

    print(
        f"Max AI rounds      : "
        f"{AI_MAX_ANALYSIS_ROUNDS}"
    )

    # ========================================================
    # 6. RUN REAL AI PIPELINE
    # ========================================================

    print("\n" + "=" * 80)

    print(
        "RUNNING REAL PRODUCTION AI ANALYSIS"
    )

    print("=" * 80)

    print(
        "\nWARNING: This section makes real "
        "AI API requests."
    )

    analysis_start = (
        time.perf_counter()
    )

    result = (
        pipeline.analyze(
            initial_clusters
        )
    )

    analysis_time = (
        time.perf_counter()
        - analysis_start
    )

    # ========================================================
    # 7. FINAL RESULT SUMMARY
    # ========================================================

    print("\n" + "=" * 80)
    print("FINAL AI ANALYSIS RESULT")
    print("=" * 80)

    print(
        f"\nRounds completed  : "
        f"{result.rounds_completed}"
    )

    print(
        f"Clusters analyzed : "
        f"{result.clusters_analyzed:,}"
    )

    print(
        f"Clusters expanded : "
        f"{result.clusters_expanded:,}"
    )

    print(
        f"\nKEEP              : "
        f"{len(result.keep):,}"
    )

    print(
        f"SAFE_TO_CLEAN     : "
        f"{len(result.safe_to_clean):,}"
    )

    print(
        f"USER_VERIFICATION : "
        f"{len(result.user_verification):,}"
    )

    print(
        f"UNRESOLVED        : "
        f"{len(result.unresolved):,}"
    )

    print(
        f"FAILED BATCHES    : "
        f"{len(result.failed_batches):,}"
    )

    # ========================================================
    # 8. DECISION DETAILS
    # ========================================================

    categories = [

        (
            "KEEP",
            result.keep,
        ),

        (
            "SAFE_TO_CLEAN",
            result.safe_to_clean,
        ),

        (
            "USER_VERIFICATION",
            result.user_verification,
        ),

        (
            "UNRESOLVED",
            result.unresolved,
        ),
    ]

    for (
        category_name,
        decisions,
    ) in categories:

        if not decisions:

            continue

        print("\n" + "=" * 80)

        print(
            category_name
        )

        print("=" * 80)

        for index, decision in enumerate(
            decisions,
            start=1,
        ):

            print(
                f"\n[{index}] "
                f"{decision.cluster_path}"
            )

            print(
                f"    Decision   : "
                f"{decision.decision}"
            )

            print(
                f"    Confidence : "
                f"{decision.confidence:.2f}"
            )

            print(
                f"    Recommend  : "
                f"{decision.recommended_path}"
            )

            print(
                f"    Reason     : "
                f"{decision.reason}"
            )

    # ========================================================
    # 9. FAILED BATCHES
    # ========================================================

    if result.failed_batches:

        print("\n" + "=" * 80)
        print("FAILED BATCHES")
        print("=" * 80)

        for batch_id in (
            result.failed_batches
        ):

            print(
                f"\n- {batch_id}"
            )

    # ========================================================
    # 10. PROVIDER RUNTIME STATS
    # ========================================================

    print("\n" + "=" * 80)
    print("PROVIDER RUNTIME STATS")
    print("=" * 80)

    registry = getattr(
        pipeline.provider,
        "registry",
        None,
    )

    if registry is None:

        print(
            "\nProvider registry unavailable."
        )

    else:

        for provider_name in (
            SUPPORTED_PROVIDERS
        ):

            entry = (
                registry.get(
                    provider_name
                )
            )

            if entry is None:

                continue

            state = (
                entry.state
            )

            print(
                f"\n{provider_name.upper()}"
            )

            print(
                f"  Requests          : "
                f"{state.total_requests}"
            )

            print(
                f"  Successes         : "
                f"{state.successful_requests}"
            )

            print(
                f"  Failures          : "
                f"{state.failed_requests}"
            )

            print(
                f"  Fallback uses     : "
                f"{state.fallback_uses}"
            )

            print(
                f"  Rate limits       : "
                f"{state.rate_limit_errors}"
            )

            print(
                f"  Auth errors       : "
                f"{state.authentication_errors}"
            )

            print(
                f"  Timeouts          : "
                f"{state.timeout_errors}"
            )

            print(
                f"  Server errors     : "
                f"{state.server_errors}"
            )

            print(
                f"  Network errors    : "
                f"{state.network_errors}"
            )

            print(
                f"  Invalid responses : "
                f"{state.invalid_response_errors}"
            )

            print(
                f"  Runtime disabled  : "
                f"{state.runtime_disabled}"
            )

            if state.last_error:

                print(
                    f"  Last error type   : "
                    f"{state.last_error_type}"
                )

                print(
                    f"  Last error        : "
                    f"{state.last_error}"
                )

    # ============================================================
    # MODEL EXECUTION TRACE
    # ============================================================

    print("\n" + "=" * 80)
    print("MODEL EXECUTION TRACE")
    print("=" * 80)

    registry = getattr(
        pipeline.provider,
        "registry",
        None,
    )


    if registry is None:

        print(
            "\nProvider registry unavailable."
        )

    else:

        total_model_attempts = 0

        total_model_failures = 0

        total_model_successes = 0

        total_model_switches = 0


        for provider_name in (
            SUPPORTED_PROVIDERS
        ):

            entry = (
                registry.get(
                    provider_name
                )
            )

            if entry is None:

                continue

            provider = (
                entry.config.provider
            )

            events = getattr(
                provider,
                "model_events",
                [],
            )

            if not events:

                continue

            print(
                f"\n{'-' * 80}"
            )

            print(
                f"PROVIDER: "
                f"{provider_name.upper()}"
            )

            print(
                f"{'-' * 80}"
            )

            # ====================================================
            # GROUP EVENTS BY BATCH
            # ====================================================

            batch_events = (
                defaultdict(
                    list
                )
            )

            for event in events:

                batch_events[
                    event[
                        "batch_id"
                    ]
                ].append(
                    event
                )

            # ====================================================
            # PRINT EACH BATCH TRACE
            # ====================================================

            for (
                batch_id,
                events_for_batch,
            ) in batch_events.items():

                print(
                    f"\n[{batch_id}]"
                )

                previous_model = (
                    None
                )

                for event in (
                    events_for_batch
                ):

                    model = (
                        event[
                            "model"
                        ]
                    )

                    status = (
                        event[
                            "status"
                        ]
                    )

                    # ============================================
                    # MODEL ATTEMPT
                    # ============================================

                    if status == "TRYING":

                        total_model_attempts += 1

                        if (
                            previous_model
                            is not None

                            and previous_model
                            != model
                        ):

                            total_model_switches += 1

                            print(
                                "    MODEL SWITCH"
                            )

                            print(
                                f"      "
                                f"{previous_model}"
                            )

                            print(
                                "        ↓"
                            )

                            print(
                                f"      {model}"
                            )

                        else:

                            print(
                                f"    TRY     : "
                                f"{model}"
                            )

                        previous_model = (
                            model
                        )

                    # ============================================
                    # SUCCESS
                    # ============================================

                    elif status == "SUCCESS":

                        total_model_successes += 1

                        print(
                            f"    SUCCESS : "
                            f"{model}"
                        )

                    # ============================================
                    # FAILURE
                    # ============================================

                    elif status == "FAILED":

                        total_model_failures += 1

                        print(
                            f"    FAILED  : "
                            f"{model}"
                        )

                        error = (
                            event.get(
                                "error"
                            )
                        )

                        if error:

                            # Avoid dumping huge API errors.
                            clean_error = (
                                str(
                                    error
                                )
                                .replace(
                                    "\n",
                                    " "
                                )
                            )

                            if (
                                len(
                                    clean_error
                                )
                                > 300
                            ):

                                clean_error = (
                                    clean_error[
                                        :300
                                    ]
                                    + "..."
                                )

                            print(
                                f"    ERROR   : "
                                f"{clean_error}"
                            )


        # ========================================================
        # MODEL TRACE SUMMARY
        # ========================================================

        print("\n" + "-" * 80)

        print(
            "MODEL TRACE SUMMARY"
        )

        print(
            "-" * 80
        )

        print(
            f"\nModel attempts  : "
            f"{total_model_attempts}"
        )

        print(
            f"Model successes : "
            f"{total_model_successes}"
        )

        print(
            f"Model failures  : "
            f"{total_model_failures}"
        )

        print(
            f"Model switches  : "
            f"{total_model_switches}"
        )

    # ============================================================
    # LOGICAL BATCH DIAGNOSTIC
    # ============================================================

    print("\n" + "=" * 80)
    print("LOGICAL BATCH EXECUTION")
    print("=" * 80)

    total_logical_batches = 0

    total_deep_batches = 0

    total_shallow_batches = 0


    for round_index, round_data in enumerate(
        diagnostic_payload_builder.rounds,
        start=1,
    ):

        batches = (
            round_data[
                "batches"
            ]
        )

        deep_batches = [

            batch

            for batch
            in batches

            if (
                batch[
                    "batch_type"
                ]
                == "DEEP"
            )
        ]

        shallow_batches = [

            batch

            for batch
            in batches

            if (
                batch[
                    "batch_type"
                ]
                == "SHALLOW"
            )
        ]

        total_logical_batches += (
            len(
                batches
            )
        )

        total_deep_batches += (
            len(
                deep_batches
            )
        )

        total_shallow_batches += (
            len(
                shallow_batches
            )
        )

        print(
            f"\nROUND {round_index}"
        )

        print(
            f"  Clusters received : "
            f"{round_data['clusters']}"
        )

        print(
            f"  Batches generated : "
            f"{len(batches)}"
        )

        print(
            f"  Deep batches      : "
            f"{len(deep_batches)}"
        )

        print(
            f"  Shallow batches   : "
            f"{len(shallow_batches)}"
        )

        for batch in batches:

            print(
                f"\n    {batch['batch_id']}"
            )

            print(
                f"      Type     : "
                f"{batch['batch_type']}"
            )

            print(
                f"      Clusters : "
                f"{batch['cluster_count']}"
            )


    print("\n" + "-" * 80)

    print(
        f"TOTAL LOGICAL BATCHES : "
        f"{total_logical_batches}"
    )

    print(
        f"TOTAL DEEP BATCHES    : "
        f"{total_deep_batches}"
    )

    print(
        f"TOTAL SHALLOW BATCHES : "
        f"{total_shallow_batches}"
    )

    # ========================================================
    # 11. PERFORMANCE
    # ========================================================

    total_time = (
        time.perf_counter()
        - diagnostic_start
    )

    print("\n" + "=" * 80)
    print("PERFORMANCE")
    print("=" * 80)

    print(
        f"\nAI data load       : "
        f"{load_time:.2f} sec"
    )

    print(
        f"Cluster build      : "
        f"{cluster_time:.2f} sec"
    )

    print(
        f"Real AI analysis   : "
        f"{analysis_time:.2f} sec"
    )

    print(
        f"Full diagnostic    : "
        f"{total_time:.2f} sec"
    )

    print("\n" + "=" * 80)


if __name__ == "__main__":

    main()