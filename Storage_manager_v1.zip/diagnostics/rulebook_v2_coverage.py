import time
from collections import defaultdict

from config.settings import DB_PATH
from database.db import create_connection

# from core.storage_scope import (
#     StorageScope,
#     StorageScopeClassifier
# )

from rules.rules_v2 import get_rules

from rules.rules_v2.router import RuleRouter

from rules.rules_v2.context import (
    RuleContext
)


def gb(size):
    return size / (1024 ** 3)


def analyze(
    context,
    router
):

    relevant_rules = (
        router.get_rules(context)
    )

    for rule in relevant_rules:

        result = rule.match_context(
            context
        )

        if result is not None:
            return result

    return None


def main():

    print("=" * 80)
    print("STORAGE MANAGER — RULEBOOK V2 FULL ANALYSIS")
    print("=" * 80)

    conn = create_connection(DB_PATH)

    # classifier = StorageScopeClassifier()

    rules = get_rules()

    router = RuleRouter(
        rules
    )

    # ---------------------------------------------------------
    # OVERALL TECHNICAL STORAGE
    # ---------------------------------------------------------

    total_files = 0
    total_size = 0

    # ---------------------------------------------------------
    # ACTION STATS
    # ---------------------------------------------------------

    actions = defaultdict(
        lambda: {
            "files": 0,
            "size": 0
        }
    )

    # ---------------------------------------------------------
    # RULE STATS
    # ---------------------------------------------------------

    rule_stats = defaultdict(
        lambda: {
            "files": 0,
            "size": 0
        }
    )

    # ---------------------------------------------------------
    # CATEGORY STATS
    # ---------------------------------------------------------

    category_stats = defaultdict(
        lambda: {
            "files": 0,
            "size": 0
        }
    )

    print("\nAnalyzing technical storage...")

    start = time.perf_counter()

    cursor = conn.execute(
        """
        SELECT
            path,
            size
        FROM files
        WHERE scope = 'TECHNICAL'
        """
    )

    for path, size in cursor:

        size = size or 0

        context = RuleContext.create(
            path,
            size
        )

        total_files += 1
        total_size += size

        result = analyze(
            context,
            router
        )

        # -----------------------------------------------------
        # UNKNOWN
        # -----------------------------------------------------

        if result is None:

            actions["UNKNOWN"]["files"] += 1
            actions["UNKNOWN"]["size"] += size

            category_stats["UNKNOWN"]["files"] += 1
            category_stats["UNKNOWN"]["size"] += size

            continue

        # -----------------------------------------------------
        # MATCHED RULE
        # -----------------------------------------------------

        action = result.action
        category = result.category

        actions[action]["files"] += 1
        actions[action]["size"] += size

        rule_stats[result.rule_id]["files"] += 1
        rule_stats[result.rule_id]["size"] += size

        category_stats[category]["files"] += 1
        category_stats[category]["size"] += size

    elapsed = time.perf_counter() - start

    # =========================================================
    # SUMMARY
    # =========================================================

    print("\n" + "=" * 80)
    print("TECHNICAL STORAGE SUMMARY")
    print("=" * 80)

    print(
        f"\nTotal technical files : "
        f"{total_files:,}"
    )

    print(
        f"Total technical size  : "
        f"{gb(total_size):.2f} GB"
    )

    # =========================================================
    # ACTION BREAKDOWN
    # =========================================================

    print("\n" + "=" * 80)
    print("ACTION BREAKDOWN")
    print("=" * 80)

    for action in [
        "CLEAN",
        "REVIEW",
        "KEEP",
        "UNKNOWN"
    ]:

        stats = actions[action]

        percentage = (
            stats["size"]
            / total_size
            * 100
            if total_size
            else 0
        )

        print(
            f"{action:<10} | "
            f"{stats['files']:>10,} files | "
            f"{gb(stats['size']):>10.2f} GB | "
            f"{percentage:>6.2f}%"
        )

    # =========================================================
    # RECLAIMABLE STORAGE
    # =========================================================

    safe_size = actions["CLEAN"]["size"]

    review_size = actions["REVIEW"]["size"]

    potential_size = (
        safe_size
        + review_size
    )

    print("\n" + "=" * 80)
    print("STORAGE RECOVERY ESTIMATE")
    print("=" * 80)

    print(
        f"\nSafe cleanup now       : "
        f"{gb(safe_size):.2f} GB"
    )

    print(
        f"Additional review data : "
        f"{gb(review_size):.2f} GB"
    )

    print(
        f"Maximum potential      : "
        f"{gb(potential_size):.2f} GB"
    )

    print(
        "\nNOTE:"
    )

    print(
        "Maximum potential does NOT mean all REVIEW data "
        "should automatically be deleted."
    )

    # =========================================================
    # RULE BREAKDOWN
    # =========================================================

    print("\n" + "=" * 80)
    print("RULE BREAKDOWN")
    print("=" * 80)

    sorted_rules = sorted(
        rule_stats.items(),
        key=lambda item:
            item[1]["size"],
        reverse=True
    )

    for rule_id, stats in sorted_rules:

        print(
            f"{rule_id:<32} | "
            f"{stats['files']:>10,} files | "
            f"{gb(stats['size']):>10.2f} GB"
        )

    # =========================================================
    # CATEGORY BREAKDOWN
    # =========================================================

    print("\n" + "=" * 80)
    print("CATEGORY BREAKDOWN")
    print("=" * 80)

    sorted_categories = sorted(
        category_stats.items(),
        key=lambda item:
            item[1]["size"],
        reverse=True
    )

    for category, stats in sorted_categories:

        print(
            f"{category:<24} | "
            f"{stats['files']:>10,} files | "
            f"{gb(stats['size']):>10.2f} GB"
        )

    # =========================================================
    # PERFORMANCE
    # =========================================================

    print("\n" + "=" * 80)
    print("PERFORMANCE")
    print("=" * 80)

    print(
        f"\nAnalysis time : "
        f"{elapsed:.2f} sec"
    )

    if elapsed:

        print(
            f"Files / second: "
            f"{total_files / elapsed:,.0f}"
        )

    print("\n" + "=" * 80)

    conn.close()


if __name__ == "__main__":
    main()