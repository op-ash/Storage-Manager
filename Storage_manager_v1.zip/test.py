from google import genai

# ============================================================
# CONFIG
# ============================================================

API_KEY = "AIzaSyDEfaW9_WkRVW-e8sjn2-cgKesx4vJjv8E"


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 80)
    print("GEMINI MODEL AVAILABILITY TEST")
    print("=" * 80)

    client = genai.Client(
        api_key=API_KEY
    )

    # ========================================================
    # LIST AVAILABLE MODELS
    # ========================================================

    print("\nFetching available Gemini models...\n")

    try:

        models = list(
            client.models.list()
        )

    except Exception as exc:

        print("[ERROR] Could not list models:")
        print(exc)
        return

    print(
        f"Models returned by API: {len(models)}"
    )

    # ========================================================
    # FILTER GEMINI TEXT MODELS
    # ========================================================

    candidates = []

    for model in models:

        name = getattr(
            model,
            "name",
            "",
        )

        # We only care about Gemini models for this test.
        if "gemini" not in name.lower():
            continue

        candidates.append(name)

    print(
        f"Gemini candidates: {len(candidates)}"
    )

    print("\n" + "=" * 80)
    print("TESTING MODELS")
    print("=" * 80)

    working_models = []

    failed_models = []

    # ========================================================
    # TEST EACH MODEL
    # ========================================================

    for index, model_name in enumerate(
        candidates,
        start=1,
    ):

        # SDK may return names like:
        #
        # models/gemini-...
        #
        # generate_content generally expects just the
        # model identifier.
        clean_name = model_name

        if clean_name.startswith(
            "models/"
        ):

            clean_name = clean_name[
                len("models/"):
            ]

        print(
            f"\n[{index}/{len(candidates)}] "
            f"Testing: {clean_name}"
        )

        try:

            response = (
                client.models.generate_content(
                    model=clean_name,
                    contents=(
                        "Reply with exactly the word OK."
                    ),
                )
            )

            text = getattr(
                response,
                "text",
                None,
            )

            print(
                f"    [WORKING] Response: {text}"
            )

            working_models.append(
                clean_name
            )

        except Exception as exc:

            error = str(exc)

            print(
                f"    [FAILED] {error[:300]}"
            )

            failed_models.append(
                (
                    clean_name,
                    error,
                )
            )

    # ========================================================
    # FINAL RESULT
    # ========================================================

    print("\n" + "=" * 80)
    print("WORKING GEMINI MODELS")
    print("=" * 80)

    if working_models:

        for model in working_models:

            print(
                f"[OK] {model}"
            )

    else:

        print(
            "No working Gemini models found."
        )

    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)

    print(
        f"Candidates tested : {len(candidates)}"
    )

    print(
        f"Working           : {len(working_models)}"
    )

    print(
        f"Failed            : {len(failed_models)}"
    )


if __name__ == "__main__":

    main()