from dataclasses import dataclass
from typing import Optional


@dataclass
class RuleResult:

    rule_id: str

    category: str

    risk_level: str

    action: str

    confidence: float

    reason: str

    priority: int = 0


class BaseRule:

    rule_id = "BASE_RULE"

    priority = 0


    def match(
        self,
        path: str,
        size: int = 0
    ) -> Optional[RuleResult]:

        raise NotImplementedError