from rules.base_rule import (
    BaseRule,
    RuleResult
)


class AppDataCacheRule(BaseRule):

    rule_id = "APPDATA_CACHE_GENERIC"

    priority = 200


    CACHE_FOLDER_NAMES = {

        "cache",

        "code cache",

        "gpucache",

        "shadercache",

    }


    def match(
        self,
        path,
        size=0
    ):

        normalized = (
            path
            .lower()
            .replace("/", "\\")
        )


        # Must be inside AppData

        if "\\appdata\\" not in normalized:

            return None


        parts = [

            part

            for part in normalized.split("\\")

            if part

        ]


        # Check folder components

        for part in parts[:-1]:

            if (
                part
                in self.CACHE_FOLDER_NAMES
            ):

                return RuleResult(

                    rule_id=self.rule_id,

                    category="APP_CACHE",

                    risk_level="REVIEW",

                    action="REVIEW",

                    confidence=0.70,

                    reason=(
                        "File appears to be inside "
                        "an application cache directory."
                    ),

                    priority=self.priority
                )


        return None