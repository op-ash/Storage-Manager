import os
from dataclasses import dataclass
from typing import Tuple


@dataclass(frozen=True)
class RuleContext:
    """
    Precomputed path information shared by all rules.

    A RuleContext is created once per file so rules do not
    repeatedly normalize, lowercase, or split the same path.
    """

    path: str
    lower_path: str
    parts: Tuple[str, ...]
    directory_parts: Tuple[str, ...]
    size: int

    @classmethod
    def create(
        cls,
        path: str,
        size: int = 0
    ):

        normalized_path = os.path.normcase(
            os.path.normpath(path)
        )

        parts = tuple(
            normalized_path.split(os.sep)
        )

        return cls(
            path=normalized_path,
            lower_path=normalized_path.lower(),
            parts=parts,
            directory_parts=parts[:-1],
            size=size or 0,
        )