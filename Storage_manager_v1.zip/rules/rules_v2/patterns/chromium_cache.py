from rules.rules_v2.base import (
    BaseRule,
    RuleResult
)


class ChromiumCacheRule(BaseRule):

    rule_id = "CHROMIUM_CACHE"
    priority = 50

    CACHE_DIRECTORIES = {
        "cache",
        "code cache",
        "gpucache",
        "dawncache",
        "grshadercache",
    }

    SENSITIVE_NAMES = {
        "cookies",
        "history",
        "login data",
        "bookmarks",
        "extensions",
        "local storage",
        "session storage",
        "sessions",
        "web data",
        "preferences",
    }

    def match_context(
        self,
        context
    ):

        directory_parts = (
            context.directory_parts
        )

        # -----------------------------------------------------
        # SAFETY GUARD
        #
        # Persistent or sensitive Chromium/CEF data must never
        # be classified as disposable browser cache, even when
        # it exists below a directory named "Cache".
        # -----------------------------------------------------

        for part in context.parts:

            if part in self.SENSITIVE_NAMES:
                return None

        # -----------------------------------------------------
        # CHROMIUM / CEF STRUCTURE CHECK
        # -----------------------------------------------------

        if "user data" not in context.parts:
            return None

        # -----------------------------------------------------
        # VERIFIED CACHE DIRECTORY CHECK
        # -----------------------------------------------------

        for directory in self.CACHE_DIRECTORIES:

            if directory in directory_parts:

                return RuleResult(
                    rule_id=self.rule_id,
                    category="BROWSER_CACHE",
                    risk="SAFE",
                    action="CLEAN",
                    confidence=0.95,
                    reason=(
                        "File is located inside a known "
                        "Chromium browser cache directory."
                    )
                )

        return None