from .chromium_cache import ChromiumCacheRule
from .electron_cache import ElectronCacheRule
from .generic_cache import GenericCacheRule


PATTERN_RULES = [
    ChromiumCacheRule(),
    ElectronCacheRule(),
    GenericCacheRule(),
]


__all__ = [
    "PATTERN_RULES",
]