from rules.rules_v2.base import (
    BaseRule,
    RuleResult
)


class GenericCacheRule(BaseRule):

    rule_id = "GENERIC_CACHE"
    priority = 90

    def match_context(
        self,
        context
    ):

        if "cache" not in context.directory_parts:
            return None

        return RuleResult(
            rule_id=self.rule_id,
            category="CACHE",
            risk="REVIEW",
            action="REVIEW",
            confidence=0.60,
            reason=(
                "Path contains a directory named Cache, "
                "but the application or cache architecture "
                "is not sufficiently verified."
            )
        )