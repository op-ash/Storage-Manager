from rules.rules_v2.base import (
    BaseRule,
    RuleResult
)


class ElectronCacheRule(BaseRule):

    rule_id = "ELECTRON_CACHE"
    priority = 55

    CACHE_DIRECTORIES = {
        "cache",
        "code cache",
        "gpucache",
        "dawncache",
        "grshadercache",
    }

    def match_context(
        self,
        context
    ):

        path = context.lower_path

        # Electron application data is commonly
        # stored under AppData Local or Roaming.

        if (
            "\\appdata\\local\\"
            not in path
            and
            "\\appdata\\roaming\\"
            not in path
        ):
            return None

        directory_parts = (
            context.directory_parts
        )

        for directory in self.CACHE_DIRECTORIES:

            if directory in directory_parts:

                return RuleResult(
                    rule_id=self.rule_id,
                    category="APP_CACHE",
                    risk="REVIEW",
                    action="REVIEW",
                    confidence=0.80,
                    reason=(
                        "File matches a common cache directory "
                        "pattern used by desktop applications."
                    )
                )

        return None