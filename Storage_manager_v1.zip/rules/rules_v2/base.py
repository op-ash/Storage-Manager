import os
from dataclasses import dataclass
from enum import Enum


class RiskLevel(Enum):
    SAFE = "SAFE"
    LOW = "LOW"
    REVIEW = "REVIEW"
    PROTECTED = "PROTECTED"


class RuleAction(Enum):
    CLEAN = "CLEAN"
    REVIEW = "REVIEW"
    KEEP = "KEEP"


@dataclass
class RuleResult:
    rule_id: str
    category: str
    risk: str
    action: str
    confidence: float
    reason: str


class BaseRule:

    rule_id = "BASE_RULE"
    priority = 100

    # ---------------------------------------------------------
    # LEGACY PATH HELPERS
    # ---------------------------------------------------------
    # Keep these for backward compatibility while old rules
    # are gradually migrated to RuleContext.
    # ---------------------------------------------------------

    def normalize(self, path):
        return os.path.normcase(
            os.path.normpath(path)
        )

    def path_parts(self, path):
        return path.split(os.sep)

    def is_inside(
        self,
        path,
        folder
    ):
        folder = self.normalize(folder)

        return (
            path == folder
            or path.startswith(
                folder + os.sep
            )
        )

    def contains_directory(
        self,
        path,
        directory_name
    ):
        directory_name = (
            directory_name.lower()
        )

        parts = self.path_parts(path)

        return directory_name in [
            part.lower()
            for part in parts[:-1]
        ]

    # ---------------------------------------------------------
    # RULE CONTEXT HELPERS
    # ---------------------------------------------------------

    def context_is_inside(
        self,
        context,
        folder
    ):
        """
        Fast path check using a pre-normalized RuleContext.

        IMPORTANT:
        The folder should ideally be pre-normalized once
        in the rule constructor rather than passed as a raw
        path on every file.
        """

        return (
            context.path == folder
            or context.path.startswith(
                folder + os.sep
            )
        )

    def context_contains_directory(
        self,
        context,
        directory_name
    ):
        """
        Checks precomputed directory parts from RuleContext.
        """

        directory_name = (
            directory_name.lower()
        )

        return directory_name in (
            part.lower()
            for part in context.directory_parts
        )

    # ---------------------------------------------------------
    # OLD RULE INTERFACE
    # ---------------------------------------------------------

    def match(
        self,
        path,
        size=0
    ):
        raise NotImplementedError

    # ---------------------------------------------------------
    # NEW OPTIMIZED RULE INTERFACE
    # ---------------------------------------------------------

    def match_context(
        self,
        context
    ):
        """
        Optimized rules should override this method.

        Temporary backward compatibility:
        Rules not yet migrated to RuleContext will continue
        working through their existing match() implementation.

        Once every V2 rule has been migrated, this fallback
        can eventually be removed.
        """

        return self.match(
            context.path,
            context.size
        )