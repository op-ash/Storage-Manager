from .temp import (
    UserTempRule,
    WindowsTempRule,
)

from .crash import CrashDumpRule


CLEANUP_RULES = [
    UserTempRule(),
    WindowsTempRule(),
    CrashDumpRule(),
]


__all__ = [
    "CLEANUP_RULES",
]