from rules.rules_v2.base import (
    BaseRule,
    RuleResult
)


class CrashDumpRule(BaseRule):

    rule_id = "CRASH_DUMP"
    priority = 35

    def match_context(
        self,
        context
    ):

        path = context.lower_path

        if (
            "\\crashdumps\\" not in path
            and not path.endswith(".dmp")
        ):
            return None

        return RuleResult(
            rule_id=self.rule_id,
            category="CRASH_DUMP",
            risk="SAFE",
            action="CLEAN",
            confidence=0.95,
            reason=(
                "File appears to be a crash dump "
                "used primarily for diagnostics."
            )
        )