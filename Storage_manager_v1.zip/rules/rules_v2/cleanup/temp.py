import os

from rules.rules_v2.base import (
    BaseRule,
    RuleResult
)


class UserTempRule(BaseRule):

    rule_id = "USER_TEMP"
    priority = 30

    def __init__(self):

        user_profile = os.environ.get(
            "USERPROFILE"
        )

        if user_profile:

            self.temp_folder = (
                self.normalize(
                    os.path.join(
                        user_profile,
                        "AppData",
                        "Local",
                        "Temp"
                    )
                )
            )

        else:

            self.temp_folder = None

    def match_context(
        self,
        context
    ):

        if not self.temp_folder:
            return None

        if not self.context_is_inside(
            context,
            self.temp_folder
        ):
            return None

        return RuleResult(
            rule_id=self.rule_id,
            category="TEMP",
            risk="SAFE",
            action="CLEAN",
            confidence=0.95,
            reason=(
                "File is located inside the current "
                "user's temporary directory."
            )
        )


class WindowsTempRule(BaseRule):

    rule_id = "WINDOWS_TEMP"
    priority = 30

    def __init__(self):

        self.temp_folder = (
            self.normalize(
                r"C:\Windows\Temp"
            )
        )

    def match_context(
        self,
        context
    ):

        if not self.context_is_inside(
            context,
            self.temp_folder
        ):
            return None

        return RuleResult(
            rule_id=self.rule_id,
            category="TEMP",
            risk="SAFE",
            action="CLEAN",
            confidence=0.90,
            reason=(
                "File is located inside the Windows "
                "temporary directory."
            )
        )