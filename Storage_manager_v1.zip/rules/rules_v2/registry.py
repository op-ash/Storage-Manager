from rules.rules_v2.protection import PROTECTION_RULES
from rules.rules_v2.cleanup import CLEANUP_RULES
from rules.rules_v2.patterns import PATTERN_RULES
from rules.rules_v2.fallback import FALLBACK_RULES


def get_rules():

    rules = [
        *PROTECTION_RULES,
        *CLEANUP_RULES,
        *PATTERN_RULES,
        *FALLBACK_RULES,
    ]

    return sorted(
        rules,
        key=lambda rule: rule.priority
    )