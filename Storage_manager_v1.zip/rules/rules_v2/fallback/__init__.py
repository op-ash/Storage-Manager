from .technical_data import (
    KnownAppDataFallbackRule,
    ProgramDataFallbackRule,
    RecycleBinFallbackRule,
)


FALLBACK_RULES = [
    KnownAppDataFallbackRule(),
    ProgramDataFallbackRule(),
    RecycleBinFallbackRule(),
]


__all__ = [
    "FALLBACK_RULES",
]