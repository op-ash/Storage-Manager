import os

from rules.rules_v2.base import (
    BaseRule,
    RuleResult,
)


class KnownAppDataFallbackRule(BaseRule):

    rule_id = "KEEP_APPDATA_FALLBACK"
    priority = 900

    APPDATA_PATTERNS = (
        "\\appdata\\local\\",
        "\\appdata\\roaming\\",
        "\\appdata\\locallow\\",
    )

    def match_context(
        self,
        context
    ):

        path = context.lower_path

        if not any(
            pattern in path
            for pattern in self.APPDATA_PATTERNS
        ):
            return None

        return RuleResult(
            rule_id=self.rule_id,
            category="APPLICATION_DATA",
            risk="PROTECTED",
            action="KEEP",
            confidence=0.85,
            reason=(
                "File belongs to application data and no verified "
                "cleanup rule matched it. Keeping it by default."
            ),
        )


class ProgramDataFallbackRule(BaseRule):

    rule_id = "KEEP_PROGRAMDATA_FALLBACK"
    priority = 910

    def __init__(self):

        self.programdata_folder = (
            self.normalize(
                r"C:\ProgramData"
            )
        )

    def match_context(
        self,
        context
    ):

        if not self.context_is_inside(
            context,
            self.programdata_folder
        ):
            return None

        return RuleResult(
            rule_id=self.rule_id,
            category="APPLICATION_DATA",
            risk="PROTECTED",
            action="KEEP",
            confidence=0.90,
            reason=(
                "File belongs to ProgramData and no verified cleanup "
                "rule matched it. Keeping shared application data by default."
            ),
        )


class RecycleBinFallbackRule(BaseRule):

    rule_id = "RECYCLE_BIN_REVIEW"
    priority = 920

    def match_context(
        self,
        context
    ):

        if "\\$recycle.bin\\" not in context.lower_path:
            return None

        return RuleResult(
            rule_id=self.rule_id,
            category="RECYCLE_BIN",
            risk="REVIEW",
            action="REVIEW",
            confidence=0.95,
            reason=(
                "File is stored in the Windows Recycle Bin. "
                "It can potentially be removed permanently after user review."
            ),
        )