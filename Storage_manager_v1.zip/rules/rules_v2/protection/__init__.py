from .technical_protection import (
    InstalledProgramsProtectionRule,
    WSLProtectionRule,
    DockerProtectionRule,
    ModelDataProtectionRule,
)


PROTECTION_RULES = [
    InstalledProgramsProtectionRule(),
    WSLProtectionRule(),
    DockerProtectionRule(),
    ModelDataProtectionRule(),
]


__all__ = [
    "PROTECTION_RULES",
]