import os

from rules.rules_v2.base import (
    BaseRule,
    RuleResult
)


class InstalledProgramsProtectionRule(BaseRule):

    rule_id = "PROTECT_INSTALLED_PROGRAMS"
    priority = 10

    def __init__(self):

        user_profile = os.environ.get(
            "USERPROFILE"
        )

        if user_profile:

            self.programs_folder = (
                self.normalize(
                    os.path.join(
                        user_profile,
                        "AppData",
                        "Local",
                        "Programs"
                    )
                )
            )

        else:
            self.programs_folder = None

    def match_context(
        self,
        context
    ):

        if not self.programs_folder:
            return None

        if not self.context_is_inside(
            context,
            self.programs_folder
        ):
            return None

        return RuleResult(
            rule_id=self.rule_id,
            category="INSTALLED_APPLICATION",
            risk="PROTECTED",
            action="KEEP",
            confidence=1.0,
            reason=(
                "File belongs to an application installed "
                "inside the user's local Programs directory."
            )
        )


class WSLProtectionRule(BaseRule):

    rule_id = "PROTECT_WSL_DATA"
    priority = 10

    def __init__(self):

        user_profile = os.environ.get(
            "USERPROFILE"
        )

        if user_profile:

            self.wsl_folder = (
                self.normalize(
                    os.path.join(
                        user_profile,
                        "AppData",
                        "Local",
                        "wsl"
                    )
                )
            )

        else:
            self.wsl_folder = None

    def match_context(
        self,
        context
    ):

        if not self.wsl_folder:
            return None

        if not self.context_is_inside(
            context,
            self.wsl_folder
        ):
            return None

        return RuleResult(
            rule_id=self.rule_id,
            category="RUNTIME_DATA",
            risk="PROTECTED",
            action="KEEP",
            confidence=1.0,
            reason=(
                "File belongs to Windows Subsystem for Linux "
                "runtime or virtual disk storage."
            )
        )


class DockerProtectionRule(BaseRule):

    rule_id = "PROTECT_DOCKER_DATA"
    priority = 10

    def __init__(self):

        user_profile = os.environ.get(
            "USERPROFILE"
        )

        if user_profile:

            self.docker_locations = (

                self.normalize(
                    os.path.join(
                        user_profile,
                        "AppData",
                        "Local",
                        "Docker"
                    )
                ),

                self.normalize(
                    os.path.join(
                        user_profile,
                        ".docker"
                    )
                ),

            )

        else:

            self.docker_locations = ()

    def match_context(
        self,
        context
    ):

        for folder in self.docker_locations:

            if self.context_is_inside(
                context,
                folder
            ):

                return RuleResult(
                    rule_id=self.rule_id,
                    category="RUNTIME_DATA",
                    risk="PROTECTED",
                    action="KEEP",
                    confidence=1.0,
                    reason=(
                        "File belongs to Docker runtime, "
                        "configuration, or container storage."
                    )
                )

        return None


class ModelDataProtectionRule(BaseRule):

    rule_id = "PROTECT_DOWNLOADED_MODELS"
    priority = 15

    RAW_MODEL_PATTERNS = (
        os.path.join(
            ".cache",
            "huggingface"
        ),
        os.path.join(
            ".cache",
            "whisper"
        ),
        os.path.join(
            ".cache",
            "chroma"
        ),
    )

    def __init__(self):

        self.model_patterns = tuple(
            self.normalize(pattern)
            for pattern
            in self.RAW_MODEL_PATTERNS
        )

    def match_context(
        self,
        context
    ):

        path = context.path

        for pattern in self.model_patterns:

            if pattern in path:

                return RuleResult(
                    rule_id=self.rule_id,
                    category="MODEL_DATA",
                    risk="PROTECTED",
                    action="KEEP",
                    confidence=0.98,
                    reason=(
                        "File appears to belong to downloaded "
                        "AI or machine-learning model data."
                    )
                )

        return None