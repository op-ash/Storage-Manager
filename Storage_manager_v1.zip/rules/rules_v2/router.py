import os


class RuleRouter:
    """
    Routes files to a smaller set of relevant rules.

    This prevents every technical file from being tested
    against every rule in the Rulebook.
    """

    def __init__(self, rules):

        self.rules_by_id = {
            rule.rule_id: rule
            for rule in rules
        }

        # -----------------------------------------------------
        # Pre-build rule groups once
        # -----------------------------------------------------

        self.appdata_rules = self._get_rules(
            [
                "PROTECT_INSTALLED_PROGRAMS",
                "PROTECT_WSL_DATA",
                "PROTECT_DOCKER_DATA",
                "USER_TEMP",
                "CRASH_DUMP",
                "CHROMIUM_CACHE",
                "ELECTRON_CACHE",
                "GENERIC_CACHE",
                "KEEP_APPDATA_FALLBACK",
            ]
        )

        self.programdata_rules = self._get_rules(
            [
                "CRASH_DUMP",
                "GENERIC_CACHE",
                "KEEP_PROGRAMDATA_FALLBACK",
            ]
        )

        self.windows_temp_rules = self._get_rules(
            [
                "WINDOWS_TEMP",
            ]
        )

        self.recycle_bin_rules = self._get_rules(
            [
                "RECYCLE_BIN_REVIEW",
            ]
        )

        self.model_rules = self._get_rules(
            [
                "PROTECT_DOWNLOADED_MODELS",
                "GENERIC_CACHE",
            ]
        )

        # Fallback for technical paths that do not belong
        # to one of the major known route families.
        self.default_rules = self._get_rules(
            [
                "CRASH_DUMP",
                "GENERIC_CACHE",
            ]
        )

        self.windows_temp_prefix = (
            os.path.normcase(
                os.path.normpath(
                    r"C:\Windows\Temp"
                )
            )
            + os.sep
        )

        self.programdata_prefix = (
            os.path.normcase(
                os.path.normpath(
                    r"C:\ProgramData"
                )
            )
            + os.sep
        )

    def _get_rules(self, rule_ids):

        return [
            self.rules_by_id[rule_id]
            for rule_id in rule_ids
            if rule_id in self.rules_by_id
        ]

    def get_rules(self, context):

        path = context.lower_path

        if path.startswith(
            self.windows_temp_prefix
        ):
            return self.windows_temp_rules

        if "\\$recycle.bin\\" in path:
            return self.recycle_bin_rules

        if "\\appdata\\" in path:
            return self.appdata_rules

        if path.startswith(
            self.programdata_prefix
        ):
            return self.programdata_rules

        if "\\.cache\\" in path:
            return self.model_rules

        return self.default_rules