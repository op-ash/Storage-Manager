from rules.protected_rules import (
    WindowsSystemRule
)

from rules.temp_rules import (
    UserTempRule,
    WindowsTempRule
)

from rules.cache_rules import (
    AppDataCacheRule
)

from rules.cleanup_rules import (
    CrashDumpRule
)


def get_rules():

    rules = [

        # Safety
        WindowsSystemRule(),

        # Temporary
        UserTempRule(),
        WindowsTempRule(),

        # Cleanup
        CrashDumpRule(),

        # Generic cache
        AppDataCacheRule(),

    ]


    # Highest priority first

    rules.sort(

        key=lambda rule:
            rule.priority,

        reverse=True

    )


    return rules