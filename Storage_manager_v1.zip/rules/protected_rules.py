from rules.base_rule import (
    BaseRule,
    RuleResult
)


class WindowsSystemRule(BaseRule):

    rule_id = "PROTECTED_WINDOWS_SYSTEM"

    priority = 1000


    PROTECTED_PATHS = (

        r"c:\windows\system32",

        r"c:\windows\syswow64",

        r"c:\windows\winsxs",

        r"c:\windows\servicing",

    )


    def match(
        self,
        path,
        size=0
    ):

        normalized = (
            path
            .lower()
            .rstrip("\\")
        )


        for protected_path in (
            self.PROTECTED_PATHS
        ):

            if (
                normalized
                == protected_path

                or normalized.startswith(
                    protected_path + "\\"
                )
            ):

                return RuleResult(

                    rule_id=self.rule_id,

                    category="SYSTEM",

                    risk_level="PROTECTED",

                    action="KEEP",

                    confidence=1.0,

                    reason=(
                        "Critical Windows system location."
                    ),

                    priority=self.priority
                )


        return None