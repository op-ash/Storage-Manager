import os

from rules.base_rule import (
    BaseRule,
    RuleResult
)


class UserTempRule(BaseRule):

    rule_id = "USER_TEMP"

    priority = 500


    def __init__(self):

        temp_path = os.environ.get(
            "TEMP"
        )


        if temp_path:

            self.temp_path = (
                temp_path
                .lower()
                .rstrip("\\")
            )

        else:

            self.temp_path = None


    def match(
        self,
        path,
        size=0
    ):

        if not self.temp_path:

            return None


        normalized = (
            path
            .lower()
            .rstrip("\\")
        )


        if (
            normalized
            == self.temp_path

            or normalized.startswith(
                self.temp_path + "\\"
            )
        ):

            return RuleResult(

                rule_id=self.rule_id,

                category="TEMP",

                risk_level="SAFE",

                action="CLEAN",

                confidence=0.95,

                reason=(
                    "File is located inside "
                    "the current user's temporary folder."
                ),

                priority=self.priority
            )


        return None


class WindowsTempRule(BaseRule):

    rule_id = "WINDOWS_TEMP"

    priority = 500


    WINDOWS_TEMP = (
        r"c:\windows\temp"
    )


    def match(
        self,
        path,
        size=0
    ):

        normalized = (
            path
            .lower()
            .rstrip("\\")
        )


        if (
            normalized
            == self.WINDOWS_TEMP

            or normalized.startswith(
                self.WINDOWS_TEMP + "\\"
            )
        ):

            return RuleResult(

                rule_id=self.rule_id,

                category="TEMP",

                risk_level="SAFE",

                action="CLEAN",

                confidence=0.90,

                reason=(
                    "File is located inside "
                    "the Windows temporary folder."
                ),

                priority=self.priority
            )


        return None