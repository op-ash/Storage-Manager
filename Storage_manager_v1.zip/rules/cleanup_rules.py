from rules.base_rule import (
    BaseRule,
    RuleResult
)


class CrashDumpRule(BaseRule):

    rule_id = "CRASH_DUMP"

    priority = 300


    def match(
        self,
        path,
        size=0
    ):

        normalized = (
            path.lower()
        )


        if (
            "\\crashdumps\\"
            in normalized

            and normalized.endswith(
                ".dmp"
            )
        ):

            return RuleResult(

                rule_id=self.rule_id,

                category="CRASH_DUMP",

                risk_level="SAFE",

                action="CLEAN",

                confidence=0.95,

                reason=(
                    "Application crash dump "
                    "used primarily for diagnostics."
                ),

                priority=self.priority
            )


        return None